/*     */ package libsvm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Solver
/*     */ {
/*     */   int active_size;
/*     */   byte[] y;
/*     */   double[] G;
/*     */   static final byte LOWER_BOUND = 0;
/*     */   static final byte UPPER_BOUND = 1;
/*     */   static final byte FREE = 2;
/*     */   byte[] alpha_status;
/*     */   double[] alpha;
/*     */   QMatrix Q;
/*     */   double[] QD;
/*     */   double eps;
/*     */   double Cp;
/*     */   double Cn;
/*     */   double[] p;
/*     */   int[] active_set;
/*     */   double[] G_bar;
/*     */   int l;
/*     */   boolean unshrink;
/*     */   static final double INF = InfinityD;
/*     */   
/* 325 */   double get_C(int i) { return (this.y[i] > 0) ? this.Cp : this.Cn; }
/*     */ 
/*     */   
/*     */   void update_alpha_status(int i) {
/* 329 */     if (this.alpha[i] >= get_C(i))
/* 330 */     { this.alpha_status[i] = 1; }
/* 331 */     else if (this.alpha[i] <= 0.0D)
/* 332 */     { this.alpha_status[i] = 0; }
/* 333 */     else { this.alpha_status[i] = 2; }
/*     */   
/* 335 */   } boolean is_upper_bound(int i) { return (this.alpha_status[i] == 1); }
/* 336 */   boolean is_lower_bound(int i) { return (this.alpha_status[i] == 0); }
/* 337 */   boolean is_free(int i) { return (this.alpha_status[i] == 2); }
/*     */ 
/*     */   
/*     */   static class SolutionInfo
/*     */   {
/*     */     double obj;
/*     */     
/*     */     double rho;
/*     */     double upper_bound_p;
/*     */     double upper_bound_n;
/*     */     double r;
/*     */   }
/*     */   
/*     */   void swap_index(int i, int j) {
/* 351 */     this.Q.swap_index(i, j);
/* 352 */     byte _ = this.y[i]; this.y[i] = this.y[j]; this.y[j] = _;
/* 353 */     double _ = this.G[i]; this.G[i] = this.G[j]; this.G[j] = _;
/* 354 */     byte _ = this.alpha_status[i]; this.alpha_status[i] = this.alpha_status[j]; this.alpha_status[j] = _;
/* 355 */     double _ = this.alpha[i]; this.alpha[i] = this.alpha[j]; this.alpha[j] = _;
/* 356 */     double _ = this.p[i]; this.p[i] = this.p[j]; this.p[j] = _;
/* 357 */     int _ = this.active_set[i]; this.active_set[i] = this.active_set[j]; this.active_set[j] = _;
/* 358 */     double _ = this.G_bar[i]; this.G_bar[i] = this.G_bar[j]; this.G_bar[j] = _;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reconstruct_gradient() {
/* 365 */     if (this.active_size == this.l) {
/*     */       return;
/*     */     }
/* 368 */     int nr_free = 0;
/*     */     int j;
/* 370 */     for (j = this.active_size; j < this.l; j++) {
/* 371 */       this.G[j] = this.G_bar[j] + this.p[j];
/*     */     }
/* 373 */     for (j = 0; j < this.active_size; j++) {
/* 374 */       if (is_free(j))
/* 375 */         nr_free++; 
/*     */     } 
/* 377 */     if (2 * nr_free < this.active_size) {
/* 378 */       svm.info("\nWarning: using -h 0 may be faster\n");
/*     */     }
/* 380 */     if (nr_free * this.l > 2 * this.active_size * (this.l - this.active_size)) {
/*     */       
/* 382 */       for (int i = this.active_size; i < this.l; i++) {
/*     */         
/* 384 */         float[] Q_i = this.Q.get_Q(i, this.active_size);
/* 385 */         for (j = 0; j < this.active_size; j++) {
/* 386 */           if (is_free(j)) {
/* 387 */             this.G[i] = this.G[i] + this.alpha[j] * Q_i[j];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/* 392 */       for (int i = 0; i < this.active_size; i++) {
/* 393 */         if (is_free(i)) {
/*     */           
/* 395 */           float[] Q_i = this.Q.get_Q(i, this.l);
/* 396 */           double alpha_i = this.alpha[i];
/* 397 */           for (j = this.active_size; j < this.l; j++) {
/* 398 */             this.G[j] = this.G[j] + alpha_i * Q_i[j];
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   void Solve(int l, QMatrix Q, double[] p_, byte[] y_, double[] alpha_, double Cp, double Cn, double eps, SolutionInfo si, int shrinking) {
/* 406 */     this.l = l;
/* 407 */     this.Q = Q;
/* 408 */     this.QD = Q.get_QD();
/* 409 */     this.p = (double[])p_.clone();
/* 410 */     this.y = (byte[])y_.clone();
/* 411 */     this.alpha = (double[])alpha_.clone();
/* 412 */     this.Cp = Cp;
/* 413 */     this.Cn = Cn;
/* 414 */     this.eps = eps;
/* 415 */     this.unshrink = false;
/*     */ 
/*     */ 
/*     */     
/* 419 */     this.alpha_status = new byte[l];
/* 420 */     for (int i = 0; i < l; i++) {
/* 421 */       update_alpha_status(i);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 426 */     this.active_set = new int[l];
/* 427 */     for (int i = 0; i < l; i++)
/* 428 */       this.active_set[i] = i; 
/* 429 */     this.active_size = l;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     this.G = new double[l];
/* 435 */     this.G_bar = new double[l];
/*     */     int i;
/* 437 */     for (i = 0; i < l; i++) {
/*     */       
/* 439 */       this.G[i] = this.p[i];
/* 440 */       this.G_bar[i] = 0.0D;
/*     */     } 
/* 442 */     for (i = 0; i < l; i++) {
/* 443 */       if (!is_lower_bound(i)) {
/*     */         
/* 445 */         float[] Q_i = Q.get_Q(i, l);
/* 446 */         double alpha_i = this.alpha[i];
/*     */         int j;
/* 448 */         for (j = 0; j < l; j++)
/* 449 */           this.G[j] = this.G[j] + alpha_i * Q_i[j]; 
/* 450 */         if (is_upper_bound(i)) {
/* 451 */           for (j = 0; j < l; j++) {
/* 452 */             this.G_bar[j] = this.G_bar[j] + get_C(i) * Q_i[j];
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 458 */     int iter = 0;
/* 459 */     int counter = Math.min(l, 1000) + 1;
/* 460 */     int[] working_set = new int[2];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 466 */       if (--counter == 0) {
/*     */         
/* 468 */         counter = Math.min(l, 1000);
/* 469 */         if (shrinking != 0) do_shrinking(); 
/* 470 */         svm.info(".");
/*     */       } 
/*     */       
/* 473 */       if (select_working_set(working_set) != 0) {
/*     */ 
/*     */         
/* 476 */         reconstruct_gradient();
/*     */         
/* 478 */         this.active_size = l;
/* 479 */         svm.info("*");
/* 480 */         if (select_working_set(working_set) != 0) {
/*     */           break;
/*     */         }
/* 483 */         counter = 1;
/*     */       } 
/*     */       
/* 486 */       int i = working_set[0];
/* 487 */       int j = working_set[1];
/*     */       
/* 489 */       iter++;
/*     */ 
/*     */ 
/*     */       
/* 493 */       float[] Q_i = Q.get_Q(i, this.active_size);
/* 494 */       float[] Q_j = Q.get_Q(j, this.active_size);
/*     */       
/* 496 */       double C_i = get_C(i);
/* 497 */       double C_j = get_C(j);
/*     */       
/* 499 */       double old_alpha_i = this.alpha[i];
/* 500 */       double old_alpha_j = this.alpha[j];
/*     */       
/* 502 */       if (this.y[i] != this.y[j]) {
/*     */         
/* 504 */         double quad_coef = this.QD[i] + this.QD[j] + (2.0F * Q_i[j]);
/* 505 */         if (quad_coef <= 0.0D)
/* 506 */           quad_coef = 1.0E-12D; 
/* 507 */         double delta = (-this.G[i] - this.G[j]) / quad_coef;
/* 508 */         double diff = this.alpha[i] - this.alpha[j];
/* 509 */         this.alpha[i] = this.alpha[i] + delta;
/* 510 */         this.alpha[j] = this.alpha[j] + delta;
/*     */         
/* 512 */         if (diff > 0.0D) {
/*     */           
/* 514 */           if (this.alpha[j] < 0.0D)
/*     */           {
/* 516 */             this.alpha[j] = 0.0D;
/* 517 */             this.alpha[i] = diff;
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 522 */         else if (this.alpha[i] < 0.0D) {
/*     */           
/* 524 */           this.alpha[i] = 0.0D;
/* 525 */           this.alpha[j] = -diff;
/*     */         } 
/*     */         
/* 528 */         if (diff > C_i - C_j)
/*     */         {
/* 530 */           if (this.alpha[i] > C_i)
/*     */           {
/* 532 */             this.alpha[i] = C_i;
/* 533 */             this.alpha[j] = C_i - diff;
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 538 */         else if (this.alpha[j] > C_j)
/*     */         {
/* 540 */           this.alpha[j] = C_j;
/* 541 */           this.alpha[i] = C_j + diff;
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 547 */         double quad_coef = this.QD[i] + this.QD[j] - (2.0F * Q_i[j]);
/* 548 */         if (quad_coef <= 0.0D)
/* 549 */           quad_coef = 1.0E-12D; 
/* 550 */         double delta = (this.G[i] - this.G[j]) / quad_coef;
/* 551 */         double sum = this.alpha[i] + this.alpha[j];
/* 552 */         this.alpha[i] = this.alpha[i] - delta;
/* 553 */         this.alpha[j] = this.alpha[j] + delta;
/*     */         
/* 555 */         if (sum > C_i) {
/*     */           
/* 557 */           if (this.alpha[i] > C_i)
/*     */           {
/* 559 */             this.alpha[i] = C_i;
/* 560 */             this.alpha[j] = sum - C_i;
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 565 */         else if (this.alpha[j] < 0.0D) {
/*     */           
/* 567 */           this.alpha[j] = 0.0D;
/* 568 */           this.alpha[i] = sum;
/*     */         } 
/*     */         
/* 571 */         if (sum > C_j) {
/*     */           
/* 573 */           if (this.alpha[j] > C_j)
/*     */           {
/* 575 */             this.alpha[j] = C_j;
/* 576 */             this.alpha[i] = sum - C_j;
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 581 */         else if (this.alpha[i] < 0.0D) {
/*     */           
/* 583 */           this.alpha[i] = 0.0D;
/* 584 */           this.alpha[j] = sum;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 591 */       double delta_alpha_i = this.alpha[i] - old_alpha_i;
/* 592 */       double delta_alpha_j = this.alpha[j] - old_alpha_j;
/*     */       
/* 594 */       for (int k = 0; k < this.active_size; k++)
/*     */       {
/* 596 */         this.G[k] = this.G[k] + Q_i[k] * delta_alpha_i + Q_j[k] * delta_alpha_j;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 602 */       boolean ui = is_upper_bound(i);
/* 603 */       boolean uj = is_upper_bound(j);
/* 604 */       update_alpha_status(i);
/* 605 */       update_alpha_status(j);
/*     */       
/* 607 */       if (ui != is_upper_bound(i)) {
/*     */         
/* 609 */         Q_i = Q.get_Q(i, l);
/* 610 */         if (ui) {
/* 611 */           for (int k = 0; k < l; k++)
/* 612 */             this.G_bar[k] = this.G_bar[k] - C_i * Q_i[k]; 
/*     */         } else {
/* 614 */           for (int k = 0; k < l; k++)
/* 615 */             this.G_bar[k] = this.G_bar[k] + C_i * Q_i[k]; 
/*     */         } 
/*     */       } 
/* 618 */       if (uj != is_upper_bound(j)) {
/*     */         
/* 620 */         Q_j = Q.get_Q(j, l);
/* 621 */         if (uj) {
/* 622 */           for (int k = 0; k < l; k++)
/* 623 */             this.G_bar[k] = this.G_bar[k] - C_j * Q_j[k];  continue;
/*     */         } 
/* 625 */         for (int k = 0; k < l; k++) {
/* 626 */           this.G_bar[k] = this.G_bar[k] + C_j * Q_j[k];
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 634 */     si.rho = calculate_rho();
/*     */ 
/*     */ 
/*     */     
/* 638 */     double v = 0.0D;
/*     */     
/* 640 */     for (int i = 0; i < l; i++) {
/* 641 */       v += this.alpha[i] * (this.G[i] + this.p[i]);
/*     */     }
/* 643 */     si.obj = v / 2.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 648 */     for (int i = 0; i < l; i++) {
/* 649 */       alpha_[this.active_set[i]] = this.alpha[i];
/*     */     }
/*     */     
/* 652 */     si.upper_bound_p = Cp;
/* 653 */     si.upper_bound_n = Cn;
/*     */     
/* 655 */     svm.info("\noptimization finished, #iter = " + iter + "\n");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int select_working_set(int[] working_set) {
/* 667 */     double Gmax = Double.NEGATIVE_INFINITY;
/* 668 */     double Gmax2 = Double.NEGATIVE_INFINITY;
/* 669 */     int Gmax_idx = -1;
/* 670 */     int Gmin_idx = -1;
/* 671 */     double obj_diff_min = Double.POSITIVE_INFINITY;
/*     */     
/* 673 */     for (int t = 0; t < this.active_size; t++) {
/* 674 */       if (this.y[t] == 1) {
/*     */         
/* 676 */         if (!is_upper_bound(t) && 
/* 677 */           -this.G[t] >= Gmax)
/*     */         {
/* 679 */           Gmax = -this.G[t];
/* 680 */           Gmax_idx = t;
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 685 */       else if (!is_lower_bound(t) && 
/* 686 */         this.G[t] >= Gmax) {
/*     */         
/* 688 */         Gmax = this.G[t];
/* 689 */         Gmax_idx = t;
/*     */       } 
/*     */     } 
/*     */     
/* 693 */     int i = Gmax_idx;
/* 694 */     float[] Q_i = null;
/* 695 */     if (i != -1) {
/* 696 */       Q_i = this.Q.get_Q(i, this.active_size);
/*     */     }
/* 698 */     for (int j = 0; j < this.active_size; j++) {
/*     */       
/* 700 */       if (this.y[j] == 1) {
/*     */         
/* 702 */         if (!is_lower_bound(j))
/*     */         {
/* 704 */           double grad_diff = Gmax + this.G[j];
/* 705 */           if (this.G[j] >= Gmax2)
/* 706 */             Gmax2 = this.G[j]; 
/* 707 */           if (grad_diff > 0.0D)
/*     */           {
/*     */             
/* 710 */             double obj_diff, quad_coef = this.QD[i] + this.QD[j] - 2.0D * this.y[i] * Q_i[j];
/* 711 */             if (quad_coef > 0.0D) {
/* 712 */               obj_diff = -(grad_diff * grad_diff) / quad_coef;
/*     */             } else {
/* 714 */               obj_diff = -(grad_diff * grad_diff) / 1.0E-12D;
/*     */             } 
/* 716 */             if (obj_diff <= obj_diff_min)
/*     */             {
/* 718 */               Gmin_idx = j;
/* 719 */               obj_diff_min = obj_diff;
/*     */             }
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 726 */       } else if (!is_upper_bound(j)) {
/*     */         
/* 728 */         double grad_diff = Gmax - this.G[j];
/* 729 */         if (-this.G[j] >= Gmax2)
/* 730 */           Gmax2 = -this.G[j]; 
/* 731 */         if (grad_diff > 0.0D) {
/*     */ 
/*     */           
/* 734 */           double obj_diff, quad_coef = this.QD[i] + this.QD[j] + 2.0D * this.y[i] * Q_i[j];
/* 735 */           if (quad_coef > 0.0D) {
/* 736 */             obj_diff = -(grad_diff * grad_diff) / quad_coef;
/*     */           } else {
/* 738 */             obj_diff = -(grad_diff * grad_diff) / 1.0E-12D;
/*     */           } 
/* 740 */           if (obj_diff <= obj_diff_min) {
/*     */             
/* 742 */             Gmin_idx = j;
/* 743 */             obj_diff_min = obj_diff;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 750 */     if (Gmax + Gmax2 < this.eps) {
/* 751 */       return 1;
/*     */     }
/* 753 */     working_set[0] = Gmax_idx;
/* 754 */     working_set[1] = Gmin_idx;
/* 755 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean be_shrunk(int i, double Gmax1, double Gmax2) {
/* 760 */     if (is_upper_bound(i)) {
/*     */       
/* 762 */       if (this.y[i] == 1) {
/* 763 */         return (-this.G[i] > Gmax1);
/*     */       }
/* 765 */       return (-this.G[i] > Gmax2);
/*     */     } 
/* 767 */     if (is_lower_bound(i)) {
/*     */       
/* 769 */       if (this.y[i] == 1) {
/* 770 */         return (this.G[i] > Gmax2);
/*     */       }
/* 772 */       return (this.G[i] > Gmax1);
/*     */     } 
/*     */     
/* 775 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void do_shrinking() {
/* 781 */     double Gmax1 = Double.NEGATIVE_INFINITY;
/* 782 */     double Gmax2 = Double.NEGATIVE_INFINITY;
/*     */     
/*     */     int i;
/* 785 */     for (i = 0; i < this.active_size; i++) {
/*     */       
/* 787 */       if (this.y[i] == 1) {
/*     */         
/* 789 */         if (!is_upper_bound(i))
/*     */         {
/* 791 */           if (-this.G[i] >= Gmax1)
/* 792 */             Gmax1 = -this.G[i]; 
/*     */         }
/* 794 */         if (!is_lower_bound(i))
/*     */         {
/* 796 */           if (this.G[i] >= Gmax2) {
/* 797 */             Gmax2 = this.G[i];
/*     */           }
/*     */         }
/*     */       } else {
/*     */         
/* 802 */         if (!is_upper_bound(i))
/*     */         {
/* 804 */           if (-this.G[i] >= Gmax2)
/* 805 */             Gmax2 = -this.G[i]; 
/*     */         }
/* 807 */         if (!is_lower_bound(i))
/*     */         {
/* 809 */           if (this.G[i] >= Gmax1) {
/* 810 */             Gmax1 = this.G[i];
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/* 815 */     if (!this.unshrink && Gmax1 + Gmax2 <= this.eps * 10.0D) {
/*     */       
/* 817 */       this.unshrink = true;
/* 818 */       reconstruct_gradient();
/* 819 */       this.active_size = this.l;
/*     */     } 
/*     */     
/* 822 */     for (i = 0; i < this.active_size; i++) {
/* 823 */       if (be_shrunk(i, Gmax1, Gmax2)) {
/*     */         
/* 825 */         this.active_size--;
/* 826 */         while (this.active_size > i) {
/*     */           
/* 828 */           if (!be_shrunk(this.active_size, Gmax1, Gmax2)) {
/*     */             
/* 830 */             swap_index(i, this.active_size);
/*     */             break;
/*     */           } 
/* 833 */           this.active_size--;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   double calculate_rho() {
/*     */     double r;
/* 841 */     int nr_free = 0;
/* 842 */     double ub = Double.POSITIVE_INFINITY, lb = Double.NEGATIVE_INFINITY, sum_free = 0.0D;
/* 843 */     for (int i = 0; i < this.active_size; i++) {
/*     */       
/* 845 */       double yG = this.y[i] * this.G[i];
/*     */       
/* 847 */       if (is_lower_bound(i)) {
/*     */         
/* 849 */         if (this.y[i] > 0) {
/* 850 */           ub = Math.min(ub, yG);
/*     */         } else {
/* 852 */           lb = Math.max(lb, yG);
/*     */         } 
/* 854 */       } else if (is_upper_bound(i)) {
/*     */         
/* 856 */         if (this.y[i] < 0) {
/* 857 */           ub = Math.min(ub, yG);
/*     */         } else {
/* 859 */           lb = Math.max(lb, yG);
/*     */         } 
/*     */       } else {
/*     */         
/* 863 */         nr_free++;
/* 864 */         sum_free += yG;
/*     */       } 
/*     */     } 
/*     */     
/* 868 */     if (nr_free > 0) {
/* 869 */       r = sum_free / nr_free;
/*     */     } else {
/* 871 */       r = (ub + lb) / 2.0D;
/*     */     } 
/* 873 */     return r;
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\Solver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */