package libsvm;

public interface svm_print_interface {
  void print(String paramString);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\svm_print_interface.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */