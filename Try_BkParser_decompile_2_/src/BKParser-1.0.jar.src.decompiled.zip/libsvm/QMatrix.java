package libsvm;

abstract class QMatrix {
  abstract float[] get_Q(int paramInt1, int paramInt2);
  
  abstract double[] get_QD();
  
  abstract void swap_index(int paramInt1, int paramInt2);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\QMatrix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */