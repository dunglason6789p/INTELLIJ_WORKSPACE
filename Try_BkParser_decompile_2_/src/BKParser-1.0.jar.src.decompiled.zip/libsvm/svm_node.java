package libsvm;

import java.io.Serializable;

public class svm_node implements Serializable {
  public int index;
  
  public double value;
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\svm_node.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */