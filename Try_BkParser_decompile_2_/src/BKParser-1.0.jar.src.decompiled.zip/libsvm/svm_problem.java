package libsvm;

import java.io.Serializable;

public class svm_problem implements Serializable {
  public int l;
  
  public double[] y;
  
  public svm_node[][] x;
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\svm_problem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */