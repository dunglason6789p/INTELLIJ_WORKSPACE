package libsvm;

import java.io.Serializable;

public class svm_model implements Serializable {
  public svm_parameter param;
  
  public int nr_class;
  
  public int l;
  
  public svm_node[][] SV;
  
  public double[][] sv_coef;
  
  public double[] rho;
  
  public double[] probA;
  
  public double[] probB;
  
  public int[] label;
  
  public int[] nSV;
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\svm_model.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */