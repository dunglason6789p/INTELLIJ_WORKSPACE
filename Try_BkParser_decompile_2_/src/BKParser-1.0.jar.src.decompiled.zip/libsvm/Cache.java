/*     */ package libsvm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Cache
/*     */ {
/*     */   private final int l;
/*     */   private long size;
/*     */   private final head_t[] head;
/*     */   private head_t lru_head;
/*     */   
/*     */   private final class head_t
/*     */   {
/*     */     head_t prev;
/*     */     head_t next;
/*     */     float[] data;
/*     */     int len;
/*     */     
/*     */     private head_t() {}
/*     */   }
/*     */   
/*     */   Cache(int l_, long size_) {
/*  29 */     this.l = l_;
/*  30 */     this.size = size_;
/*  31 */     this.head = new head_t[this.l];
/*  32 */     for (int i = 0; i < this.l; ) { this.head[i] = new head_t(null); i++; }
/*  33 */      this.size /= 4L;
/*  34 */     this.size -= (this.l * 4);
/*  35 */     this.size = Math.max(this.size, 2L * this.l);
/*  36 */     this.lru_head = new head_t(null);
/*  37 */     this.lru_head.next = this.lru_head.prev = this.lru_head;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void lru_delete(head_t h) {
/*  43 */     h.prev.next = h.next;
/*  44 */     h.next.prev = h.prev;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void lru_insert(head_t h) {
/*  50 */     h.next = this.lru_head;
/*  51 */     h.prev = this.lru_head.prev;
/*  52 */     h.prev.next = h;
/*  53 */     h.next.prev = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int get_data(int index, float[][] data, int len) {
/*  62 */     head_t h = this.head[index];
/*  63 */     if (h.len > 0) lru_delete(h); 
/*  64 */     int more = len - h.len;
/*     */     
/*  66 */     if (more > 0) {
/*     */ 
/*     */       
/*  69 */       while (this.size < more) {
/*     */         
/*  71 */         head_t old = this.lru_head.next;
/*  72 */         lru_delete(old);
/*  73 */         this.size += old.len;
/*  74 */         old.data = null;
/*  75 */         old.len = 0;
/*     */       } 
/*     */ 
/*     */       
/*  79 */       float[] new_data = new float[len];
/*  80 */       if (h.data != null) System.arraycopy(h.data, 0, new_data, 0, h.len); 
/*  81 */       h.data = new_data;
/*  82 */       this.size -= more;
/*  83 */       int _ = h.len; h.len = len; len = _;
/*     */     } 
/*     */     
/*  86 */     lru_insert(h);
/*  87 */     data[0] = h.data;
/*  88 */     return len;
/*     */   }
/*     */ 
/*     */   
/*     */   void swap_index(int i, int j) {
/*  93 */     if (i == j)
/*     */       return; 
/*  95 */     if ((this.head[i]).len > 0) lru_delete(this.head[i]); 
/*  96 */     if ((this.head[j]).len > 0) lru_delete(this.head[j]); 
/*  97 */     float[] _ = (this.head[i]).data; (this.head[i]).data = (this.head[j]).data; (this.head[j]).data = _;
/*  98 */     int _ = (this.head[i]).len; (this.head[i]).len = (this.head[j]).len; (this.head[j]).len = _;
/*  99 */     if ((this.head[i]).len > 0) lru_insert(this.head[i]); 
/* 100 */     if ((this.head[j]).len > 0) lru_insert(this.head[j]);
/*     */     
/* 102 */     if (i > j) { int _ = i; i = j; j = _; }
/* 103 */      for (head_t h = this.lru_head.next; h != this.lru_head; h = h.next) {
/*     */       
/* 105 */       if (h.len > i)
/*     */       {
/* 107 */         if (h.len > j) {
/* 108 */           float _ = h.data[i]; h.data[i] = h.data[j]; h.data[j] = _;
/*     */         }
/*     */         else {
/*     */           
/* 112 */           lru_delete(h);
/* 113 */           this.size += h.len;
/* 114 */           h.data = null;
/* 115 */           h.len = 0;
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\Cache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */