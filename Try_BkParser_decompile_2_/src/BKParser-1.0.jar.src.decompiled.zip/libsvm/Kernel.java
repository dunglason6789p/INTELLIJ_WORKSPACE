/*     */ package libsvm;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Kernel
/*     */   extends QMatrix
/*     */ {
/*     */   private svm_node[][] x;
/*     */   private final double[] x_square;
/*     */   private final int kernel_type;
/*     */   private final int degree;
/*     */   private final double gamma;
/*     */   private final double coef0;
/*     */   
/*     */   abstract float[] get_Q(int paramInt1, int paramInt2);
/*     */   
/*     */   abstract double[] get_QD();
/*     */   
/*     */   void swap_index(int i, int j) {
/* 150 */     svm_node[] _ = this.x[i]; this.x[i] = this.x[j]; this.x[j] = _;
/* 151 */     if (this.x_square != null) { double _ = this.x_square[i]; this.x_square[i] = this.x_square[j]; this.x_square[j] = _; }
/*     */   
/*     */   }
/*     */   
/*     */   private static double powi(double base, int times) {
/* 156 */     double tmp = base, ret = 1.0D;
/*     */     int t;
/* 158 */     for (t = times; t > 0; t /= 2) {
/*     */       
/* 160 */       if (t % 2 == 1) ret *= tmp; 
/* 161 */       tmp *= tmp;
/*     */     } 
/* 163 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   double kernel_function(int i, int j) {
/* 168 */     switch (this.kernel_type) {
/*     */       
/*     */       case 0:
/* 171 */         return dot(this.x[i], this.x[j]);
/*     */       case 1:
/* 173 */         return powi(this.gamma * dot(this.x[i], this.x[j]) + this.coef0, this.degree);
/*     */       case 2:
/* 175 */         return Math.exp(-this.gamma * (this.x_square[i] + this.x_square[j] - 2.0D * dot(this.x[i], this.x[j])));
/*     */       case 3:
/* 177 */         return Math.tanh(this.gamma * dot(this.x[i], this.x[j]) + this.coef0);
/*     */       case 4:
/* 179 */         return (this.x[i][(int)(this.x[j][0]).value]).value;
/*     */     } 
/* 181 */     return 0.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Kernel(int l, svm_node[][] x_, svm_parameter param) {
/* 187 */     this.kernel_type = param.kernel_type;
/* 188 */     this.degree = param.degree;
/* 189 */     this.gamma = param.gamma;
/* 190 */     this.coef0 = param.coef0;
/*     */     
/* 192 */     this.x = (svm_node[][])x_.clone();
/*     */     
/* 194 */     if (this.kernel_type == 2) {
/*     */       
/* 196 */       this.x_square = new double[l];
/* 197 */       for (int i = 0; i < l; i++)
/* 198 */         this.x_square[i] = dot(this.x[i], this.x[i]); 
/*     */     } else {
/* 200 */       this.x_square = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   static double dot(svm_node[] x, svm_node[] y) {
/* 205 */     double sum = 0.0D;
/* 206 */     int xlen = x.length;
/* 207 */     int ylen = y.length;
/* 208 */     int i = 0;
/* 209 */     int j = 0;
/* 210 */     while (i < xlen && j < ylen) {
/*     */       
/* 212 */       if ((x[i]).index == (y[j]).index) {
/* 213 */         sum += (x[i++]).value * (y[j++]).value;
/*     */         continue;
/*     */       } 
/* 216 */       if ((x[i]).index > (y[j]).index) {
/* 217 */         j++; continue;
/*     */       } 
/* 219 */       i++;
/*     */     } 
/*     */     
/* 222 */     return sum; } static double k_function(svm_node[] x, svm_node[] y, svm_parameter param) {
/*     */     int j;
/*     */     int i;
/*     */     int ylen;
/*     */     int xlen;
/*     */     double sum;
/* 228 */     switch (param.kernel_type) {
/*     */       
/*     */       case 0:
/* 231 */         return dot(x, y);
/*     */       case 1:
/* 233 */         return powi(param.gamma * dot(x, y) + param.coef0, param.degree);
/*     */       
/*     */       case 2:
/* 236 */         sum = 0.0D;
/* 237 */         xlen = x.length;
/* 238 */         ylen = y.length;
/* 239 */         i = 0;
/* 240 */         j = 0;
/* 241 */         while (i < xlen && j < ylen) {
/*     */           
/* 243 */           if ((x[i]).index == (y[j]).index) {
/*     */             
/* 245 */             double d = (x[i++]).value - (y[j++]).value;
/* 246 */             sum += d * d; continue;
/*     */           } 
/* 248 */           if ((x[i]).index > (y[j]).index) {
/*     */             
/* 250 */             sum += (y[j]).value * (y[j]).value;
/* 251 */             j++;
/*     */             
/*     */             continue;
/*     */           } 
/* 255 */           sum += (x[i]).value * (x[i]).value;
/* 256 */           i++;
/*     */         } 
/*     */ 
/*     */         
/* 260 */         while (i < xlen) {
/*     */           
/* 262 */           sum += (x[i]).value * (x[i]).value;
/* 263 */           i++;
/*     */         } 
/*     */         
/* 266 */         while (j < ylen) {
/*     */           
/* 268 */           sum += (y[j]).value * (y[j]).value;
/* 269 */           j++;
/*     */         } 
/*     */         
/* 272 */         return Math.exp(-param.gamma * sum);
/*     */       
/*     */       case 3:
/* 275 */         return Math.tanh(param.gamma * dot(x, y) + param.coef0);
/*     */       case 4:
/* 277 */         return (x[(int)(y[0]).value]).value;
/*     */     } 
/* 279 */     return 0.0D;
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\Kernel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */