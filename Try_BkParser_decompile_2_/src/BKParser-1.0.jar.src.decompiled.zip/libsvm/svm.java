/*      */ package libsvm;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.util.Random;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class svm
/*      */ {
/*      */   public static final int LIBSVM_VERSION = 310;
/* 1283 */   public static final Random rand = new Random();
/*      */   
/* 1285 */   private static svm_print_interface svm_print_stdout = new svm_print_interface()
/*      */     {
/*      */       public void print(String s)
/*      */       {
/* 1289 */         System.out.print(s);
/* 1290 */         System.out.flush();
/*      */       }
/*      */     };
/*      */   
/* 1294 */   private static svm_print_interface svm_print_string = svm_print_stdout;
/*      */ 
/*      */ 
/*      */   
/* 1298 */   static void info(String s) { svm_print_string.print(s); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void solve_c_svc(svm_problem prob, svm_parameter param, double[] alpha, Solver.SolutionInfo si, double Cp, double Cn) {
/* 1305 */     int l = prob.l;
/* 1306 */     double[] minus_ones = new double[l];
/* 1307 */     byte[] y = new byte[l];
/*      */     
/*      */     int i;
/*      */     
/* 1311 */     for (i = 0; i < l; i++) {
/*      */       
/* 1313 */       alpha[i] = 0.0D;
/* 1314 */       minus_ones[i] = -1.0D;
/* 1315 */       if (prob.y[i] > 0.0D) { y[i] = 1; } else { y[i] = -1; }
/*      */     
/*      */     } 
/* 1318 */     Solver s = new Solver();
/* 1319 */     s.Solve(l, new SVC_Q(prob, param, y), minus_ones, y, alpha, Cp, Cn, param.eps, si, param.shrinking);
/*      */ 
/*      */     
/* 1322 */     double sum_alpha = 0.0D;
/* 1323 */     for (i = 0; i < l; i++) {
/* 1324 */       sum_alpha += alpha[i];
/*      */     }
/* 1326 */     if (Cp == Cn) {
/* 1327 */       info("nu = " + (sum_alpha / Cp * prob.l) + "\n");
/*      */     }
/* 1329 */     for (i = 0; i < l; i++) {
/* 1330 */       alpha[i] = alpha[i] * y[i];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void solve_nu_svc(svm_problem prob, svm_parameter param, double[] alpha, Solver.SolutionInfo si) {
/* 1337 */     int l = prob.l;
/* 1338 */     double nu = param.nu;
/*      */     
/* 1340 */     byte[] y = new byte[l];
/*      */     int i;
/* 1342 */     for (i = 0; i < l; i++) {
/* 1343 */       if (prob.y[i] > 0.0D) {
/* 1344 */         y[i] = 1;
/*      */       } else {
/* 1346 */         y[i] = -1;
/*      */       } 
/* 1348 */     }  double sum_pos = nu * l / 2.0D;
/* 1349 */     double sum_neg = nu * l / 2.0D;
/*      */     
/* 1351 */     for (i = 0; i < l; i++) {
/* 1352 */       if (y[i] == 1) {
/*      */         
/* 1354 */         alpha[i] = Math.min(1.0D, sum_pos);
/* 1355 */         sum_pos -= alpha[i];
/*      */       }
/*      */       else {
/*      */         
/* 1359 */         alpha[i] = Math.min(1.0D, sum_neg);
/* 1360 */         sum_neg -= alpha[i];
/*      */       } 
/*      */     } 
/* 1363 */     double[] zeros = new double[l];
/*      */     
/* 1365 */     for (i = 0; i < l; i++) {
/* 1366 */       zeros[i] = 0.0D;
/*      */     }
/* 1368 */     Solver_NU s = new Solver_NU();
/* 1369 */     s.Solve(l, new SVC_Q(prob, param, y), zeros, y, alpha, 1.0D, 1.0D, param.eps, si, param.shrinking);
/*      */     
/* 1371 */     double r = si.r;
/*      */     
/* 1373 */     info("C = " + (1.0D / r) + "\n");
/*      */     
/* 1375 */     for (i = 0; i < l; i++) {
/* 1376 */       alpha[i] = alpha[i] * y[i] / r;
/*      */     }
/* 1378 */     si.rho /= r;
/* 1379 */     si.obj /= r * r;
/* 1380 */     si.upper_bound_p = 1.0D / r;
/* 1381 */     si.upper_bound_n = 1.0D / r;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void solve_one_class(svm_problem prob, svm_parameter param, double[] alpha, Solver.SolutionInfo si) {
/* 1387 */     int l = prob.l;
/* 1388 */     double[] zeros = new double[l];
/* 1389 */     byte[] ones = new byte[l];
/*      */ 
/*      */     
/* 1392 */     int n = (int)(param.nu * prob.l);
/*      */     int i;
/* 1394 */     for (i = 0; i < n; i++)
/* 1395 */       alpha[i] = 1.0D; 
/* 1396 */     if (n < prob.l)
/* 1397 */       alpha[n] = param.nu * prob.l - n; 
/* 1398 */     for (i = n + 1; i < l; i++) {
/* 1399 */       alpha[i] = 0.0D;
/*      */     }
/* 1401 */     for (i = 0; i < l; i++) {
/*      */       
/* 1403 */       zeros[i] = 0.0D;
/* 1404 */       ones[i] = 1;
/*      */     } 
/*      */     
/* 1407 */     Solver s = new Solver();
/* 1408 */     s.Solve(l, new ONE_CLASS_Q(prob, param), zeros, ones, alpha, 1.0D, 1.0D, param.eps, si, param.shrinking);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void solve_epsilon_svr(svm_problem prob, svm_parameter param, double[] alpha, Solver.SolutionInfo si) {
/* 1415 */     int l = prob.l;
/* 1416 */     double[] alpha2 = new double[2 * l];
/* 1417 */     double[] linear_term = new double[2 * l];
/* 1418 */     byte[] y = new byte[2 * l];
/*      */     
/*      */     int i;
/* 1421 */     for (i = 0; i < l; i++) {
/*      */       
/* 1423 */       alpha2[i] = 0.0D;
/* 1424 */       linear_term[i] = param.p - prob.y[i];
/* 1425 */       y[i] = 1;
/*      */       
/* 1427 */       alpha2[i + l] = 0.0D;
/* 1428 */       linear_term[i + l] = param.p + prob.y[i];
/* 1429 */       y[i + l] = -1;
/*      */     } 
/*      */     
/* 1432 */     Solver s = new Solver();
/* 1433 */     s.Solve(2 * l, new SVR_Q(prob, param), linear_term, y, alpha2, param.C, param.C, param.eps, si, param.shrinking);
/*      */ 
/*      */     
/* 1436 */     double sum_alpha = 0.0D;
/* 1437 */     for (i = 0; i < l; i++) {
/*      */       
/* 1439 */       alpha[i] = alpha2[i] - alpha2[i + l];
/* 1440 */       sum_alpha += Math.abs(alpha[i]);
/*      */     } 
/* 1442 */     info("nu = " + (sum_alpha / param.C * l) + "\n");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void solve_nu_svr(svm_problem prob, svm_parameter param, double[] alpha, Solver.SolutionInfo si) {
/* 1448 */     int l = prob.l;
/* 1449 */     double C = param.C;
/* 1450 */     double[] alpha2 = new double[2 * l];
/* 1451 */     double[] linear_term = new double[2 * l];
/* 1452 */     byte[] y = new byte[2 * l];
/*      */ 
/*      */     
/* 1455 */     double sum = C * param.nu * l / 2.0D; int i;
/* 1456 */     for (i = 0; i < l; i++) {
/*      */       
/* 1458 */       alpha2[i + l] = Math.min(sum, C); alpha2[i] = Math.min(sum, C);
/* 1459 */       sum -= alpha2[i];
/*      */       
/* 1461 */       linear_term[i] = -prob.y[i];
/* 1462 */       y[i] = 1;
/*      */       
/* 1464 */       linear_term[i + l] = prob.y[i];
/* 1465 */       y[i + l] = -1;
/*      */     } 
/*      */     
/* 1468 */     Solver_NU s = new Solver_NU();
/* 1469 */     s.Solve(2 * l, new SVR_Q(prob, param), linear_term, y, alpha2, C, C, param.eps, si, param.shrinking);
/*      */ 
/*      */     
/* 1472 */     info("epsilon = " + -si.r + "\n");
/*      */     
/* 1474 */     for (i = 0; i < l; i++) {
/* 1475 */       alpha[i] = alpha2[i] - alpha2[i + l];
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static class decision_function
/*      */   {
/*      */     double[] alpha;
/*      */ 
/*      */     
/*      */     double rho;
/*      */   }
/*      */ 
/*      */   
/*      */   static decision_function svm_train_one(svm_problem prob, svm_parameter param, double Cp, double Cn) {
/* 1491 */     double[] alpha = new double[prob.l];
/* 1492 */     Solver.SolutionInfo si = new Solver.SolutionInfo();
/* 1493 */     switch (param.svm_type) {
/*      */       
/*      */       case 0:
/* 1496 */         solve_c_svc(prob, param, alpha, si, Cp, Cn);
/*      */         break;
/*      */       case 1:
/* 1499 */         solve_nu_svc(prob, param, alpha, si);
/*      */         break;
/*      */       case 2:
/* 1502 */         solve_one_class(prob, param, alpha, si);
/*      */         break;
/*      */       case 3:
/* 1505 */         solve_epsilon_svr(prob, param, alpha, si);
/*      */         break;
/*      */       case 4:
/* 1508 */         solve_nu_svr(prob, param, alpha, si);
/*      */         break;
/*      */     } 
/*      */     
/* 1512 */     info("obj = " + si.obj + ", rho = " + si.rho + "\n");
/*      */ 
/*      */ 
/*      */     
/* 1516 */     int nSV = 0;
/* 1517 */     int nBSV = 0;
/* 1518 */     for (int i = 0; i < prob.l; i++) {
/*      */       
/* 1520 */       if (Math.abs(alpha[i]) > 0.0D) {
/*      */         
/* 1522 */         nSV++;
/* 1523 */         if (prob.y[i] > 0.0D) {
/*      */           
/* 1525 */           if (Math.abs(alpha[i]) >= si.upper_bound_p) {
/* 1526 */             nBSV++;
/*      */           
/*      */           }
/*      */         }
/* 1530 */         else if (Math.abs(alpha[i]) >= si.upper_bound_n) {
/* 1531 */           nBSV++;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1536 */     info("nSV = " + nSV + ", nBSV = " + nBSV + "\n");
/*      */     
/* 1538 */     decision_function f = new decision_function();
/* 1539 */     f.alpha = alpha;
/* 1540 */     f.rho = si.rho;
/* 1541 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void sigmoid_train(int l, double[] dec_values, double[] labels, double[] probAB) {
/* 1549 */     double prior1 = 0.0D, prior0 = 0.0D;
/*      */     
/*      */     int i;
/* 1552 */     for (i = 0; i < l; i++) {
/* 1553 */       if (labels[i] > 0.0D) { prior1++; }
/* 1554 */       else { prior0++; }
/*      */     
/* 1556 */     }  int max_iter = 100;
/* 1557 */     double min_step = 1.0E-10D;
/* 1558 */     double sigma = 1.0E-12D;
/* 1559 */     double eps = 1.0E-5D;
/* 1560 */     double hiTarget = (prior1 + 1.0D) / (prior1 + 2.0D);
/* 1561 */     double loTarget = 1.0D / (prior0 + 2.0D);
/* 1562 */     double[] t = new double[l];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1568 */     double A = 0.0D, B = Math.log((prior0 + 1.0D) / (prior1 + 1.0D));
/* 1569 */     double fval = 0.0D;
/*      */     
/* 1571 */     for (i = 0; i < l; i++) {
/*      */       
/* 1573 */       if (labels[i] > 0.0D) { t[i] = hiTarget; }
/* 1574 */       else { t[i] = loTarget; }
/* 1575 */        double fApB = dec_values[i] * A + B;
/* 1576 */       if (fApB >= 0.0D) {
/* 1577 */         fval += t[i] * fApB + Math.log(1.0D + Math.exp(-fApB));
/*      */       } else {
/* 1579 */         fval += (t[i] - 1.0D) * fApB + Math.log(1.0D + Math.exp(fApB));
/*      */       } 
/* 1581 */     }  int iter; for (iter = 0; iter < max_iter; iter++) {
/*      */ 
/*      */       
/* 1584 */       double h11 = sigma;
/* 1585 */       double h22 = sigma;
/* 1586 */       double h21 = 0.0D, g1 = 0.0D, g2 = 0.0D;
/* 1587 */       for (i = 0; i < l; i++) {
/*      */         
/* 1589 */         double q, p, fApB = dec_values[i] * A + B;
/* 1590 */         if (fApB >= 0.0D) {
/*      */           
/* 1592 */           p = Math.exp(-fApB) / (1.0D + Math.exp(-fApB));
/* 1593 */           q = 1.0D / (1.0D + Math.exp(-fApB));
/*      */         }
/*      */         else {
/*      */           
/* 1597 */           p = 1.0D / (1.0D + Math.exp(fApB));
/* 1598 */           q = Math.exp(fApB) / (1.0D + Math.exp(fApB));
/*      */         } 
/* 1600 */         double d2 = p * q;
/* 1601 */         h11 += dec_values[i] * dec_values[i] * d2;
/* 1602 */         h22 += d2;
/* 1603 */         h21 += dec_values[i] * d2;
/* 1604 */         double d1 = t[i] - p;
/* 1605 */         g1 += dec_values[i] * d1;
/* 1606 */         g2 += d1;
/*      */       } 
/*      */ 
/*      */       
/* 1610 */       if (Math.abs(g1) < eps && Math.abs(g2) < eps) {
/*      */         break;
/*      */       }
/*      */       
/* 1614 */       double det = h11 * h22 - h21 * h21;
/* 1615 */       double dA = -(h22 * g1 - h21 * g2) / det;
/* 1616 */       double dB = -(-h21 * g1 + h11 * g2) / det;
/* 1617 */       double gd = g1 * dA + g2 * dB;
/*      */ 
/*      */       
/* 1620 */       double stepsize = 1.0D;
/* 1621 */       while (stepsize >= min_step) {
/*      */         
/* 1623 */         double newA = A + stepsize * dA;
/* 1624 */         double newB = B + stepsize * dB;
/*      */ 
/*      */         
/* 1627 */         double newf = 0.0D;
/* 1628 */         for (i = 0; i < l; i++) {
/*      */           
/* 1630 */           double fApB = dec_values[i] * newA + newB;
/* 1631 */           if (fApB >= 0.0D) {
/* 1632 */             newf += t[i] * fApB + Math.log(1.0D + Math.exp(-fApB));
/*      */           } else {
/* 1634 */             newf += (t[i] - 1.0D) * fApB + Math.log(1.0D + Math.exp(fApB));
/*      */           } 
/*      */         } 
/* 1637 */         if (newf < fval + 1.0E-4D * stepsize * gd) {
/*      */           
/* 1639 */           A = newA; B = newB; fval = newf;
/*      */           
/*      */           break;
/*      */         } 
/* 1643 */         stepsize /= 2.0D;
/*      */       } 
/*      */       
/* 1646 */       if (stepsize < min_step) {
/*      */         
/* 1648 */         info("Line search fails in two-class probability estimates\n");
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1653 */     if (iter >= max_iter)
/* 1654 */       info("Reaching maximal iterations in two-class probability estimates\n"); 
/* 1655 */     probAB[0] = A; probAB[1] = B;
/*      */   }
/*      */ 
/*      */   
/*      */   private static double sigmoid_predict(double decision_value, double A, double B) {
/* 1660 */     double fApB = decision_value * A + B;
/* 1661 */     if (fApB >= 0.0D) {
/* 1662 */       return Math.exp(-fApB) / (1.0D + Math.exp(-fApB));
/*      */     }
/* 1664 */     return 1.0D / (1.0D + Math.exp(fApB));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void multiclass_probability(int k, double[][] r, double[] p) {
/* 1671 */     int iter = 0, max_iter = Math.max(100, k);
/* 1672 */     double[][] Q = new double[k][k];
/* 1673 */     double[] Qp = new double[k];
/* 1674 */     double eps = 0.005D / k;
/*      */     int t;
/* 1676 */     for (t = 0; t < k; t++) {
/*      */       
/* 1678 */       p[t] = 1.0D / k;
/* 1679 */       Q[t][t] = 0.0D; int j;
/* 1680 */       for (j = 0; j < t; j++) {
/*      */         
/* 1682 */         Q[t][t] = Q[t][t] + r[j][t] * r[j][t];
/* 1683 */         Q[t][j] = Q[j][t];
/*      */       } 
/* 1685 */       for (j = t + 1; j < k; j++) {
/*      */         
/* 1687 */         Q[t][t] = Q[t][t] + r[j][t] * r[j][t];
/* 1688 */         Q[t][j] = -r[j][t] * r[t][j];
/*      */       } 
/*      */     } 
/* 1691 */     for (iter = 0; iter < max_iter; iter++) {
/*      */ 
/*      */       
/* 1694 */       double pQp = 0.0D;
/* 1695 */       for (t = 0; t < k; t++) {
/*      */         
/* 1697 */         Qp[t] = 0.0D;
/* 1698 */         for (int j = 0; j < k; j++)
/* 1699 */           Qp[t] = Qp[t] + Q[t][j] * p[j]; 
/* 1700 */         pQp += p[t] * Qp[t];
/*      */       } 
/* 1702 */       double max_error = 0.0D;
/* 1703 */       for (t = 0; t < k; t++) {
/*      */         
/* 1705 */         double error = Math.abs(Qp[t] - pQp);
/* 1706 */         if (error > max_error)
/* 1707 */           max_error = error; 
/*      */       } 
/* 1709 */       if (max_error < eps)
/*      */         break; 
/* 1711 */       for (t = 0; t < k; t++) {
/*      */         
/* 1713 */         double diff = (-Qp[t] + pQp) / Q[t][t];
/* 1714 */         p[t] = p[t] + diff;
/* 1715 */         pQp = (pQp + diff * (diff * Q[t][t] + 2.0D * Qp[t])) / (1.0D + diff) / (1.0D + diff);
/* 1716 */         for (int j = 0; j < k; j++) {
/*      */           
/* 1718 */           Qp[j] = (Qp[j] + diff * Q[t][j]) / (1.0D + diff);
/* 1719 */           p[j] = p[j] / (1.0D + diff);
/*      */         } 
/*      */       } 
/*      */     } 
/* 1723 */     if (iter >= max_iter) {
/* 1724 */       info("Exceeds max_iter in multiclass_prob\n");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static void svm_binary_svc_probability(svm_problem prob, svm_parameter param, double Cp, double Cn, double[] probAB) {
/* 1731 */     int nr_fold = 5;
/* 1732 */     int[] perm = new int[prob.l];
/* 1733 */     double[] dec_values = new double[prob.l];
/*      */     
/*      */     int i;
/* 1736 */     for (i = 0; i < prob.l; ) { perm[i] = i; i++; }
/* 1737 */      for (i = 0; i < prob.l; i++) {
/*      */       
/* 1739 */       int j = i + rand.nextInt(prob.l - i);
/* 1740 */       int _ = perm[i]; perm[i] = perm[j]; perm[j] = _;
/*      */     } 
/* 1742 */     for (i = 0; i < nr_fold; i++) {
/*      */       
/* 1744 */       int begin = i * prob.l / nr_fold;
/* 1745 */       int end = (i + 1) * prob.l / nr_fold;
/*      */       
/* 1747 */       svm_problem subprob = new svm_problem();
/*      */       
/* 1749 */       prob.l -= end - begin;
/* 1750 */       subprob.x = new svm_node[subprob.l][];
/* 1751 */       subprob.y = new double[subprob.l];
/*      */       
/* 1753 */       int k = 0; int j;
/* 1754 */       for (j = 0; j < begin; j++) {
/*      */         
/* 1756 */         subprob.x[k] = prob.x[perm[j]];
/* 1757 */         subprob.y[k] = prob.y[perm[j]];
/* 1758 */         k++;
/*      */       } 
/* 1760 */       for (j = end; j < prob.l; j++) {
/*      */         
/* 1762 */         subprob.x[k] = prob.x[perm[j]];
/* 1763 */         subprob.y[k] = prob.y[perm[j]];
/* 1764 */         k++;
/*      */       } 
/* 1766 */       int p_count = 0, n_count = 0;
/* 1767 */       for (j = 0; j < k; j++) {
/* 1768 */         if (subprob.y[j] > 0.0D) {
/* 1769 */           p_count++;
/*      */         } else {
/* 1771 */           n_count++;
/*      */         } 
/* 1773 */       }  if (p_count == 0 && n_count == 0) {
/* 1774 */         for (j = begin; j < end; j++)
/* 1775 */           dec_values[perm[j]] = 0.0D; 
/* 1776 */       } else if (p_count > 0 && n_count == 0) {
/* 1777 */         for (j = begin; j < end; j++)
/* 1778 */           dec_values[perm[j]] = 1.0D; 
/* 1779 */       } else if (p_count == 0 && n_count > 0) {
/* 1780 */         for (j = begin; j < end; j++) {
/* 1781 */           dec_values[perm[j]] = -1.0D;
/*      */         }
/*      */       } else {
/* 1784 */         svm_parameter subparam = (svm_parameter)param.clone();
/* 1785 */         subparam.probability = 0;
/* 1786 */         subparam.C = 1.0D;
/* 1787 */         subparam.nr_weight = 2;
/* 1788 */         subparam.weight_label = new int[2];
/* 1789 */         subparam.weight = new double[2];
/* 1790 */         subparam.weight_label[0] = 1;
/* 1791 */         subparam.weight_label[1] = -1;
/* 1792 */         subparam.weight[0] = Cp;
/* 1793 */         subparam.weight[1] = Cn;
/* 1794 */         svm_model submodel = svm_train(subprob, subparam);
/* 1795 */         for (j = begin; j < end; j++) {
/*      */           
/* 1797 */           double[] dec_value = new double[1];
/* 1798 */           svm_predict_values(submodel, prob.x[perm[j]], dec_value);
/* 1799 */           dec_values[perm[j]] = dec_value[0];
/*      */           
/* 1801 */           dec_values[perm[j]] = dec_values[perm[j]] * submodel.label[0];
/*      */         } 
/*      */       } 
/*      */     } 
/* 1805 */     sigmoid_train(prob.l, dec_values, prob.y, probAB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double svm_svr_probability(svm_problem prob, svm_parameter param) {
/* 1812 */     int nr_fold = 5;
/* 1813 */     double[] ymv = new double[prob.l];
/* 1814 */     double mae = 0.0D;
/*      */     
/* 1816 */     svm_parameter newparam = (svm_parameter)param.clone();
/* 1817 */     newparam.probability = 0;
/* 1818 */     svm_cross_validation(prob, newparam, nr_fold, ymv); int i;
/* 1819 */     for (i = 0; i < prob.l; i++) {
/*      */       
/* 1821 */       ymv[i] = prob.y[i] - ymv[i];
/* 1822 */       mae += Math.abs(ymv[i]);
/*      */     } 
/* 1824 */     mae /= prob.l;
/* 1825 */     double std = Math.sqrt(2.0D * mae * mae);
/* 1826 */     int count = 0;
/* 1827 */     mae = 0.0D;
/* 1828 */     for (i = 0; i < prob.l; i++) {
/* 1829 */       if (Math.abs(ymv[i]) > 5.0D * std)
/* 1830 */       { count++; }
/*      */       else
/* 1832 */       { mae += Math.abs(ymv[i]); } 
/* 1833 */     }  mae /= (prob.l - count);
/* 1834 */     info("Prob. model for test data: target value = predicted value + z,\nz: Laplace distribution e^(-|z|/sigma)/(2sigma),sigma=" + mae + "\n");
/* 1835 */     return mae;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void svm_group_classes(svm_problem prob, int[] nr_class_ret, int[][] label_ret, int[][] start_ret, int[][] count_ret, int[] perm) {
/* 1842 */     int l = prob.l;
/* 1843 */     int max_nr_class = 16;
/* 1844 */     int nr_class = 0;
/* 1845 */     int[] label = new int[max_nr_class];
/* 1846 */     int[] count = new int[max_nr_class];
/* 1847 */     int[] data_label = new int[l];
/*      */     
/*      */     int i;
/* 1850 */     for (i = 0; i < l; i++) {
/*      */       
/* 1852 */       int this_label = (int)prob.y[i];
/*      */       int j;
/* 1854 */       for (j = 0; j < nr_class; j++) {
/*      */         
/* 1856 */         if (this_label == label[j]) {
/*      */           
/* 1858 */           count[j] = count[j] + 1;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1862 */       data_label[i] = j;
/* 1863 */       if (j == nr_class) {
/*      */         
/* 1865 */         if (nr_class == max_nr_class) {
/*      */           
/* 1867 */           max_nr_class *= 2;
/* 1868 */           int[] new_data = new int[max_nr_class];
/* 1869 */           System.arraycopy(label, 0, new_data, 0, label.length);
/* 1870 */           label = new_data;
/* 1871 */           new_data = new int[max_nr_class];
/* 1872 */           System.arraycopy(count, 0, new_data, 0, count.length);
/* 1873 */           count = new_data;
/*      */         } 
/* 1875 */         label[nr_class] = this_label;
/* 1876 */         count[nr_class] = 1;
/* 1877 */         nr_class++;
/*      */       } 
/*      */     } 
/*      */     
/* 1881 */     int[] start = new int[nr_class];
/* 1882 */     start[0] = 0;
/* 1883 */     for (i = 1; i < nr_class; i++)
/* 1884 */       start[i] = start[i - 1] + count[i - 1]; 
/* 1885 */     for (i = 0; i < l; i++) {
/*      */       
/* 1887 */       perm[start[data_label[i]]] = i;
/* 1888 */       start[data_label[i]] = start[data_label[i]] + 1;
/*      */     } 
/* 1890 */     start[0] = 0;
/* 1891 */     for (i = 1; i < nr_class; i++) {
/* 1892 */       start[i] = start[i - 1] + count[i - 1];
/*      */     }
/* 1894 */     nr_class_ret[0] = nr_class;
/* 1895 */     label_ret[0] = label;
/* 1896 */     start_ret[0] = start;
/* 1897 */     count_ret[0] = count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static svm_model svm_train(svm_problem prob, svm_parameter param) {
/* 1905 */     svm_model model = new svm_model();
/* 1906 */     model.param = param;
/*      */     
/* 1908 */     if (param.svm_type == 2 || param.svm_type == 3 || param.svm_type == 4) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1913 */       model.nr_class = 2;
/* 1914 */       model.label = null;
/* 1915 */       model.nSV = null;
/* 1916 */       model.probA = null; model.probB = null;
/* 1917 */       model.sv_coef = new double[1][];
/*      */       
/* 1919 */       if (param.probability == 1 && (param.svm_type == 3 || param.svm_type == 4)) {
/*      */ 
/*      */ 
/*      */         
/* 1923 */         model.probA = new double[1];
/* 1924 */         model.probA[0] = svm_svr_probability(prob, param);
/*      */       } 
/*      */       
/* 1927 */       decision_function f = svm_train_one(prob, param, 0.0D, 0.0D);
/* 1928 */       model.rho = new double[1];
/* 1929 */       model.rho[0] = f.rho;
/*      */       
/* 1931 */       int nSV = 0;
/*      */       int i;
/* 1933 */       for (i = 0; i < prob.l; i++) {
/* 1934 */         if (Math.abs(f.alpha[i]) > 0.0D) nSV++; 
/* 1935 */       }  model.l = nSV;
/* 1936 */       model.SV = new svm_node[nSV][];
/* 1937 */       model.sv_coef[0] = new double[nSV];
/* 1938 */       int j = 0;
/* 1939 */       for (i = 0; i < prob.l; i++) {
/* 1940 */         if (Math.abs(f.alpha[i]) > 0.0D)
/*      */         {
/* 1942 */           model.SV[j] = prob.x[i];
/* 1943 */           model.sv_coef[0][j] = f.alpha[i];
/* 1944 */           j++;
/*      */         }
/*      */       
/*      */       } 
/*      */     } else {
/*      */       
/* 1950 */       int l = prob.l;
/* 1951 */       int[] tmp_nr_class = new int[1];
/* 1952 */       int[][] tmp_label = new int[1][];
/* 1953 */       int[][] tmp_start = new int[1][];
/* 1954 */       int[][] tmp_count = new int[1][];
/* 1955 */       int[] perm = new int[l];
/*      */ 
/*      */       
/* 1958 */       svm_group_classes(prob, tmp_nr_class, tmp_label, tmp_start, tmp_count, perm);
/* 1959 */       int nr_class = tmp_nr_class[0];
/* 1960 */       int[] label = tmp_label[0];
/* 1961 */       int[] start = tmp_start[0];
/* 1962 */       int[] count = tmp_count[0];
/* 1963 */       svm_node[][] x = new svm_node[l][];
/*      */       int i;
/* 1965 */       for (i = 0; i < l; i++) {
/* 1966 */         x[i] = prob.x[perm[i]];
/*      */       }
/*      */ 
/*      */       
/* 1970 */       double[] weighted_C = new double[nr_class];
/* 1971 */       for (i = 0; i < nr_class; i++)
/* 1972 */         weighted_C[i] = param.C; 
/* 1973 */       for (i = 0; i < param.nr_weight; i++) {
/*      */         int j;
/*      */         
/* 1976 */         for (j = 0; j < nr_class && 
/* 1977 */           param.weight_label[i] != label[j]; j++);
/*      */         
/* 1979 */         if (j == nr_class) {
/* 1980 */           System.err.print("warning: class label " + param.weight_label[i] + " specified in weight is not found\n");
/*      */         } else {
/* 1982 */           weighted_C[j] = weighted_C[j] * param.weight[i];
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1987 */       boolean[] nonzero = new boolean[l];
/* 1988 */       for (i = 0; i < l; i++)
/* 1989 */         nonzero[i] = false; 
/* 1990 */       decision_function[] arrayOfdecision_function = new decision_function[nr_class * (nr_class - 1) / 2];
/*      */       
/* 1992 */       double[] probA = null, probB = null;
/* 1993 */       if (param.probability == 1) {
/*      */         
/* 1995 */         probA = new double[nr_class * (nr_class - 1) / 2];
/* 1996 */         probB = new double[nr_class * (nr_class - 1) / 2];
/*      */       } 
/*      */       
/* 1999 */       int p = 0;
/* 2000 */       for (i = 0; i < nr_class; i++) {
/* 2001 */         for (int j = i + 1; j < nr_class; j++) {
/*      */           
/* 2003 */           svm_problem sub_prob = new svm_problem();
/* 2004 */           int si = start[i], sj = start[j];
/* 2005 */           int ci = count[i], cj = count[j];
/* 2006 */           sub_prob.l = ci + cj;
/* 2007 */           sub_prob.x = new svm_node[sub_prob.l][];
/* 2008 */           sub_prob.y = new double[sub_prob.l];
/*      */           int k;
/* 2010 */           for (k = 0; k < ci; k++) {
/*      */             
/* 2012 */             sub_prob.x[k] = x[si + k];
/* 2013 */             sub_prob.y[k] = 1.0D;
/*      */           } 
/* 2015 */           for (k = 0; k < cj; k++) {
/*      */             
/* 2017 */             sub_prob.x[ci + k] = x[sj + k];
/* 2018 */             sub_prob.y[ci + k] = -1.0D;
/*      */           } 
/*      */           
/* 2021 */           if (param.probability == 1) {
/*      */             
/* 2023 */             double[] probAB = new double[2];
/* 2024 */             svm_binary_svc_probability(sub_prob, param, weighted_C[i], weighted_C[j], probAB);
/* 2025 */             probA[p] = probAB[0];
/* 2026 */             probB[p] = probAB[1];
/*      */           } 
/*      */           
/* 2029 */           arrayOfdecision_function[p] = svm_train_one(sub_prob, param, weighted_C[i], weighted_C[j]);
/* 2030 */           for (k = 0; k < ci; k++) {
/* 2031 */             if (!nonzero[si + k] && Math.abs((arrayOfdecision_function[p]).alpha[k]) > 0.0D)
/* 2032 */               nonzero[si + k] = true; 
/* 2033 */           }  for (k = 0; k < cj; k++) {
/* 2034 */             if (!nonzero[sj + k] && Math.abs((arrayOfdecision_function[p]).alpha[ci + k]) > 0.0D)
/* 2035 */               nonzero[sj + k] = true; 
/* 2036 */           }  p++;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 2041 */       model.nr_class = nr_class;
/*      */       
/* 2043 */       model.label = new int[nr_class];
/* 2044 */       for (i = 0; i < nr_class; i++) {
/* 2045 */         model.label[i] = label[i];
/*      */       }
/* 2047 */       model.rho = new double[nr_class * (nr_class - 1) / 2];
/* 2048 */       for (i = 0; i < nr_class * (nr_class - 1) / 2; i++) {
/* 2049 */         model.rho[i] = (arrayOfdecision_function[i]).rho;
/*      */       }
/* 2051 */       if (param.probability == 1) {
/*      */         
/* 2053 */         model.probA = new double[nr_class * (nr_class - 1) / 2];
/* 2054 */         model.probB = new double[nr_class * (nr_class - 1) / 2];
/* 2055 */         for (i = 0; i < nr_class * (nr_class - 1) / 2; i++)
/*      */         {
/* 2057 */           model.probA[i] = probA[i];
/* 2058 */           model.probB[i] = probB[i];
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 2063 */         model.probA = null;
/* 2064 */         model.probB = null;
/*      */       } 
/*      */       
/* 2067 */       int nnz = 0;
/* 2068 */       int[] nz_count = new int[nr_class];
/* 2069 */       model.nSV = new int[nr_class];
/* 2070 */       for (i = 0; i < nr_class; i++) {
/*      */         
/* 2072 */         int nSV = 0;
/* 2073 */         for (int j = 0; j < count[i]; j++) {
/* 2074 */           if (nonzero[start[i] + j]) {
/*      */             
/* 2076 */             nSV++;
/* 2077 */             nnz++;
/*      */           } 
/* 2079 */         }  model.nSV[i] = nSV;
/* 2080 */         nz_count[i] = nSV;
/*      */       } 
/*      */       
/* 2083 */       info("Total nSV = " + nnz + "\n");
/*      */       
/* 2085 */       model.l = nnz;
/* 2086 */       model.SV = new svm_node[nnz][];
/* 2087 */       p = 0;
/* 2088 */       for (i = 0; i < l; i++) {
/* 2089 */         if (nonzero[i]) model.SV[p++] = x[i]; 
/*      */       } 
/* 2091 */       int[] nz_start = new int[nr_class];
/* 2092 */       nz_start[0] = 0;
/* 2093 */       for (i = 1; i < nr_class; i++) {
/* 2094 */         nz_start[i] = nz_start[i - 1] + nz_count[i - 1];
/*      */       }
/* 2096 */       model.sv_coef = new double[nr_class - 1][];
/* 2097 */       for (i = 0; i < nr_class - 1; i++) {
/* 2098 */         model.sv_coef[i] = new double[nnz];
/*      */       }
/* 2100 */       p = 0;
/* 2101 */       for (i = 0; i < nr_class; i++) {
/* 2102 */         for (int j = i + 1; j < nr_class; j++) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2108 */           int si = start[i];
/* 2109 */           int sj = start[j];
/* 2110 */           int ci = count[i];
/* 2111 */           int cj = count[j];
/*      */           
/* 2113 */           int q = nz_start[i];
/*      */           int k;
/* 2115 */           for (k = 0; k < ci; k++) {
/* 2116 */             if (nonzero[si + k])
/* 2117 */               model.sv_coef[j - 1][q++] = (arrayOfdecision_function[p]).alpha[k]; 
/* 2118 */           }  q = nz_start[j];
/* 2119 */           for (k = 0; k < cj; k++) {
/* 2120 */             if (nonzero[sj + k])
/* 2121 */               model.sv_coef[i][q++] = (arrayOfdecision_function[p]).alpha[ci + k]; 
/* 2122 */           }  p++;
/*      */         } 
/*      */       } 
/* 2125 */     }  return model;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void svm_cross_validation(svm_problem prob, svm_parameter param, int nr_fold, double[] target) {
/* 2132 */     int[] fold_start = new int[nr_fold + 1];
/* 2133 */     int l = prob.l;
/* 2134 */     int[] perm = new int[l];
/*      */ 
/*      */ 
/*      */     
/* 2138 */     if ((param.svm_type == 0 || param.svm_type == 1) && nr_fold < l) {
/*      */ 
/*      */       
/* 2141 */       int[] tmp_nr_class = new int[1];
/* 2142 */       int[][] tmp_label = new int[1][];
/* 2143 */       int[][] tmp_start = new int[1][];
/* 2144 */       int[][] tmp_count = new int[1][];
/*      */       
/* 2146 */       svm_group_classes(prob, tmp_nr_class, tmp_label, tmp_start, tmp_count, perm);
/*      */       
/* 2148 */       int nr_class = tmp_nr_class[0];
/* 2149 */       int[] start = tmp_start[0];
/* 2150 */       int[] count = tmp_count[0];
/*      */ 
/*      */       
/* 2153 */       int[] fold_count = new int[nr_fold];
/*      */       
/* 2155 */       int[] index = new int[l]; int i;
/* 2156 */       for (i = 0; i < l; i++)
/* 2157 */         index[i] = perm[i];  int c;
/* 2158 */       for (c = 0; c < nr_class; c++) {
/* 2159 */         for (i = 0; i < count[c]; i++) {
/*      */           
/* 2161 */           int j = i + rand.nextInt(count[c] - i);
/* 2162 */           int _ = index[start[c] + j]; index[start[c] + j] = index[start[c] + i]; index[start[c] + i] = _;
/*      */         } 
/* 2164 */       }  for (i = 0; i < nr_fold; i++) {
/*      */         
/* 2166 */         fold_count[i] = 0;
/* 2167 */         for (c = 0; c < nr_class; c++)
/* 2168 */           fold_count[i] = fold_count[i] + (i + 1) * count[c] / nr_fold - i * count[c] / nr_fold; 
/*      */       } 
/* 2170 */       fold_start[0] = 0;
/* 2171 */       for (i = 1; i <= nr_fold; i++)
/* 2172 */         fold_start[i] = fold_start[i - 1] + fold_count[i - 1]; 
/* 2173 */       for (c = 0; c < nr_class; c++) {
/* 2174 */         for (i = 0; i < nr_fold; i++) {
/*      */           
/* 2176 */           int begin = start[c] + i * count[c] / nr_fold;
/* 2177 */           int end = start[c] + (i + 1) * count[c] / nr_fold;
/* 2178 */           for (int j = begin; j < end; j++) {
/*      */             
/* 2180 */             perm[fold_start[i]] = index[j];
/* 2181 */             fold_start[i] = fold_start[i] + 1;
/*      */           } 
/*      */         } 
/* 2184 */       }  fold_start[0] = 0;
/* 2185 */       for (i = 1; i <= nr_fold; i++) {
/* 2186 */         fold_start[i] = fold_start[i - 1] + fold_count[i - 1];
/*      */       }
/*      */     } else {
/*      */       int i;
/* 2190 */       for (i = 0; i < l; ) { perm[i] = i; i++; }
/* 2191 */        for (i = 0; i < l; i++) {
/*      */         
/* 2193 */         int j = i + rand.nextInt(l - i);
/* 2194 */         int _ = perm[i]; perm[i] = perm[j]; perm[j] = _;
/*      */       } 
/* 2196 */       for (i = 0; i <= nr_fold; i++) {
/* 2197 */         fold_start[i] = i * l / nr_fold;
/*      */       }
/*      */     } 
/* 2200 */     for (byte b = 0; b < nr_fold; b++) {
/*      */       
/* 2202 */       int begin = fold_start[b];
/* 2203 */       int end = fold_start[b + true];
/*      */       
/* 2205 */       svm_problem subprob = new svm_problem();
/*      */       
/* 2207 */       subprob.l = l - end - begin;
/* 2208 */       subprob.x = new svm_node[subprob.l][];
/* 2209 */       subprob.y = new double[subprob.l];
/*      */       
/* 2211 */       int k = 0; int j;
/* 2212 */       for (j = 0; j < begin; j++) {
/*      */         
/* 2214 */         subprob.x[k] = prob.x[perm[j]];
/* 2215 */         subprob.y[k] = prob.y[perm[j]];
/* 2216 */         k++;
/*      */       } 
/* 2218 */       for (j = end; j < l; j++) {
/*      */         
/* 2220 */         subprob.x[k] = prob.x[perm[j]];
/* 2221 */         subprob.y[k] = prob.y[perm[j]];
/* 2222 */         k++;
/*      */       } 
/* 2224 */       svm_model submodel = svm_train(subprob, param);
/* 2225 */       if (param.probability == 1 && (param.svm_type == 0 || param.svm_type == 1)) {
/*      */ 
/*      */ 
/*      */         
/* 2229 */         double[] prob_estimates = new double[svm_get_nr_class(submodel)];
/* 2230 */         for (j = begin; j < end; j++) {
/* 2231 */           target[perm[j]] = svm_predict_probability(submodel, prob.x[perm[j]], prob_estimates);
/*      */         }
/*      */       } else {
/* 2234 */         for (j = begin; j < end; j++) {
/* 2235 */           target[perm[j]] = svm_predict(submodel, prob.x[perm[j]]);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/* 2241 */   public static int svm_get_svm_type(svm_model model) { return model.param.svm_type; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2246 */   public static int svm_get_nr_class(svm_model model) { return model.nr_class; }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void svm_get_labels(svm_model model, int[] label) {
/* 2251 */     if (model.label != null)
/* 2252 */       for (int i = 0; i < model.nr_class; i++) {
/* 2253 */         label[i] = model.label[i];
/*      */       } 
/*      */   }
/*      */   
/*      */   public static double svm_get_svr_probability(svm_model model) {
/* 2258 */     if ((model.param.svm_type == 3 || model.param.svm_type == 4) && model.probA != null)
/*      */     {
/* 2260 */       return model.probA[0];
/*      */     }
/*      */     
/* 2263 */     System.err.print("Model doesn't contain information for SVR probability inference\n");
/* 2264 */     return 0.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double svm_predict_values(svm_model model, svm_node[] x, double[] dec_values) {
/* 2270 */     if (model.param.svm_type == 2 || model.param.svm_type == 3 || model.param.svm_type == 4) {
/*      */ 
/*      */ 
/*      */       
/* 2274 */       double[] sv_coef = model.sv_coef[0];
/* 2275 */       double sum = 0.0D;
/* 2276 */       for (int i = 0; i < model.l; i++)
/* 2277 */         sum += sv_coef[i] * Kernel.k_function(x, model.SV[i], model.param); 
/* 2278 */       sum -= model.rho[0];
/* 2279 */       dec_values[0] = sum;
/*      */       
/* 2281 */       if (model.param.svm_type == 2) {
/* 2282 */         return (sum > 0.0D) ? 1.0D : -1.0D;
/*      */       }
/* 2284 */       return sum;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2289 */     int nr_class = model.nr_class;
/* 2290 */     int l = model.l;
/*      */     
/* 2292 */     double[] kvalue = new double[l]; int i;
/* 2293 */     for (i = 0; i < l; i++) {
/* 2294 */       kvalue[i] = Kernel.k_function(x, model.SV[i], model.param);
/*      */     }
/* 2296 */     int[] start = new int[nr_class];
/* 2297 */     start[0] = 0;
/* 2298 */     for (i = 1; i < nr_class; i++) {
/* 2299 */       start[i] = start[i - 1] + model.nSV[i - 1];
/*      */     }
/* 2301 */     int[] vote = new int[nr_class];
/* 2302 */     for (i = 0; i < nr_class; i++) {
/* 2303 */       vote[i] = 0;
/*      */     }
/* 2305 */     int p = 0;
/* 2306 */     for (i = 0; i < nr_class; i++) {
/* 2307 */       for (int j = i + 1; j < nr_class; j++) {
/*      */         
/* 2309 */         double sum = 0.0D;
/* 2310 */         int si = start[i];
/* 2311 */         int sj = start[j];
/* 2312 */         int ci = model.nSV[i];
/* 2313 */         int cj = model.nSV[j];
/*      */ 
/*      */         
/* 2316 */         double[] coef1 = model.sv_coef[j - 1];
/* 2317 */         double[] coef2 = model.sv_coef[i]; int k;
/* 2318 */         for (k = 0; k < ci; k++)
/* 2319 */           sum += coef1[si + k] * kvalue[si + k]; 
/* 2320 */         for (k = 0; k < cj; k++)
/* 2321 */           sum += coef2[sj + k] * kvalue[sj + k]; 
/* 2322 */         sum -= model.rho[p];
/* 2323 */         dec_values[p] = sum;
/*      */         
/* 2325 */         if (dec_values[p] > 0.0D) {
/* 2326 */           vote[i] = vote[i] + 1;
/*      */         } else {
/* 2328 */           vote[j] = vote[j] + 1;
/* 2329 */         }  p++;
/*      */       } 
/*      */     } 
/* 2332 */     int vote_max_idx = 0;
/* 2333 */     for (i = 1; i < nr_class; i++) {
/* 2334 */       if (vote[i] > vote[vote_max_idx])
/* 2335 */         vote_max_idx = i; 
/*      */     } 
/* 2337 */     return model.label[vote_max_idx];
/*      */   }
/*      */ 
/*      */   
/*      */   public static double svm_predict(svm_model model, svm_node[] x) {
/*      */     double[] dec_values;
/* 2343 */     int nr_class = model.nr_class;
/*      */     
/* 2345 */     if (model.param.svm_type == 2 || model.param.svm_type == 3 || model.param.svm_type == 4) {
/*      */ 
/*      */       
/* 2348 */       dec_values = new double[1];
/*      */     } else {
/* 2350 */       dec_values = new double[nr_class * (nr_class - 1) / 2];
/* 2351 */     }  return svm_predict_values(model, x, dec_values);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static double svm_predict_probability(svm_model model, svm_node[] x, double[] prob_estimates) {
/* 2357 */     if ((model.param.svm_type == 0 || model.param.svm_type == 1) && model.probA != null && model.probB != null) {
/*      */ 
/*      */ 
/*      */       
/* 2361 */       int nr_class = model.nr_class;
/* 2362 */       double[] dec_values = new double[nr_class * (nr_class - 1) / 2];
/* 2363 */       svm_predict_values(model, x, dec_values);
/*      */       
/* 2365 */       double min_prob = 1.0E-7D;
/* 2366 */       double[][] pairwise_prob = new double[nr_class][nr_class];
/*      */       
/* 2368 */       int k = 0; int i;
/* 2369 */       for (i = 0; i < nr_class; i++) {
/* 2370 */         for (int j = i + 1; j < nr_class; j++) {
/*      */           
/* 2372 */           pairwise_prob[i][j] = Math.min(Math.max(sigmoid_predict(dec_values[k], model.probA[k], model.probB[k]), min_prob), 1.0D - min_prob);
/* 2373 */           pairwise_prob[j][i] = 1.0D - pairwise_prob[i][j];
/* 2374 */           k++;
/*      */         } 
/* 2376 */       }  multiclass_probability(nr_class, pairwise_prob, prob_estimates);
/*      */       
/* 2378 */       int prob_max_idx = 0;
/* 2379 */       for (i = 1; i < nr_class; i++) {
/* 2380 */         if (prob_estimates[i] > prob_estimates[prob_max_idx])
/* 2381 */           prob_max_idx = i; 
/* 2382 */       }  return model.label[prob_max_idx];
/*      */     } 
/*      */     
/* 2385 */     return svm_predict(model, x);
/*      */   }
/*      */   
/* 2388 */   static final String[] svm_type_table = { "c_svc", "nu_svc", "one_class", "epsilon_svr", "nu_svr" };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2393 */   static final String[] kernel_type_table = { "linear", "polynomial", "rbf", "sigmoid", "precomputed" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void svm_save_model(String model_file_name, svm_model model) throws IOException {
/* 2400 */     DataOutputStream fp = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(model_file_name)));
/*      */     
/* 2402 */     svm_parameter param = model.param;
/*      */     
/* 2404 */     fp.writeBytes("svm_type " + svm_type_table[param.svm_type] + "\n");
/* 2405 */     fp.writeBytes("kernel_type " + kernel_type_table[param.kernel_type] + "\n");
/*      */     
/* 2407 */     if (param.kernel_type == 1) {
/* 2408 */       fp.writeBytes("degree " + param.degree + "\n");
/*      */     }
/* 2410 */     if (param.kernel_type == 1 || param.kernel_type == 2 || param.kernel_type == 3)
/*      */     {
/*      */       
/* 2413 */       fp.writeBytes("gamma " + param.gamma + "\n");
/*      */     }
/* 2415 */     if (param.kernel_type == 1 || param.kernel_type == 3)
/*      */     {
/* 2417 */       fp.writeBytes("coef0 " + param.coef0 + "\n");
/*      */     }
/* 2419 */     int nr_class = model.nr_class;
/* 2420 */     int l = model.l;
/* 2421 */     fp.writeBytes("nr_class " + nr_class + "\n");
/* 2422 */     fp.writeBytes("total_sv " + l + "\n");
/*      */ 
/*      */     
/* 2425 */     fp.writeBytes("rho");
/* 2426 */     for (int i = 0; i < nr_class * (nr_class - 1) / 2; i++)
/* 2427 */       fp.writeBytes(" " + model.rho[i]); 
/* 2428 */     fp.writeBytes("\n");
/*      */ 
/*      */     
/* 2431 */     if (model.label != null) {
/*      */       
/* 2433 */       fp.writeBytes("label");
/* 2434 */       for (int i = 0; i < nr_class; i++)
/* 2435 */         fp.writeBytes(" " + model.label[i]); 
/* 2436 */       fp.writeBytes("\n");
/*      */     } 
/*      */     
/* 2439 */     if (model.probA != null) {
/*      */       
/* 2441 */       fp.writeBytes("probA");
/* 2442 */       for (int i = 0; i < nr_class * (nr_class - 1) / 2; i++)
/* 2443 */         fp.writeBytes(" " + model.probA[i]); 
/* 2444 */       fp.writeBytes("\n");
/*      */     } 
/* 2446 */     if (model.probB != null) {
/*      */       
/* 2448 */       fp.writeBytes("probB");
/* 2449 */       for (int i = 0; i < nr_class * (nr_class - 1) / 2; i++)
/* 2450 */         fp.writeBytes(" " + model.probB[i]); 
/* 2451 */       fp.writeBytes("\n");
/*      */     } 
/*      */     
/* 2454 */     if (model.nSV != null) {
/*      */       
/* 2456 */       fp.writeBytes("nr_sv");
/* 2457 */       for (int i = 0; i < nr_class; i++)
/* 2458 */         fp.writeBytes(" " + model.nSV[i]); 
/* 2459 */       fp.writeBytes("\n");
/*      */     } 
/*      */     
/* 2462 */     fp.writeBytes("SV\n");
/* 2463 */     double[][] sv_coef = model.sv_coef;
/* 2464 */     svm_node[][] SV = model.SV;
/*      */     
/* 2466 */     for (int i = 0; i < l; i++) {
/*      */       
/* 2468 */       for (int j = 0; j < nr_class - 1; j++) {
/* 2469 */         fp.writeBytes(sv_coef[j][i] + " ");
/*      */       }
/* 2471 */       svm_node[] p = SV[i];
/* 2472 */       if (param.kernel_type == 4) {
/* 2473 */         fp.writeBytes("0:" + (int)(p[0]).value);
/*      */       } else {
/* 2475 */         for (int j = 0; j < p.length; j++)
/* 2476 */           fp.writeBytes((p[j]).index + ":" + (p[j]).value + " "); 
/* 2477 */       }  fp.writeBytes("\n");
/*      */     } 
/*      */     
/* 2480 */     fp.close();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2485 */   private static double atof(String s) { return Double.valueOf(s).doubleValue(); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2490 */   private static int atoi(String s) { return Integer.parseInt(s); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2495 */   public static svm_model svm_load_model(String model_file_name) throws IOException { return svm_load_model(new BufferedReader(new FileReader(model_file_name))); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static svm_model svm_load_model(BufferedReader fp) throws IOException { // Byte code:
/*      */     //   0: new libsvm/svm_model
/*      */     //   3: dup
/*      */     //   4: invokespecial <init> : ()V
/*      */     //   7: astore_1
/*      */     //   8: new libsvm/svm_parameter
/*      */     //   11: dup
/*      */     //   12: invokespecial <init> : ()V
/*      */     //   15: astore_2
/*      */     //   16: aload_1
/*      */     //   17: aload_2
/*      */     //   18: putfield param : Llibsvm/svm_parameter;
/*      */     //   21: aload_1
/*      */     //   22: aconst_null
/*      */     //   23: putfield rho : [D
/*      */     //   26: aload_1
/*      */     //   27: aconst_null
/*      */     //   28: putfield probA : [D
/*      */     //   31: aload_1
/*      */     //   32: aconst_null
/*      */     //   33: putfield probB : [D
/*      */     //   36: aload_1
/*      */     //   37: aconst_null
/*      */     //   38: putfield label : [I
/*      */     //   41: aload_1
/*      */     //   42: aconst_null
/*      */     //   43: putfield nSV : [I
/*      */     //   46: aload_0
/*      */     //   47: invokevirtual readLine : ()Ljava/lang/String;
/*      */     //   50: astore_3
/*      */     //   51: aload_3
/*      */     //   52: aload_3
/*      */     //   53: bipush #32
/*      */     //   55: invokevirtual indexOf : (I)I
/*      */     //   58: iconst_1
/*      */     //   59: iadd
/*      */     //   60: invokevirtual substring : (I)Ljava/lang/String;
/*      */     //   63: astore #4
/*      */     //   65: aload_3
/*      */     //   66: ldc 'svm_type'
/*      */     //   68: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   71: ifeq -> 138
/*      */     //   74: iconst_0
/*      */     //   75: istore #5
/*      */     //   77: iload #5
/*      */     //   79: getstatic libsvm/svm.svm_type_table : [Ljava/lang/String;
/*      */     //   82: arraylength
/*      */     //   83: if_icmpge -> 116
/*      */     //   86: aload #4
/*      */     //   88: getstatic libsvm/svm.svm_type_table : [Ljava/lang/String;
/*      */     //   91: iload #5
/*      */     //   93: aaload
/*      */     //   94: invokevirtual indexOf : (Ljava/lang/String;)I
/*      */     //   97: iconst_m1
/*      */     //   98: if_icmpeq -> 110
/*      */     //   101: aload_2
/*      */     //   102: iload #5
/*      */     //   104: putfield svm_type : I
/*      */     //   107: goto -> 116
/*      */     //   110: iinc #5, 1
/*      */     //   113: goto -> 77
/*      */     //   116: iload #5
/*      */     //   118: getstatic libsvm/svm.svm_type_table : [Ljava/lang/String;
/*      */     //   121: arraylength
/*      */     //   122: if_icmpne -> 135
/*      */     //   125: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*      */     //   128: ldc 'unknown svm type.\\n'
/*      */     //   130: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   133: aconst_null
/*      */     //   134: areturn
/*      */     //   135: goto -> 727
/*      */     //   138: aload_3
/*      */     //   139: ldc 'kernel_type'
/*      */     //   141: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   144: ifeq -> 211
/*      */     //   147: iconst_0
/*      */     //   148: istore #5
/*      */     //   150: iload #5
/*      */     //   152: getstatic libsvm/svm.kernel_type_table : [Ljava/lang/String;
/*      */     //   155: arraylength
/*      */     //   156: if_icmpge -> 189
/*      */     //   159: aload #4
/*      */     //   161: getstatic libsvm/svm.kernel_type_table : [Ljava/lang/String;
/*      */     //   164: iload #5
/*      */     //   166: aaload
/*      */     //   167: invokevirtual indexOf : (Ljava/lang/String;)I
/*      */     //   170: iconst_m1
/*      */     //   171: if_icmpeq -> 183
/*      */     //   174: aload_2
/*      */     //   175: iload #5
/*      */     //   177: putfield kernel_type : I
/*      */     //   180: goto -> 189
/*      */     //   183: iinc #5, 1
/*      */     //   186: goto -> 150
/*      */     //   189: iload #5
/*      */     //   191: getstatic libsvm/svm.kernel_type_table : [Ljava/lang/String;
/*      */     //   194: arraylength
/*      */     //   195: if_icmpne -> 208
/*      */     //   198: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*      */     //   201: ldc 'unknown kernel function.\\n'
/*      */     //   203: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   206: aconst_null
/*      */     //   207: areturn
/*      */     //   208: goto -> 727
/*      */     //   211: aload_3
/*      */     //   212: ldc 'degree'
/*      */     //   214: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   217: ifeq -> 232
/*      */     //   220: aload_2
/*      */     //   221: aload #4
/*      */     //   223: invokestatic atoi : (Ljava/lang/String;)I
/*      */     //   226: putfield degree : I
/*      */     //   229: goto -> 727
/*      */     //   232: aload_3
/*      */     //   233: ldc 'gamma'
/*      */     //   235: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   238: ifeq -> 253
/*      */     //   241: aload_2
/*      */     //   242: aload #4
/*      */     //   244: invokestatic atof : (Ljava/lang/String;)D
/*      */     //   247: putfield gamma : D
/*      */     //   250: goto -> 727
/*      */     //   253: aload_3
/*      */     //   254: ldc 'coef0'
/*      */     //   256: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   259: ifeq -> 274
/*      */     //   262: aload_2
/*      */     //   263: aload #4
/*      */     //   265: invokestatic atof : (Ljava/lang/String;)D
/*      */     //   268: putfield coef0 : D
/*      */     //   271: goto -> 727
/*      */     //   274: aload_3
/*      */     //   275: ldc 'nr_class'
/*      */     //   277: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   280: ifeq -> 295
/*      */     //   283: aload_1
/*      */     //   284: aload #4
/*      */     //   286: invokestatic atoi : (Ljava/lang/String;)I
/*      */     //   289: putfield nr_class : I
/*      */     //   292: goto -> 727
/*      */     //   295: aload_3
/*      */     //   296: ldc 'total_sv'
/*      */     //   298: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   301: ifeq -> 316
/*      */     //   304: aload_1
/*      */     //   305: aload #4
/*      */     //   307: invokestatic atoi : (Ljava/lang/String;)I
/*      */     //   310: putfield l : I
/*      */     //   313: goto -> 727
/*      */     //   316: aload_3
/*      */     //   317: ldc 'rho'
/*      */     //   319: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   322: ifeq -> 393
/*      */     //   325: aload_1
/*      */     //   326: getfield nr_class : I
/*      */     //   329: aload_1
/*      */     //   330: getfield nr_class : I
/*      */     //   333: iconst_1
/*      */     //   334: isub
/*      */     //   335: imul
/*      */     //   336: iconst_2
/*      */     //   337: idiv
/*      */     //   338: istore #5
/*      */     //   340: aload_1
/*      */     //   341: iload #5
/*      */     //   343: newarray double
/*      */     //   345: putfield rho : [D
/*      */     //   348: new java/util/StringTokenizer
/*      */     //   351: dup
/*      */     //   352: aload #4
/*      */     //   354: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   357: astore #6
/*      */     //   359: iconst_0
/*      */     //   360: istore #7
/*      */     //   362: iload #7
/*      */     //   364: iload #5
/*      */     //   366: if_icmpge -> 390
/*      */     //   369: aload_1
/*      */     //   370: getfield rho : [D
/*      */     //   373: iload #7
/*      */     //   375: aload #6
/*      */     //   377: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   380: invokestatic atof : (Ljava/lang/String;)D
/*      */     //   383: dastore
/*      */     //   384: iinc #7, 1
/*      */     //   387: goto -> 362
/*      */     //   390: goto -> 727
/*      */     //   393: aload_3
/*      */     //   394: ldc 'label'
/*      */     //   396: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   399: ifeq -> 461
/*      */     //   402: aload_1
/*      */     //   403: getfield nr_class : I
/*      */     //   406: istore #5
/*      */     //   408: aload_1
/*      */     //   409: iload #5
/*      */     //   411: newarray int
/*      */     //   413: putfield label : [I
/*      */     //   416: new java/util/StringTokenizer
/*      */     //   419: dup
/*      */     //   420: aload #4
/*      */     //   422: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   425: astore #6
/*      */     //   427: iconst_0
/*      */     //   428: istore #7
/*      */     //   430: iload #7
/*      */     //   432: iload #5
/*      */     //   434: if_icmpge -> 458
/*      */     //   437: aload_1
/*      */     //   438: getfield label : [I
/*      */     //   441: iload #7
/*      */     //   443: aload #6
/*      */     //   445: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   448: invokestatic atoi : (Ljava/lang/String;)I
/*      */     //   451: iastore
/*      */     //   452: iinc #7, 1
/*      */     //   455: goto -> 430
/*      */     //   458: goto -> 727
/*      */     //   461: aload_3
/*      */     //   462: ldc 'probA'
/*      */     //   464: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   467: ifeq -> 538
/*      */     //   470: aload_1
/*      */     //   471: getfield nr_class : I
/*      */     //   474: aload_1
/*      */     //   475: getfield nr_class : I
/*      */     //   478: iconst_1
/*      */     //   479: isub
/*      */     //   480: imul
/*      */     //   481: iconst_2
/*      */     //   482: idiv
/*      */     //   483: istore #5
/*      */     //   485: aload_1
/*      */     //   486: iload #5
/*      */     //   488: newarray double
/*      */     //   490: putfield probA : [D
/*      */     //   493: new java/util/StringTokenizer
/*      */     //   496: dup
/*      */     //   497: aload #4
/*      */     //   499: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   502: astore #6
/*      */     //   504: iconst_0
/*      */     //   505: istore #7
/*      */     //   507: iload #7
/*      */     //   509: iload #5
/*      */     //   511: if_icmpge -> 535
/*      */     //   514: aload_1
/*      */     //   515: getfield probA : [D
/*      */     //   518: iload #7
/*      */     //   520: aload #6
/*      */     //   522: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   525: invokestatic atof : (Ljava/lang/String;)D
/*      */     //   528: dastore
/*      */     //   529: iinc #7, 1
/*      */     //   532: goto -> 507
/*      */     //   535: goto -> 727
/*      */     //   538: aload_3
/*      */     //   539: ldc 'probB'
/*      */     //   541: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   544: ifeq -> 615
/*      */     //   547: aload_1
/*      */     //   548: getfield nr_class : I
/*      */     //   551: aload_1
/*      */     //   552: getfield nr_class : I
/*      */     //   555: iconst_1
/*      */     //   556: isub
/*      */     //   557: imul
/*      */     //   558: iconst_2
/*      */     //   559: idiv
/*      */     //   560: istore #5
/*      */     //   562: aload_1
/*      */     //   563: iload #5
/*      */     //   565: newarray double
/*      */     //   567: putfield probB : [D
/*      */     //   570: new java/util/StringTokenizer
/*      */     //   573: dup
/*      */     //   574: aload #4
/*      */     //   576: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   579: astore #6
/*      */     //   581: iconst_0
/*      */     //   582: istore #7
/*      */     //   584: iload #7
/*      */     //   586: iload #5
/*      */     //   588: if_icmpge -> 612
/*      */     //   591: aload_1
/*      */     //   592: getfield probB : [D
/*      */     //   595: iload #7
/*      */     //   597: aload #6
/*      */     //   599: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   602: invokestatic atof : (Ljava/lang/String;)D
/*      */     //   605: dastore
/*      */     //   606: iinc #7, 1
/*      */     //   609: goto -> 584
/*      */     //   612: goto -> 727
/*      */     //   615: aload_3
/*      */     //   616: ldc 'nr_sv'
/*      */     //   618: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   621: ifeq -> 683
/*      */     //   624: aload_1
/*      */     //   625: getfield nr_class : I
/*      */     //   628: istore #5
/*      */     //   630: aload_1
/*      */     //   631: iload #5
/*      */     //   633: newarray int
/*      */     //   635: putfield nSV : [I
/*      */     //   638: new java/util/StringTokenizer
/*      */     //   641: dup
/*      */     //   642: aload #4
/*      */     //   644: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   647: astore #6
/*      */     //   649: iconst_0
/*      */     //   650: istore #7
/*      */     //   652: iload #7
/*      */     //   654: iload #5
/*      */     //   656: if_icmpge -> 680
/*      */     //   659: aload_1
/*      */     //   660: getfield nSV : [I
/*      */     //   663: iload #7
/*      */     //   665: aload #6
/*      */     //   667: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   670: invokestatic atoi : (Ljava/lang/String;)I
/*      */     //   673: iastore
/*      */     //   674: iinc #7, 1
/*      */     //   677: goto -> 652
/*      */     //   680: goto -> 727
/*      */     //   683: aload_3
/*      */     //   684: ldc 'SV'
/*      */     //   686: invokevirtual startsWith : (Ljava/lang/String;)Z
/*      */     //   689: ifeq -> 695
/*      */     //   692: goto -> 730
/*      */     //   695: getstatic java/lang/System.err : Ljava/io/PrintStream;
/*      */     //   698: new java/lang/StringBuilder
/*      */     //   701: dup
/*      */     //   702: invokespecial <init> : ()V
/*      */     //   705: ldc 'unknown text in model file: ['
/*      */     //   707: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   710: aload_3
/*      */     //   711: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   714: ldc ']\\n'
/*      */     //   716: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*      */     //   719: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   722: invokevirtual print : (Ljava/lang/String;)V
/*      */     //   725: aconst_null
/*      */     //   726: areturn
/*      */     //   727: goto -> 46
/*      */     //   730: aload_1
/*      */     //   731: getfield nr_class : I
/*      */     //   734: iconst_1
/*      */     //   735: isub
/*      */     //   736: istore_3
/*      */     //   737: aload_1
/*      */     //   738: getfield l : I
/*      */     //   741: istore #4
/*      */     //   743: aload_1
/*      */     //   744: iload_3
/*      */     //   745: iload #4
/*      */     //   747: multianewarray[[D 2
/*      */     //   751: putfield sv_coef : [[D
/*      */     //   754: aload_1
/*      */     //   755: iload #4
/*      */     //   757: anewarray [Llibsvm/svm_node;
/*      */     //   760: putfield SV : [[Llibsvm/svm_node;
/*      */     //   763: iconst_0
/*      */     //   764: istore #5
/*      */     //   766: iload #5
/*      */     //   768: iload #4
/*      */     //   770: if_icmpge -> 927
/*      */     //   773: aload_0
/*      */     //   774: invokevirtual readLine : ()Ljava/lang/String;
/*      */     //   777: astore #6
/*      */     //   779: new java/util/StringTokenizer
/*      */     //   782: dup
/*      */     //   783: aload #6
/*      */     //   785: ldc ' \\t\\n\\r\\f:'
/*      */     //   787: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   790: astore #7
/*      */     //   792: iconst_0
/*      */     //   793: istore #8
/*      */     //   795: iload #8
/*      */     //   797: iload_3
/*      */     //   798: if_icmpge -> 825
/*      */     //   801: aload_1
/*      */     //   802: getfield sv_coef : [[D
/*      */     //   805: iload #8
/*      */     //   807: aaload
/*      */     //   808: iload #5
/*      */     //   810: aload #7
/*      */     //   812: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   815: invokestatic atof : (Ljava/lang/String;)D
/*      */     //   818: dastore
/*      */     //   819: iinc #8, 1
/*      */     //   822: goto -> 795
/*      */     //   825: aload #7
/*      */     //   827: invokevirtual countTokens : ()I
/*      */     //   830: iconst_2
/*      */     //   831: idiv
/*      */     //   832: istore #8
/*      */     //   834: aload_1
/*      */     //   835: getfield SV : [[Llibsvm/svm_node;
/*      */     //   838: iload #5
/*      */     //   840: iload #8
/*      */     //   842: anewarray libsvm/svm_node
/*      */     //   845: aastore
/*      */     //   846: iconst_0
/*      */     //   847: istore #9
/*      */     //   849: iload #9
/*      */     //   851: iload #8
/*      */     //   853: if_icmpge -> 921
/*      */     //   856: aload_1
/*      */     //   857: getfield SV : [[Llibsvm/svm_node;
/*      */     //   860: iload #5
/*      */     //   862: aaload
/*      */     //   863: iload #9
/*      */     //   865: new libsvm/svm_node
/*      */     //   868: dup
/*      */     //   869: invokespecial <init> : ()V
/*      */     //   872: aastore
/*      */     //   873: aload_1
/*      */     //   874: getfield SV : [[Llibsvm/svm_node;
/*      */     //   877: iload #5
/*      */     //   879: aaload
/*      */     //   880: iload #9
/*      */     //   882: aaload
/*      */     //   883: aload #7
/*      */     //   885: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   888: invokestatic atoi : (Ljava/lang/String;)I
/*      */     //   891: putfield index : I
/*      */     //   894: aload_1
/*      */     //   895: getfield SV : [[Llibsvm/svm_node;
/*      */     //   898: iload #5
/*      */     //   900: aaload
/*      */     //   901: iload #9
/*      */     //   903: aaload
/*      */     //   904: aload #7
/*      */     //   906: invokevirtual nextToken : ()Ljava/lang/String;
/*      */     //   909: invokestatic atof : (Ljava/lang/String;)D
/*      */     //   912: putfield value : D
/*      */     //   915: iinc #9, 1
/*      */     //   918: goto -> 849
/*      */     //   921: iinc #5, 1
/*      */     //   924: goto -> 766
/*      */     //   927: aload_0
/*      */     //   928: invokevirtual close : ()V
/*      */     //   931: aload_1
/*      */     //   932: areturn
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2502	-> 0
/*      */     //   #2503	-> 8
/*      */     //   #2504	-> 16
/*      */     //   #2505	-> 21
/*      */     //   #2506	-> 26
/*      */     //   #2507	-> 31
/*      */     //   #2508	-> 36
/*      */     //   #2509	-> 41
/*      */     //   #2513	-> 46
/*      */     //   #2514	-> 51
/*      */     //   #2516	-> 65
/*      */     //   #2519	-> 74
/*      */     //   #2521	-> 86
/*      */     //   #2523	-> 101
/*      */     //   #2524	-> 107
/*      */     //   #2519	-> 110
/*      */     //   #2527	-> 116
/*      */     //   #2529	-> 125
/*      */     //   #2530	-> 133
/*      */     //   #2532	-> 135
/*      */     //   #2533	-> 138
/*      */     //   #2536	-> 147
/*      */     //   #2538	-> 159
/*      */     //   #2540	-> 174
/*      */     //   #2541	-> 180
/*      */     //   #2536	-> 183
/*      */     //   #2544	-> 189
/*      */     //   #2546	-> 198
/*      */     //   #2547	-> 206
/*      */     //   #2549	-> 208
/*      */     //   #2550	-> 211
/*      */     //   #2551	-> 220
/*      */     //   #2552	-> 232
/*      */     //   #2553	-> 241
/*      */     //   #2554	-> 253
/*      */     //   #2555	-> 262
/*      */     //   #2556	-> 274
/*      */     //   #2557	-> 283
/*      */     //   #2558	-> 295
/*      */     //   #2559	-> 304
/*      */     //   #2560	-> 316
/*      */     //   #2562	-> 325
/*      */     //   #2563	-> 340
/*      */     //   #2564	-> 348
/*      */     //   #2565	-> 359
/*      */     //   #2566	-> 369
/*      */     //   #2565	-> 384
/*      */     //   #2567	-> 390
/*      */     //   #2568	-> 393
/*      */     //   #2570	-> 402
/*      */     //   #2571	-> 408
/*      */     //   #2572	-> 416
/*      */     //   #2573	-> 427
/*      */     //   #2574	-> 437
/*      */     //   #2573	-> 452
/*      */     //   #2575	-> 458
/*      */     //   #2576	-> 461
/*      */     //   #2578	-> 470
/*      */     //   #2579	-> 485
/*      */     //   #2580	-> 493
/*      */     //   #2581	-> 504
/*      */     //   #2582	-> 514
/*      */     //   #2581	-> 529
/*      */     //   #2583	-> 535
/*      */     //   #2584	-> 538
/*      */     //   #2586	-> 547
/*      */     //   #2587	-> 562
/*      */     //   #2588	-> 570
/*      */     //   #2589	-> 581
/*      */     //   #2590	-> 591
/*      */     //   #2589	-> 606
/*      */     //   #2591	-> 612
/*      */     //   #2592	-> 615
/*      */     //   #2594	-> 624
/*      */     //   #2595	-> 630
/*      */     //   #2596	-> 638
/*      */     //   #2597	-> 649
/*      */     //   #2598	-> 659
/*      */     //   #2597	-> 674
/*      */     //   #2599	-> 680
/*      */     //   #2600	-> 683
/*      */     //   #2602	-> 692
/*      */     //   #2606	-> 695
/*      */     //   #2607	-> 725
/*      */     //   #2609	-> 727
/*      */     //   #2613	-> 730
/*      */     //   #2614	-> 737
/*      */     //   #2615	-> 743
/*      */     //   #2616	-> 754
/*      */     //   #2618	-> 763
/*      */     //   #2620	-> 773
/*      */     //   #2621	-> 779
/*      */     //   #2623	-> 792
/*      */     //   #2624	-> 801
/*      */     //   #2623	-> 819
/*      */     //   #2625	-> 825
/*      */     //   #2626	-> 834
/*      */     //   #2627	-> 846
/*      */     //   #2629	-> 856
/*      */     //   #2630	-> 873
/*      */     //   #2631	-> 894
/*      */     //   #2627	-> 915
/*      */     //   #2618	-> 921
/*      */     //   #2635	-> 927
/*      */     //   #2636	-> 931
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   77	58	5	i	I
/*      */     //   150	58	5	i	I
/*      */     //   362	28	7	i	I
/*      */     //   340	50	5	n	I
/*      */     //   359	31	6	st	Ljava/util/StringTokenizer;
/*      */     //   430	28	7	i	I
/*      */     //   408	50	5	n	I
/*      */     //   427	31	6	st	Ljava/util/StringTokenizer;
/*      */     //   507	28	7	i	I
/*      */     //   485	50	5	n	I
/*      */     //   504	31	6	st	Ljava/util/StringTokenizer;
/*      */     //   584	28	7	i	I
/*      */     //   562	50	5	n	I
/*      */     //   581	31	6	st	Ljava/util/StringTokenizer;
/*      */     //   652	28	7	i	I
/*      */     //   630	50	5	n	I
/*      */     //   649	31	6	st	Ljava/util/StringTokenizer;
/*      */     //   51	676	3	cmd	Ljava/lang/String;
/*      */     //   65	662	4	arg	Ljava/lang/String;
/*      */     //   795	30	8	k	I
/*      */     //   849	72	9	j	I
/*      */     //   779	142	6	line	Ljava/lang/String;
/*      */     //   792	129	7	st	Ljava/util/StringTokenizer;
/*      */     //   834	87	8	n	I
/*      */     //   766	161	5	i	I
/*      */     //   0	933	0	fp	Ljava/io/BufferedReader;
/*      */     //   8	925	1	model	Llibsvm/svm_model;
/*      */     //   16	917	2	param	Llibsvm/svm_parameter;
/*      */     //   737	196	3	m	I
/*      */     //   743	190	4	l	I }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String svm_check_parameter(svm_problem prob, svm_parameter param) {
/* 2643 */     int svm_type = param.svm_type;
/* 2644 */     if (svm_type != 0 && svm_type != 1 && svm_type != 2 && svm_type != 3 && svm_type != 4)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 2649 */       return "unknown svm type";
/*      */     }
/*      */ 
/*      */     
/* 2653 */     int kernel_type = param.kernel_type;
/* 2654 */     if (kernel_type != 0 && kernel_type != 1 && kernel_type != 2 && kernel_type != 3 && kernel_type != 4)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 2659 */       return "unknown kernel type";
/*      */     }
/* 2661 */     if (param.gamma < 0.0D) {
/* 2662 */       return "gamma < 0";
/*      */     }
/* 2664 */     if (param.degree < 0) {
/* 2665 */       return "degree of polynomial kernel < 0";
/*      */     }
/*      */ 
/*      */     
/* 2669 */     if (param.cache_size <= 0.0D) {
/* 2670 */       return "cache_size <= 0";
/*      */     }
/* 2672 */     if (param.eps <= 0.0D) {
/* 2673 */       return "eps <= 0";
/*      */     }
/* 2675 */     if (svm_type == 0 || svm_type == 3 || svm_type == 4)
/*      */     {
/*      */       
/* 2678 */       if (param.C <= 0.0D)
/* 2679 */         return "C <= 0"; 
/*      */     }
/* 2681 */     if (svm_type == 1 || svm_type == 2 || svm_type == 4)
/*      */     {
/*      */       
/* 2684 */       if (param.nu <= 0.0D || param.nu > 1.0D)
/* 2685 */         return "nu <= 0 or nu > 1"; 
/*      */     }
/* 2687 */     if (svm_type == 3 && 
/* 2688 */       param.p < 0.0D) {
/* 2689 */       return "p < 0";
/*      */     }
/* 2691 */     if (param.shrinking != 0 && param.shrinking != 1)
/*      */     {
/* 2693 */       return "shrinking != 0 and shrinking != 1";
/*      */     }
/* 2695 */     if (param.probability != 0 && param.probability != 1)
/*      */     {
/* 2697 */       return "probability != 0 and probability != 1";
/*      */     }
/* 2699 */     if (param.probability == 1 && svm_type == 2)
/*      */     {
/* 2701 */       return "one-class SVM probability output not supported yet";
/*      */     }
/*      */ 
/*      */     
/* 2705 */     if (svm_type == 1) {
/*      */       
/* 2707 */       int l = prob.l;
/* 2708 */       int max_nr_class = 16;
/* 2709 */       int nr_class = 0;
/* 2710 */       int[] label = new int[max_nr_class];
/* 2711 */       int[] count = new int[max_nr_class];
/*      */       
/*      */       int i;
/* 2714 */       for (i = 0; i < l; i++) {
/*      */         
/* 2716 */         int this_label = (int)prob.y[i];
/*      */         int j;
/* 2718 */         for (j = 0; j < nr_class; j++) {
/* 2719 */           if (this_label == label[j]) {
/*      */             
/* 2721 */             count[j] = count[j] + 1;
/*      */             break;
/*      */           } 
/*      */         } 
/* 2725 */         if (j == nr_class) {
/*      */           
/* 2727 */           if (nr_class == max_nr_class) {
/*      */             
/* 2729 */             max_nr_class *= 2;
/* 2730 */             int[] new_data = new int[max_nr_class];
/* 2731 */             System.arraycopy(label, 0, new_data, 0, label.length);
/* 2732 */             label = new_data;
/*      */             
/* 2734 */             new_data = new int[max_nr_class];
/* 2735 */             System.arraycopy(count, 0, new_data, 0, count.length);
/* 2736 */             count = new_data;
/*      */           } 
/* 2738 */           label[nr_class] = this_label;
/* 2739 */           count[nr_class] = 1;
/* 2740 */           nr_class++;
/*      */         } 
/*      */       } 
/*      */       
/* 2744 */       for (i = 0; i < nr_class; i++) {
/*      */         
/* 2746 */         int n1 = count[i];
/* 2747 */         for (int j = i + 1; j < nr_class; j++) {
/*      */           
/* 2749 */           int n2 = count[j];
/* 2750 */           if (param.nu * (n1 + n2) / 2.0D > Math.min(n1, n2)) {
/* 2751 */             return "specified nu is infeasible";
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/* 2756 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int svm_check_probability_model(svm_model model) {
/* 2761 */     if (((model.param.svm_type == 0 || model.param.svm_type == 1) && model.probA != null && model.probB != null) || ((model.param.svm_type == 3 || model.param.svm_type == 4) && model.probA != null))
/*      */     {
/*      */ 
/*      */       
/* 2765 */       return 1;
/*      */     }
/* 2767 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void svm_set_print_string_function(svm_print_interface print_func) {
/* 2772 */     if (print_func == null) {
/* 2773 */       svm_print_string = svm_print_stdout;
/*      */     } else {
/* 2775 */       svm_print_string = print_func;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\svm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */