/*      */ package libsvm;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class Solver_NU
/*      */   extends Solver
/*      */ {
/*      */   private Solver.SolutionInfo si;
/*      */   
/*      */   void Solve(int l, QMatrix Q, double[] p, byte[] y, double[] alpha, double Cp, double Cn, double eps, Solver.SolutionInfo si, int shrinking) {
/*  891 */     this.si = si;
/*  892 */     super.Solve(l, Q, p, y, alpha, Cp, Cn, eps, si, shrinking);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int select_working_set(int[] working_set) {
/*  904 */     double Gmaxp = Double.NEGATIVE_INFINITY;
/*  905 */     double Gmaxp2 = Double.NEGATIVE_INFINITY;
/*  906 */     int Gmaxp_idx = -1;
/*      */     
/*  908 */     double Gmaxn = Double.NEGATIVE_INFINITY;
/*  909 */     double Gmaxn2 = Double.NEGATIVE_INFINITY;
/*  910 */     int Gmaxn_idx = -1;
/*      */     
/*  912 */     int Gmin_idx = -1;
/*  913 */     double obj_diff_min = Double.POSITIVE_INFINITY;
/*      */     
/*  915 */     for (int t = 0; t < this.active_size; t++) {
/*  916 */       if (this.y[t] == 1) {
/*      */         
/*  918 */         if (!is_upper_bound(t) && 
/*  919 */           -this.G[t] >= Gmaxp)
/*      */         {
/*  921 */           Gmaxp = -this.G[t];
/*  922 */           Gmaxp_idx = t;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  927 */       else if (!is_lower_bound(t) && 
/*  928 */         this.G[t] >= Gmaxn) {
/*      */         
/*  930 */         Gmaxn = this.G[t];
/*  931 */         Gmaxn_idx = t;
/*      */       } 
/*      */     } 
/*      */     
/*  935 */     int ip = Gmaxp_idx;
/*  936 */     int in = Gmaxn_idx;
/*  937 */     float[] Q_ip = null;
/*  938 */     float[] Q_in = null;
/*  939 */     if (ip != -1)
/*  940 */       Q_ip = this.Q.get_Q(ip, this.active_size); 
/*  941 */     if (in != -1) {
/*  942 */       Q_in = this.Q.get_Q(in, this.active_size);
/*      */     }
/*  944 */     for (int j = 0; j < this.active_size; j++) {
/*      */       
/*  946 */       if (this.y[j] == 1) {
/*      */         
/*  948 */         if (!is_lower_bound(j))
/*      */         {
/*  950 */           double grad_diff = Gmaxp + this.G[j];
/*  951 */           if (this.G[j] >= Gmaxp2)
/*  952 */             Gmaxp2 = this.G[j]; 
/*  953 */           if (grad_diff > 0.0D)
/*      */           {
/*      */             
/*  956 */             double obj_diff, quad_coef = this.QD[ip] + this.QD[j] - (2.0F * Q_ip[j]);
/*  957 */             if (quad_coef > 0.0D) {
/*  958 */               obj_diff = -(grad_diff * grad_diff) / quad_coef;
/*      */             } else {
/*  960 */               obj_diff = -(grad_diff * grad_diff) / 1.0E-12D;
/*      */             } 
/*  962 */             if (obj_diff <= obj_diff_min)
/*      */             {
/*  964 */               Gmin_idx = j;
/*  965 */               obj_diff_min = obj_diff;
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */       
/*  972 */       } else if (!is_upper_bound(j)) {
/*      */         
/*  974 */         double grad_diff = Gmaxn - this.G[j];
/*  975 */         if (-this.G[j] >= Gmaxn2)
/*  976 */           Gmaxn2 = -this.G[j]; 
/*  977 */         if (grad_diff > 0.0D) {
/*      */ 
/*      */           
/*  980 */           double obj_diff, quad_coef = this.QD[in] + this.QD[j] - (2.0F * Q_in[j]);
/*  981 */           if (quad_coef > 0.0D) {
/*  982 */             obj_diff = -(grad_diff * grad_diff) / quad_coef;
/*      */           } else {
/*  984 */             obj_diff = -(grad_diff * grad_diff) / 1.0E-12D;
/*      */           } 
/*  986 */           if (obj_diff <= obj_diff_min) {
/*      */             
/*  988 */             Gmin_idx = j;
/*  989 */             obj_diff_min = obj_diff;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  996 */     if (Math.max(Gmaxp + Gmaxp2, Gmaxn + Gmaxn2) < this.eps) {
/*  997 */       return 1;
/*      */     }
/*  999 */     if (this.y[Gmin_idx] == 1) {
/* 1000 */       working_set[0] = Gmaxp_idx;
/*      */     } else {
/* 1002 */       working_set[0] = Gmaxn_idx;
/* 1003 */     }  working_set[1] = Gmin_idx;
/*      */     
/* 1005 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean be_shrunk(int i, double Gmax1, double Gmax2, double Gmax3, double Gmax4) {
/* 1010 */     if (is_upper_bound(i)) {
/*      */       
/* 1012 */       if (this.y[i] == 1) {
/* 1013 */         return (-this.G[i] > Gmax1);
/*      */       }
/* 1015 */       return (-this.G[i] > Gmax4);
/*      */     } 
/* 1017 */     if (is_lower_bound(i)) {
/*      */       
/* 1019 */       if (this.y[i] == 1) {
/* 1020 */         return (this.G[i] > Gmax2);
/*      */       }
/* 1022 */       return (this.G[i] > Gmax3);
/*      */     } 
/*      */     
/* 1025 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   void do_shrinking() {
/* 1030 */     double Gmax1 = Double.NEGATIVE_INFINITY;
/* 1031 */     double Gmax2 = Double.NEGATIVE_INFINITY;
/* 1032 */     double Gmax3 = Double.NEGATIVE_INFINITY;
/* 1033 */     double Gmax4 = Double.NEGATIVE_INFINITY;
/*      */     
/*      */     int i;
/*      */     
/* 1037 */     for (i = 0; i < this.active_size; i++) {
/*      */       
/* 1039 */       if (!is_upper_bound(i))
/*      */       {
/* 1041 */         if (this.y[i] == 1)
/*      */         
/* 1043 */         { if (-this.G[i] > Gmax1) Gmax1 = -this.G[i];
/*      */            }
/* 1045 */         else if (-this.G[i] > Gmax4) { Gmax4 = -this.G[i]; }
/*      */          } 
/* 1047 */       if (!is_lower_bound(i))
/*      */       {
/* 1049 */         if (this.y[i] == 1)
/*      */         
/* 1051 */         { if (this.G[i] > Gmax2) Gmax2 = this.G[i];
/*      */            }
/* 1053 */         else if (this.G[i] > Gmax3) { Gmax3 = this.G[i]; }
/*      */       
/*      */       }
/*      */     } 
/* 1057 */     if (!this.unshrink && Math.max(Gmax1 + Gmax2, Gmax3 + Gmax4) <= this.eps * 10.0D) {
/*      */       
/* 1059 */       this.unshrink = true;
/* 1060 */       reconstruct_gradient();
/* 1061 */       this.active_size = this.l;
/*      */     } 
/*      */     
/* 1064 */     for (i = 0; i < this.active_size; i++) {
/* 1065 */       if (be_shrunk(i, Gmax1, Gmax2, Gmax3, Gmax4)) {
/*      */         
/* 1067 */         this.active_size--;
/* 1068 */         while (this.active_size > i) {
/*      */           
/* 1070 */           if (!be_shrunk(this.active_size, Gmax1, Gmax2, Gmax3, Gmax4)) {
/*      */             
/* 1072 */             swap_index(i, this.active_size);
/*      */             break;
/*      */           } 
/* 1075 */           this.active_size--;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   double calculate_rho() {
/*      */     double r2;
/* 1082 */     int nr_free1 = 0, nr_free2 = 0;
/* 1083 */     double ub1 = Double.POSITIVE_INFINITY, ub2 = Double.POSITIVE_INFINITY;
/* 1084 */     double lb1 = Double.NEGATIVE_INFINITY, lb2 = Double.NEGATIVE_INFINITY;
/* 1085 */     double sum_free1 = 0.0D, sum_free2 = 0.0D;
/*      */     double r1;
/* 1087 */     for (r1 = false; r1 < this.active_size; r1++) {
/*      */       
/* 1089 */       if (this.y[r1] == 1) {
/*      */         
/* 1091 */         if (is_lower_bound(r1)) {
/* 1092 */           ub1 = Math.min(ub1, this.G[r1]);
/* 1093 */         } else if (is_upper_bound(r1)) {
/* 1094 */           lb1 = Math.max(lb1, this.G[r1]);
/*      */         } else {
/*      */           
/* 1097 */           nr_free1++;
/* 1098 */           sum_free1 += this.G[r1];
/*      */         
/*      */         }
/*      */       
/*      */       }
/* 1103 */       else if (is_lower_bound(r1)) {
/* 1104 */         ub2 = Math.min(ub2, this.G[r1]);
/* 1105 */       } else if (is_upper_bound(r1)) {
/* 1106 */         lb2 = Math.max(lb2, this.G[r1]);
/*      */       } else {
/*      */         
/* 1109 */         nr_free2++;
/* 1110 */         sum_free2 += this.G[r1];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1116 */     if (nr_free1 > 0) {
/* 1117 */       double r1 = sum_free1 / nr_free1;
/*      */     } else {
/* 1119 */       r1 = (ub1 + lb1) / 2.0D;
/*      */     } 
/* 1121 */     if (nr_free2 > 0) {
/* 1122 */       r2 = sum_free2 / nr_free2;
/*      */     } else {
/* 1124 */       r2 = (ub2 + lb2) / 2.0D;
/*      */     } 
/* 1126 */     this.si.r = (r1 + r2) / 2.0D;
/* 1127 */     return (r1 - r2) / 2.0D;
/*      */   }
/*      */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\libsvm\Solver_NU.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */