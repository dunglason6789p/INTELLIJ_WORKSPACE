/*     */ package de.bwaldvogel.liblinear;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Formatter;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Predict
/*     */ {
/*     */   private static boolean flag_predict_probability = false;
/*  29 */   private static final Pattern COLON = Pattern.compile(":");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void doPredict(BufferedReader reader, Writer writer, Model model) throws IOException {
/*  35 */     int n, correct = 0;
/*  36 */     int total = 0;
/*     */     
/*  38 */     int nr_class = model.getNrClass();
/*  39 */     double[] prob_estimates = null;
/*     */     
/*  41 */     int nr_feature = model.getNrFeature();
/*  42 */     if (model.bias >= 0.0D) {
/*  43 */       n = nr_feature + 1;
/*     */     } else {
/*  45 */       n = nr_feature;
/*     */     } 
/*  47 */     Formatter out = new Formatter(writer);
/*     */     
/*  49 */     if (flag_predict_probability) {
/*  50 */       if (!model.isProbabilityModel()) {
/*  51 */         throw new IllegalArgumentException("probability output is only supported for logistic regression");
/*     */       }
/*     */       
/*  54 */       int[] labels = model.getLabels();
/*  55 */       prob_estimates = new double[nr_class];
/*     */       
/*  57 */       Linear.printf(out, "labels", new Object[0]);
/*  58 */       for (int j = 0; j < nr_class; j++) {
/*  59 */         Linear.printf(out, " %d", new Object[] { Integer.valueOf(labels[j]) });
/*  60 */       }  Linear.printf(out, "\n", new Object[0]);
/*     */     } 
/*     */ 
/*     */     
/*  64 */     String line = null;
/*  65 */     while ((line = reader.readLine()) != null) {
/*  66 */       int predict_label, target_label; List<FeatureNode> x = new ArrayList<FeatureNode>();
/*  67 */       StringTokenizer st = new StringTokenizer(line, " \t\n");
/*     */       
/*     */       try {
/*  70 */         String label = st.nextToken();
/*  71 */         target_label = Linear.atoi(label);
/*  72 */       } catch (NoSuchElementException e) {
/*  73 */         throw new RuntimeException("Wrong input format at line " + (total + 1), e);
/*     */       } 
/*     */       
/*  76 */       while (st.hasMoreTokens()) {
/*  77 */         String[] split = COLON.split(st.nextToken(), 2);
/*  78 */         if (split == null || split.length < 2) {
/*  79 */           throw new RuntimeException("Wrong input format at line " + (total + 1));
/*     */         }
/*     */         
/*     */         try {
/*  83 */           predict_label = Linear.atoi(split[0]);
/*  84 */           double val = Linear.atof(split[1]);
/*     */ 
/*     */           
/*  87 */           if (predict_label <= nr_feature) {
/*  88 */             FeatureNode node = new FeatureNode(predict_label, val);
/*  89 */             x.add(node);
/*     */           } 
/*  91 */         } catch (NumberFormatException e) {
/*  92 */           throw new RuntimeException("Wrong input format at line " + (total + 1), e);
/*     */         } 
/*     */       } 
/*     */       
/*  96 */       if (model.bias >= 0.0D) {
/*  97 */         FeatureNode node = new FeatureNode(n, model.bias);
/*  98 */         x.add(node);
/*     */       } 
/*     */       
/* 101 */       FeatureNode[] nodes = new FeatureNode[x.size()];
/* 102 */       nodes = (FeatureNode[])x.toArray(nodes);
/*     */ 
/*     */ 
/*     */       
/* 106 */       if (flag_predict_probability) {
/* 107 */         assert prob_estimates != null;
/* 108 */         predict_label = Linear.predictProbability(model, nodes, prob_estimates);
/* 109 */         Linear.printf(out, "%d", new Object[] { Integer.valueOf(predict_label) });
/* 110 */         for (int j = 0; j < model.nr_class; j++) {
/* 111 */           Linear.printf(out, " %g", new Object[] { Double.valueOf(prob_estimates[j]) });
/* 112 */         }  Linear.printf(out, "\n", new Object[0]);
/*     */       } else {
/* 114 */         predict_label = Linear.predict(model, nodes);
/* 115 */         Linear.printf(out, "%d\n", new Object[] { Integer.valueOf(predict_label) });
/*     */       } 
/*     */       
/* 118 */       if (predict_label == target_label) {
/* 119 */         correct++;
/*     */       }
/* 121 */       total++;
/*     */     } 
/* 123 */     System.out.printf("Accuracy = %g%% (%d/%d)%n", new Object[] { Double.valueOf(correct / total * 100.0D), Integer.valueOf(correct), Integer.valueOf(total) });
/*     */   }
/*     */   
/*     */   private static void exit_with_help() {
/* 127 */     System.out.printf("Usage: predict [options] test_file model_file output_file%noptions:%n-b probability_estimates: whether to output probability estimates, 0 or 1 (default 0)%n", new Object[0]);
/*     */     
/* 129 */     System.exit(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] argv) throws IOException {
/*     */     int i;
/* 136 */     for (i = 0; i < argv.length && 
/* 137 */       argv[i].charAt(0) == '-'; i++) {
/* 138 */       i++;
/* 139 */       switch (argv[i - 1].charAt(1)) {
/*     */         case 'b':
/*     */           try {
/* 142 */             flag_predict_probability = (Linear.atoi(argv[i]) != 0);
/* 143 */           } catch (NumberFormatException e) {
/* 144 */             exit_with_help();
/*     */           } 
/*     */           break;
/*     */         
/*     */         default:
/* 149 */           System.err.printf("unknown option: -%d%n", new Object[] { Character.valueOf(argv[i - 1].charAt(1)) });
/* 150 */           exit_with_help();
/*     */           break;
/*     */       } 
/*     */     } 
/* 154 */     if (i >= argv.length || argv.length <= i + 2) {
/* 155 */       exit_with_help();
/*     */     }
/*     */     
/* 158 */     reader = null;
/* 159 */     writer = null;
/*     */     try {
/* 161 */       reader = new BufferedReader(new InputStreamReader(new FileInputStream(argv[i]), Linear.FILE_CHARSET));
/* 162 */       writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(argv[i + 2]), Linear.FILE_CHARSET));
/*     */       
/* 164 */       Model model = Linear.loadModel(new File(argv[i + 1]));
/* 165 */       doPredict(reader, writer, model);
/*     */     } finally {
/*     */       
/* 168 */       Linear.closeQuietly(reader);
/* 169 */       Linear.closeQuietly(writer);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\Predict.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */