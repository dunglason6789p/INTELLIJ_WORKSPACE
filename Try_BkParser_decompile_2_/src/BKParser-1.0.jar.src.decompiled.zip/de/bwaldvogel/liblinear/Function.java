package de.bwaldvogel.liblinear;

interface Function {
  double fun(double[] paramArrayOfDouble);
  
  void grad(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
  
  void Hv(double[] paramArrayOfDouble1, double[] paramArrayOfDouble2);
  
  int get_nr_variable();
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */