/*    */ package de.bwaldvogel.liblinear;
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DoubleArrayPointer
/*    */ {
/*    */   private final double[] _array;
/*    */   private int _offset;
/*    */   
/*    */   public void setOffset(int offset) {
/* 11 */     if (offset < 0 || offset >= this._array.length) throw new IllegalArgumentException("offset must be between 0 and the length of the array"); 
/* 12 */     this._offset = offset;
/*    */   }
/*    */   
/*    */   public DoubleArrayPointer(double[] array, int offset) {
/* 16 */     this._array = array;
/* 17 */     setOffset(offset);
/*    */   }
/*    */ 
/*    */   
/* 21 */   public double get(int index) { return this._array[this._offset + index]; }
/*    */ 
/*    */ 
/*    */   
/* 25 */   public void set(int index, double value) { this._array[this._offset + index] = value; }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\DoubleArrayPointer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */