/*    */ package de.bwaldvogel.liblinear;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ArraySorter
/*    */ {
/* 12 */   public static void reversedMergesort(double[] a) { reversedMergesort(a, 0, a.length); }
/*    */ 
/*    */ 
/*    */   
/*    */   private static void reversedMergesort(double[] x, int off, int len) {
/* 17 */     if (len < 7) {
/* 18 */       for (int i = off; i < len + off; i++) {
/* 19 */         for (int j = i; j > off && x[j - 1] < x[j]; j--) {
/* 20 */           swap(x, j, j - 1);
/*    */         }
/*    */       } 
/*    */       return;
/*    */     } 
/* 25 */     int m = off + (len >> 1);
/* 26 */     if (len > 7) {
/* 27 */       int l = off;
/* 28 */       int n = off + len - 1;
/* 29 */       if (len > 40) {
/* 30 */         int s = len / 8;
/* 31 */         l = med3(x, l, l + s, l + 2 * s);
/* 32 */         m = med3(x, m - s, m, m + s);
/* 33 */         n = med3(x, n - 2 * s, n - s, n);
/*    */       } 
/* 35 */       m = med3(x, l, m, n);
/*    */     } 
/* 37 */     double v = x[m];
/*    */ 
/*    */     
/* 40 */     int a = off, b = a, c = off + len - 1, d = c;
/*    */     while (true) {
/* 42 */       if (b <= c && x[b] >= v) {
/* 43 */         if (x[b] == v) swap(x, a++, b); 
/* 44 */         b++; continue;
/*    */       } 
/* 46 */       while (c >= b && x[c] <= v) {
/* 47 */         if (x[c] == v) swap(x, c, d--); 
/* 48 */         c--;
/*    */       } 
/* 50 */       if (b > c)
/* 51 */         break;  swap(x, b++, c--);
/*    */     } 
/*    */ 
/*    */     
/* 55 */     int n = off + len;
/* 56 */     int s = Math.min(a - off, b - a);
/* 57 */     vecswap(x, off, b - s, s);
/* 58 */     s = Math.min(d - c, n - d - 1);
/* 59 */     vecswap(x, b, n - s, s);
/*    */ 
/*    */     
/* 62 */     if ((s = b - a) > 1) reversedMergesort(x, off, s); 
/* 63 */     if ((s = d - c) > 1) reversedMergesort(x, n - s, s);
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static void swap(double[] x, int a, int b) {
/* 70 */     double t = x[a];
/* 71 */     x[a] = x[b];
/* 72 */     x[b] = t;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static void vecswap(double[] x, int a, int b, int n) {
/* 79 */     for (int i = 0; i < n; i++, a++, b++) {
/* 80 */       swap(x, a, b);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 87 */   private static int med3(double[] x, int a, int b, int c) { return (x[a] < x[b]) ? ((x[b] < x[c]) ? b : ((x[a] < x[c]) ? c : a)) : ((x[b] > x[c]) ? b : ((x[a] > x[c]) ? c : a)); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\ArraySorter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */