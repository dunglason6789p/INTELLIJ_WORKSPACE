/*    */ package de.bwaldvogel.liblinear;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Parameter
/*    */ {
/*    */   double C;
/*    */   double eps;
/*    */   SolverType solverType;
/*    */   double[] weight;
/*    */   int[] weightLabel;
/*    */   
/*    */   public Parameter(SolverType solverType, double C, double eps) {
/* 15 */     this.weight = null;
/*    */     
/* 17 */     this.weightLabel = null;
/*    */ 
/*    */     
/* 20 */     setSolverType(solverType);
/* 21 */     setC(C);
/* 22 */     setEps(eps);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setWeights(double[] weights, int[] weightLabels) {
/* 38 */     if (weights == null) throw new IllegalArgumentException("'weight' must not be null"); 
/* 39 */     if (weightLabels == null || weightLabels.length != weights.length)
/* 40 */       throw new IllegalArgumentException("'weightLabels' must have same length as 'weight'"); 
/* 41 */     this.weightLabel = Linear.copyOf(weightLabels, weightLabels.length);
/* 42 */     this.weight = Linear.copyOf(weights, weights.length);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   public double[] getWeights() { return Linear.copyOf(this.weight, this.weight.length); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 56 */   public int[] getWeightLabels() { return Linear.copyOf(this.weightLabel, this.weightLabel.length); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getNumWeights() {
/* 64 */     if (this.weight == null) return 0; 
/* 65 */     return this.weight.length;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setC(double C) {
/* 72 */     if (C <= 0.0D) throw new IllegalArgumentException("C must not be <= 0"); 
/* 73 */     this.C = C;
/*    */   }
/*    */ 
/*    */   
/* 77 */   public double getC() { return this.C; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setEps(double eps) {
/* 84 */     if (eps <= 0.0D) throw new IllegalArgumentException("eps must not be <= 0"); 
/* 85 */     this.eps = eps;
/*    */   }
/*    */ 
/*    */   
/* 89 */   public double getEps() { return this.eps; }
/*    */ 
/*    */   
/*    */   public void setSolverType(SolverType solverType) {
/* 93 */     if (solverType == null) throw new IllegalArgumentException("solver type must not be null"); 
/* 94 */     this.solverType = solverType;
/*    */   }
/*    */ 
/*    */   
/* 98 */   public SolverType getSolverType() { return this.solverType; }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\Parameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */