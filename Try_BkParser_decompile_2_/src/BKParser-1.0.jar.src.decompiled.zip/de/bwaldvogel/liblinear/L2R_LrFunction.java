/*     */ package de.bwaldvogel.liblinear;
/*     */ 
/*     */ class L2R_LrFunction
/*     */   implements Function
/*     */ {
/*     */   private final double[] C;
/*     */   private final double[] z;
/*     */   private final double[] D;
/*     */   private final Problem prob;
/*     */   
/*     */   public L2R_LrFunction(Problem prob, double Cp, double Cn) {
/*  12 */     int l = prob.l;
/*  13 */     int[] y = prob.y;
/*     */     
/*  15 */     this.prob = prob;
/*     */     
/*  17 */     this.z = new double[l];
/*  18 */     this.D = new double[l];
/*  19 */     this.C = new double[l];
/*     */     
/*  21 */     for (int i = 0; i < l; i++) {
/*  22 */       if (y[i] == 1) {
/*  23 */         this.C[i] = Cp;
/*     */       } else {
/*  25 */         this.C[i] = Cn;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void Xv(double[] v, double[] Xv) {
/*  32 */     for (int i = 0; i < this.prob.l; i++) {
/*  33 */       Xv[i] = 0.0D;
/*  34 */       for (FeatureNode s : this.prob.x[i]) {
/*  35 */         Xv[i] = Xv[i] + v[s.index - 1] * s.value;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void XTv(double[] v, double[] XTv) {
/*  41 */     int l = this.prob.l;
/*  42 */     int w_size = get_nr_variable();
/*  43 */     FeatureNode[][] x = this.prob.x;
/*     */     
/*  45 */     for (int i = 0; i < w_size; i++) {
/*  46 */       XTv[i] = 0.0D;
/*     */     }
/*  48 */     for (int i = 0; i < l; i++) {
/*  49 */       for (FeatureNode s : x[i]) {
/*  50 */         XTv[s.index - 1] = XTv[s.index - 1] + v[i] * s.value;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double fun(double[] w) {
/*  58 */     f = 0.0D;
/*  59 */     int[] y = this.prob.y;
/*  60 */     int l = this.prob.l;
/*  61 */     int w_size = get_nr_variable();
/*     */     
/*  63 */     Xv(w, this.z); int i;
/*  64 */     for (i = 0; i < l; i++) {
/*  65 */       double yz = y[i] * this.z[i];
/*  66 */       if (yz >= 0.0D) {
/*  67 */         f += this.C[i] * Math.log(1.0D + Math.exp(-yz));
/*     */       } else {
/*  69 */         f += this.C[i] * (-yz + Math.log(1.0D + Math.exp(yz)));
/*     */       } 
/*  71 */     }  f = 2.0D * f;
/*  72 */     for (i = 0; i < w_size; i++)
/*  73 */       f += w[i] * w[i]; 
/*  74 */     return 2.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void grad(double[] w, double[] g) {
/*  81 */     int[] y = this.prob.y;
/*  82 */     int l = this.prob.l;
/*  83 */     int w_size = get_nr_variable();
/*     */     int i;
/*  85 */     for (i = 0; i < l; i++) {
/*  86 */       this.z[i] = 1.0D / (1.0D + Math.exp(-y[i] * this.z[i]));
/*  87 */       this.D[i] = this.z[i] * (1.0D - this.z[i]);
/*  88 */       this.z[i] = this.C[i] * (this.z[i] - 1.0D) * y[i];
/*     */     } 
/*  90 */     XTv(this.z, g);
/*     */     
/*  92 */     for (i = 0; i < w_size; i++) {
/*  93 */       g[i] = w[i] + g[i];
/*     */     }
/*     */   }
/*     */   
/*     */   public void Hv(double[] s, double[] Hs) {
/*  98 */     int l = this.prob.l;
/*  99 */     int w_size = get_nr_variable();
/* 100 */     double[] wa = new double[l];
/*     */     
/* 102 */     Xv(s, wa); int i;
/* 103 */     for (i = 0; i < l; i++) {
/* 104 */       wa[i] = this.C[i] * this.D[i] * wa[i];
/*     */     }
/* 106 */     XTv(wa, Hs);
/* 107 */     for (i = 0; i < w_size; i++) {
/* 108 */       Hs[i] = s[i] + Hs[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 113 */   public int get_nr_variable() { return this.prob.n; }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\L2R_LrFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */