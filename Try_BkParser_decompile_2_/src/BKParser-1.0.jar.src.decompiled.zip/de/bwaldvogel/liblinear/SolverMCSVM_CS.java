/*     */ package de.bwaldvogel.liblinear;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SolverMCSVM_CS
/*     */ {
/*     */   private final double[] B;
/*     */   private final double[] C;
/*     */   private final double eps;
/*     */   private final double[] G;
/*     */   private final int max_iter;
/*     */   private final int w_size;
/*     */   private final int l;
/*     */   private final int nr_class;
/*     */   private final Problem prob;
/*     */   
/*  43 */   public SolverMCSVM_CS(Problem prob, int nr_class, double[] C) { this(prob, nr_class, C, 0.1D); }
/*     */ 
/*     */ 
/*     */   
/*  47 */   public SolverMCSVM_CS(Problem prob, int nr_class, double[] C, double eps) { this(prob, nr_class, C, eps, 100000); }
/*     */ 
/*     */ 
/*     */   
/*     */   public SolverMCSVM_CS(Problem prob, int nr_class, double[] weighted_C, double eps, int max_iter) {
/*  52 */     this.w_size = prob.n;
/*  53 */     this.l = prob.l;
/*  54 */     this.nr_class = nr_class;
/*  55 */     this.eps = eps;
/*  56 */     this.max_iter = max_iter;
/*  57 */     this.prob = prob;
/*  58 */     this.C = weighted_C;
/*  59 */     this.B = new double[nr_class];
/*  60 */     this.G = new double[nr_class];
/*     */   }
/*     */ 
/*     */   
/*  64 */   private int GETI(int i) { return this.prob.y[i]; }
/*     */ 
/*     */   
/*     */   private boolean be_shrunk(int i, int m, int yi, double alpha_i, double minG) {
/*  68 */     double bound = 0.0D;
/*  69 */     if (m == yi) bound = this.C[GETI(i)]; 
/*  70 */     if (alpha_i == bound && this.G[m] < minG) return true; 
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void solve(double[] w) {
/*  76 */     int iter = 0;
/*  77 */     double[] alpha = new double[this.l * this.nr_class];
/*  78 */     double[] alpha_new = new double[this.nr_class];
/*  79 */     int[] index = new int[this.l];
/*  80 */     double[] QD = new double[this.l];
/*  81 */     int[] d_ind = new int[this.nr_class];
/*  82 */     double[] d_val = new double[this.nr_class];
/*  83 */     int[] alpha_index = new int[this.nr_class * this.l];
/*  84 */     int[] y_index = new int[this.l];
/*  85 */     int active_size = this.l;
/*  86 */     int[] active_size_i = new int[this.l];
/*  87 */     double eps_shrink = Math.max(10.0D * this.eps, 1.0D);
/*  88 */     boolean start_from_all = true;
/*     */     int i;
/*  90 */     for (i = 0; i < this.l * this.nr_class; i++)
/*  91 */       alpha[i] = 0.0D; 
/*  92 */     for (i = 0; i < this.w_size * this.nr_class; i++)
/*  93 */       w[i] = 0.0D; 
/*  94 */     for (i = 0; i < this.l; i++) {
/*  95 */       for (int m = 0; m < this.nr_class; m++)
/*  96 */         alpha_index[i * this.nr_class + m] = m; 
/*  97 */       QD[i] = 0.0D;
/*  98 */       for (FeatureNode xi : this.prob.x[i]) {
/*  99 */         QD[i] = QD[i] + xi.value * xi.value;
/*     */       }
/* 101 */       active_size_i[i] = this.nr_class;
/* 102 */       y_index[i] = this.prob.y[i];
/* 103 */       index[i] = i;
/*     */     } 
/*     */     
/* 106 */     DoubleArrayPointer alpha_i = new DoubleArrayPointer(alpha, 0);
/* 107 */     IntArrayPointer alpha_index_i = new IntArrayPointer(alpha_index, 0);
/*     */     
/* 109 */     while (iter < this.max_iter) {
/* 110 */       double stopping = Double.NEGATIVE_INFINITY;
/*     */       
/* 112 */       for (i = 0; i < active_size; i++) {
/*     */         
/* 114 */         int j = i + Linear.random.nextInt(active_size - i);
/* 115 */         Linear.swap(index, i, j);
/*     */       } 
/* 117 */       for (int s = 0; s < active_size; s++) {
/*     */         
/* 119 */         i = index[s];
/* 120 */         double Ai = QD[i];
/*     */         
/* 122 */         alpha_i.setOffset(i * this.nr_class);
/*     */ 
/*     */         
/* 125 */         alpha_index_i.setOffset(i * this.nr_class);
/*     */         
/* 127 */         if (Ai > 0.0D) {
/* 128 */           int m; for (m = 0; m < active_size_i[i]; m++)
/* 129 */             this.G[m] = 1.0D; 
/* 130 */           if (y_index[i] < active_size_i[i]) this.G[y_index[i]] = 0.0D;
/*     */           
/* 132 */           for (FeatureNode xi : this.prob.x[i]) {
/*     */             
/* 134 */             int w_offset = (xi.index - 1) * this.nr_class;
/* 135 */             for (m = 0; m < active_size_i[i]; m++)
/*     */             {
/* 137 */               this.G[m] = this.G[m] + w[w_offset + alpha_index_i.get(m)] * xi.value;
/*     */             }
/*     */           } 
/*     */           
/* 141 */           double minG = Double.POSITIVE_INFINITY;
/* 142 */           double maxG = Double.NEGATIVE_INFINITY;
/* 143 */           for (m = 0; m < active_size_i[i]; m++) {
/* 144 */             if (alpha_i.get(alpha_index_i.get(m)) < 0.0D && this.G[m] < minG) minG = this.G[m]; 
/* 145 */             if (this.G[m] > maxG) maxG = this.G[m]; 
/*     */           } 
/* 147 */           if (y_index[i] < active_size_i[i] && 
/* 148 */             alpha_i.get(this.prob.y[i]) < this.C[GETI(i)] && this.G[y_index[i]] < minG) {
/* 149 */             minG = this.G[y_index[i]];
/*     */           }
/*     */ 
/*     */           
/* 153 */           for (m = 0; m < active_size_i[i]; m++) {
/* 154 */             if (be_shrunk(i, m, y_index[i], alpha_i.get(alpha_index_i.get(m)), minG)) {
/* 155 */               active_size_i[i] = active_size_i[i] - 1;
/* 156 */               while (active_size_i[i] > m) {
/* 157 */                 if (!be_shrunk(i, active_size_i[i], y_index[i], alpha_i.get(alpha_index_i.get(active_size_i[i])), minG)) {
/* 158 */                   Linear.swap(alpha_index_i, m, active_size_i[i]);
/* 159 */                   Linear.swap(this.G, m, active_size_i[i]);
/* 160 */                   if (y_index[i] == active_size_i[i]) {
/* 161 */                     y_index[i] = m; break;
/* 162 */                   }  if (y_index[i] == m) y_index[i] = active_size_i[i]; 
/*     */                   break;
/*     */                 } 
/* 165 */                 active_size_i[i] = active_size_i[i] - 1;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 170 */           if (active_size_i[i] <= 1) {
/* 171 */             active_size--;
/* 172 */             Linear.swap(index, s, active_size);
/* 173 */             s--;
/*     */ 
/*     */           
/*     */           }
/* 177 */           else if (maxG - minG > 1.0E-12D) {
/*     */ 
/*     */             
/* 180 */             stopping = Math.max(maxG - minG, stopping);
/*     */             
/* 182 */             for (m = 0; m < active_size_i[i]; m++) {
/* 183 */               this.B[m] = this.G[m] - Ai * alpha_i.get(alpha_index_i.get(m));
/*     */             }
/* 185 */             solve_sub_problem(Ai, y_index[i], this.C[GETI(i)], active_size_i[i], alpha_new);
/* 186 */             int nz_d = 0;
/* 187 */             for (m = 0; m < active_size_i[i]; m++) {
/* 188 */               double d = alpha_new[m] - alpha_i.get(alpha_index_i.get(m));
/* 189 */               alpha_i.set(alpha_index_i.get(m), alpha_new[m]);
/* 190 */               if (Math.abs(d) >= 1.0E-12D) {
/* 191 */                 d_ind[nz_d] = alpha_index_i.get(m);
/* 192 */                 d_val[nz_d] = d;
/* 193 */                 nz_d++;
/*     */               } 
/*     */             } 
/*     */             
/* 197 */             for (FeatureNode xi : this.prob.x[i]) {
/*     */               
/* 199 */               int w_offset = (xi.index - 1) * this.nr_class;
/* 200 */               for (m = 0; m < nz_d; m++) {
/* 201 */                 w[w_offset + d_ind[m]] = w[w_offset + d_ind[m]] + d_val[m] * xi.value;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 207 */       iter++;
/*     */       
/* 209 */       if (iter % 10 == 0) {
/* 210 */         Linear.info(".");
/*     */       }
/*     */       
/* 213 */       if (stopping < eps_shrink) {
/* 214 */         if (stopping < this.eps && start_from_all == true) {
/*     */           break;
/*     */         }
/* 217 */         active_size = this.l;
/* 218 */         for (i = 0; i < this.l; i++)
/* 219 */           active_size_i[i] = this.nr_class; 
/* 220 */         Linear.info("*");
/* 221 */         eps_shrink = Math.max(eps_shrink / 2.0D, this.eps);
/* 222 */         start_from_all = true;
/*     */         continue;
/*     */       } 
/* 225 */       start_from_all = false;
/*     */     } 
/*     */     
/* 228 */     Linear.info("%noptimization finished, #iter = %d%n", new Object[] { Integer.valueOf(iter) });
/* 229 */     if (iter >= this.max_iter) Linear.info("%nWARNING: reaching max number of iterations%n");
/*     */ 
/*     */     
/* 232 */     double v = 0.0D;
/* 233 */     int nSV = 0;
/* 234 */     for (i = 0; i < this.w_size * this.nr_class; i++)
/* 235 */       v += w[i] * w[i]; 
/* 236 */     v = 0.5D * v;
/* 237 */     for (i = 0; i < this.l * this.nr_class; i++) {
/* 238 */       v += alpha[i];
/* 239 */       if (Math.abs(alpha[i]) > 0.0D) nSV++; 
/*     */     } 
/* 241 */     for (i = 0; i < this.l; i++)
/* 242 */       v -= alpha[i * this.nr_class + this.prob.y[i]]; 
/* 243 */     Linear.info("Objective value = %f%n", new Object[] { Double.valueOf(v) });
/* 244 */     Linear.info("nSV = %d%n", new Object[] { Integer.valueOf(nSV) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void solve_sub_problem(double A_i, int yi, double C_yi, int active_i, double[] alpha_new) {
/* 251 */     assert active_i <= this.B.length;
/* 252 */     double[] D = Linear.copyOf(this.B, active_i);
/*     */ 
/*     */     
/* 255 */     if (yi < active_i) D[yi] = D[yi] + A_i * C_yi;
/*     */ 
/*     */     
/* 258 */     ArraySorter.reversedMergesort(D);
/*     */     
/* 260 */     double beta = D[0] - A_i * C_yi; int r;
/* 261 */     for (r = 1; r < active_i && beta < r * D[r]; r++) {
/* 262 */       beta += D[r];
/*     */     }
/* 264 */     beta /= r;
/* 265 */     for (r = 0; r < active_i; r++) {
/* 266 */       if (r == yi) {
/* 267 */         alpha_new[r] = Math.min(C_yi, (beta - this.B[r]) / A_i);
/*     */       } else {
/* 269 */         alpha_new[r] = Math.min(0.0D, (beta - this.B[r]) / A_i);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\SolverMCSVM_CS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */