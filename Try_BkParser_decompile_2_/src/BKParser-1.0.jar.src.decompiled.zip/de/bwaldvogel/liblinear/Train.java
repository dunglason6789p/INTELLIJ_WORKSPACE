/*     */ package de.bwaldvogel.liblinear;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Train
/*     */ {
/*  19 */   public static void main(String[] args) throws IOException, InvalidInputDataException { (new Train()).run(args); }
/*     */ 
/*     */   
/*  22 */   private double bias = 1.0D;
/*     */   private boolean cross_validation = false;
/*     */   private String inputFilename;
/*     */   private String modelFilename;
/*     */   private int nr_fold;
/*  27 */   private Parameter param = null;
/*  28 */   private Problem prob = null;
/*     */   
/*     */   private void do_cross_validation() {
/*  31 */     int[] target = new int[this.prob.l];
/*     */ 
/*     */     
/*  34 */     long start = System.currentTimeMillis();
/*  35 */     Linear.crossValidation(this.prob, this.param, this.nr_fold, target);
/*  36 */     long stop = System.currentTimeMillis();
/*  37 */     System.out.println("time: " + (stop - start) + " ms");
/*     */     
/*  39 */     int total_correct = 0;
/*  40 */     for (int i = 0; i < this.prob.l; i++) {
/*  41 */       if (target[i] == this.prob.y[i]) total_correct++; 
/*     */     } 
/*  43 */     System.out.printf("correct: %d%n", new Object[] { Integer.valueOf(total_correct) });
/*  44 */     System.out.printf("Cross Validation Accuracy = %g%%%n", new Object[] { Double.valueOf(100.0D * total_correct / this.prob.l) });
/*     */   }
/*     */   
/*     */   private void exit_with_help() {
/*  48 */     System.out.printf("Usage: train [options] training_set_file [model_file]%noptions:%n-s type : set type of solver (default 1)%n   0 -- L2-regularized logistic regression (primal)%n   1 -- L2-regularized L2-loss support vector classification (dual)%n   2 -- L2-regularized L2-loss support vector classification (primal)%n   3 -- L2-regularized L1-loss support vector classification (dual)%n   4 -- multi-class support vector classification by Crammer and Singer%n   5 -- L1-regularized L2-loss support vector classification%n   6 -- L1-regularized logistic regression%n   7 -- L2-regularized logistic regression (dual)%n-c cost : set the parameter C (default 1)%n-e epsilon : set tolerance of termination criterion%n   -s 0 and 2%n       |f'(w)|_2 <= eps*min(pos,neg)/l*|f'(w0)|_2,%n       where f is the primal function and pos/neg are # of%n       positive/negative data (default 0.01)%n   -s 1, 3, 4 and 7%n       Dual maximal violation <= eps; similar to libsvm (default 0.1)%n   -s 5 and 6%n       |f'(w)|_1 <= eps*min(pos,neg)/l*|f'(w0)|_1,%n       where f is the primal function (default 0.01)%n-B bias : if bias >= 0, instance x becomes [x; bias]; if < 0, no bias term added (default -1)%n-wi weight: weights adjust the parameter C of different classes (see README for details)%n-v n: n-fold cross validation mode%n-q : quiet mode (no outputs)%n", new Object[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     System.exit(1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  79 */   Problem getProblem() { return this.prob; }
/*     */ 
/*     */ 
/*     */   
/*  83 */   double getBias() { return this.bias; }
/*     */ 
/*     */ 
/*     */   
/*  87 */   Parameter getParameter() { return this.param; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void parse_command_line(String[] argv) throws IOException, InvalidInputDataException {
/*  94 */     this.param = new Parameter(SolverType.L2R_L2LOSS_SVC_DUAL, 1.0D, Double.POSITIVE_INFINITY);
/*     */     
/*  96 */     this.bias = -1.0D;
/*  97 */     this.cross_validation = false;
/*     */     
/*  99 */     int nr_weight = 0;
/*     */     
/*     */     int i;
/* 102 */     for (i = 0; i < argv.length && 
/* 103 */       argv[i].charAt(0) == '-'; i++) {
/* 104 */       double[] old; int[] old; if (++i >= argv.length) exit_with_help(); 
/* 105 */       switch (argv[i - 1].charAt(1)) {
/*     */         case 's':
/* 107 */           this.param.solverType = SolverType.values()[Linear.atoi(argv[i])];
/*     */           break;
/*     */         case 'c':
/* 110 */           this.param.setC(Linear.atof(argv[i]));
/*     */           break;
/*     */         case 'e':
/* 113 */           this.param.setEps(Linear.atof(argv[i]));
/*     */           break;
/*     */         case 'B':
/* 116 */           this.bias = Linear.atof(argv[i]);
/*     */           break;
/*     */         case 'w':
/* 119 */           nr_weight++;
/*     */           
/* 121 */           old = this.param.weightLabel;
/* 122 */           this.param.weightLabel = new int[nr_weight];
/* 123 */           System.arraycopy(old, 0, this.param.weightLabel, 0, nr_weight - 1);
/*     */ 
/*     */ 
/*     */           
/* 127 */           old = this.param.weight;
/* 128 */           this.param.weight = new double[nr_weight];
/* 129 */           System.arraycopy(old, 0, this.param.weight, 0, nr_weight - 1);
/*     */ 
/*     */           
/* 132 */           this.param.weightLabel[nr_weight - 1] = Linear.atoi(argv[i - 1].substring(2));
/* 133 */           this.param.weight[nr_weight - 1] = Linear.atof(argv[i]);
/*     */           break;
/*     */         case 'v':
/* 136 */           this.cross_validation = true;
/* 137 */           this.nr_fold = Linear.atoi(argv[i]);
/* 138 */           if (this.nr_fold < 2) {
/* 139 */             System.err.println("n-fold cross validation: n must >= 2");
/* 140 */             exit_with_help();
/*     */           } 
/*     */           break;
/*     */         case 'q':
/* 144 */           Linear.disableDebugOutput();
/*     */           break;
/*     */         default:
/* 147 */           System.err.println("unknown option");
/* 148 */           exit_with_help();
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 154 */     if (i >= argv.length) exit_with_help();
/*     */     
/* 156 */     this.inputFilename = argv[i];
/*     */     
/* 158 */     if (i < argv.length - 1) {
/* 159 */       this.modelFilename = argv[i + 1];
/*     */     } else {
/* 161 */       int p = argv[i].lastIndexOf('/');
/* 162 */       p++;
/* 163 */       this.modelFilename = argv[i].substring(p) + ".model";
/*     */     } 
/*     */     
/* 166 */     if (this.param.eps == Double.POSITIVE_INFINITY) {
/* 167 */       if (this.param.solverType == SolverType.L2R_LR || this.param.solverType == SolverType.L2R_L2LOSS_SVC) {
/* 168 */         this.param.setEps(0.01D);
/* 169 */       } else if (this.param.solverType == SolverType.L2R_L2LOSS_SVC_DUAL || this.param.solverType == SolverType.L2R_L1LOSS_SVC_DUAL || this.param.solverType == SolverType.MCSVM_CS || this.param.solverType == SolverType.L2R_LR_DUAL) {
/*     */         
/* 171 */         this.param.setEps(0.1D);
/* 172 */       } else if (this.param.solverType == SolverType.L1R_L2LOSS_SVC || this.param.solverType == SolverType.L1R_LR) {
/* 173 */         this.param.setEps(0.01D);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Problem readProblem(File file, double bias) throws IOException, InvalidInputDataException {
/* 185 */     fp = new BufferedReader(new FileReader(file));
/* 186 */     List<Integer> vy = new ArrayList<Integer>();
/* 187 */     List<FeatureNode[]> vx = new ArrayList<FeatureNode[]>();
/* 188 */     int max_index = 0;
/*     */     
/* 190 */     int lineNr = 0;
/*     */     try {
/*     */       while (true) {
/*     */         FeatureNode[] x;
/* 194 */         String token, line = fp.readLine();
/* 195 */         if (line == null)
/* 196 */           break;  lineNr++;
/*     */         
/* 198 */         StringTokenizer st = new StringTokenizer(line, " \t\n\r\f:");
/*     */         
/*     */         try {
/* 201 */           token = st.nextToken();
/* 202 */         } catch (NoSuchElementException e) {
/* 203 */           throw new InvalidInputDataException("empty line", file, lineNr, e);
/*     */         } 
/*     */         
/*     */         try {
/* 207 */           vy.add(Integer.valueOf(Linear.atoi(token)));
/* 208 */         } catch (NumberFormatException e) {
/* 209 */           throw new InvalidInputDataException("invalid label: " + token, file, lineNr, e);
/*     */         } 
/*     */         
/* 212 */         int m = st.countTokens() / 2;
/*     */         
/* 214 */         if (bias >= 0.0D) {
/* 215 */           x = new FeatureNode[m + 1];
/*     */         } else {
/* 217 */           x = new FeatureNode[m];
/*     */         } 
/* 219 */         int indexBefore = 0;
/* 220 */         for (int j = 0; j < m; j++) {
/*     */           int index;
/* 222 */           token = st.nextToken();
/*     */           
/*     */           try {
/* 225 */             index = Linear.atoi(token);
/* 226 */           } catch (NumberFormatException e) {
/* 227 */             throw new InvalidInputDataException("invalid index: " + token, file, lineNr, e);
/*     */           } 
/*     */ 
/*     */           
/* 231 */           if (index < 0) throw new InvalidInputDataException("invalid index: " + index, file, lineNr); 
/* 232 */           if (index <= indexBefore) throw new InvalidInputDataException("indices must be sorted in ascending order", file, lineNr); 
/* 233 */           indexBefore = index;
/*     */           
/* 235 */           token = st.nextToken();
/*     */           try {
/* 237 */             double value = Linear.atof(token);
/* 238 */             x[j] = new FeatureNode(index, value);
/* 239 */           } catch (NumberFormatException e) {
/* 240 */             throw new InvalidInputDataException("invalid value: " + token, file, lineNr);
/*     */           } 
/*     */         } 
/* 243 */         if (m > 0) {
/* 244 */           max_index = Math.max(max_index, (x[m - 1]).index);
/*     */         }
/*     */         
/* 247 */         vx.add(x);
/*     */       } 
/*     */       
/* 250 */       return constructProblem(vy, vx, max_index, bias);
/*     */     } finally {
/*     */       
/* 253 */       fp.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 258 */   void readProblem(String filename) throws IOException, InvalidInputDataException { this.prob = readProblem(new File(filename), this.bias); }
/*     */ 
/*     */   
/*     */   private static Problem constructProblem(List<Integer> vy, List<FeatureNode[]> vx, int max_index, double bias) {
/* 262 */     Problem prob = new Problem();
/* 263 */     prob.bias = bias;
/* 264 */     prob.l = vy.size();
/* 265 */     prob.n = max_index;
/* 266 */     if (bias >= 0.0D) {
/* 267 */       prob.n++;
/*     */     }
/* 269 */     prob.x = new FeatureNode[prob.l][];
/* 270 */     for (int i = 0; i < prob.l; i++) {
/* 271 */       prob.x[i] = (FeatureNode[])vx.get(i);
/*     */       
/* 273 */       if (bias >= 0.0D) {
/* 274 */         assert prob.x[i][prob.x[i].length - true] == null;
/* 275 */         prob.x[i][prob.x[i].length - 1] = new FeatureNode(max_index + 1, bias);
/*     */       } 
/*     */     } 
/*     */     
/* 279 */     prob.y = new int[prob.l];
/* 280 */     for (int i = 0; i < prob.l; i++) {
/* 281 */       prob.y[i] = ((Integer)vy.get(i)).intValue();
/*     */     }
/* 283 */     return prob;
/*     */   }
/*     */   
/*     */   private void run(String[] args) throws IOException, InvalidInputDataException {
/* 287 */     parse_command_line(args);
/* 288 */     readProblem(this.inputFilename);
/* 289 */     if (this.cross_validation) {
/* 290 */       do_cross_validation();
/*     */     } else {
/* 292 */       Model model = Linear.train(this.prob, this.param);
/* 293 */       Linear.saveModel(new File(this.modelFilename), model);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\Train.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */