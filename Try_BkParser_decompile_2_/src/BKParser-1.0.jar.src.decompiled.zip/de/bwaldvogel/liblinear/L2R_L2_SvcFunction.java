/*     */ package de.bwaldvogel.liblinear;
/*     */ 
/*     */ 
/*     */ class L2R_L2_SvcFunction
/*     */   implements Function
/*     */ {
/*     */   private final Problem prob;
/*     */   private final double[] C;
/*     */   private final int[] I;
/*     */   private final double[] z;
/*     */   private int sizeI;
/*     */   
/*     */   public L2R_L2_SvcFunction(Problem prob, double Cp, double Cn) {
/*  14 */     int l = prob.l;
/*  15 */     int[] y = prob.y;
/*     */     
/*  17 */     this.prob = prob;
/*     */     
/*  19 */     this.z = new double[l];
/*  20 */     this.C = new double[l];
/*  21 */     this.I = new int[l];
/*     */     
/*  23 */     for (int i = 0; i < l; i++) {
/*  24 */       if (y[i] == 1) {
/*  25 */         this.C[i] = Cp;
/*     */       } else {
/*  27 */         this.C[i] = Cn;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public double fun(double[] w) {
/*  33 */     f = 0.0D;
/*  34 */     int[] y = this.prob.y;
/*  35 */     int l = this.prob.l;
/*  36 */     int w_size = get_nr_variable();
/*     */     
/*  38 */     Xv(w, this.z); int i;
/*  39 */     for (i = 0; i < l; i++) {
/*  40 */       this.z[i] = y[i] * this.z[i];
/*  41 */       double d = 1.0D - this.z[i];
/*  42 */       if (d > 0.0D) f += this.C[i] * d * d; 
/*     */     } 
/*  44 */     f = 2.0D * f;
/*  45 */     for (i = 0; i < w_size; i++)
/*  46 */       f += w[i] * w[i]; 
/*  47 */     return 2.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public int get_nr_variable() { return this.prob.n; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void grad(double[] w, double[] g) {
/*  58 */     int[] y = this.prob.y;
/*  59 */     int l = this.prob.l;
/*  60 */     int w_size = get_nr_variable();
/*     */     
/*  62 */     this.sizeI = 0; int i;
/*  63 */     for (i = 0; i < l; i++) {
/*  64 */       if (this.z[i] < 1.0D) {
/*  65 */         this.z[this.sizeI] = this.C[i] * y[i] * (this.z[i] - 1.0D);
/*  66 */         this.I[this.sizeI] = i;
/*  67 */         this.sizeI++;
/*     */       } 
/*     */     } 
/*  70 */     subXTv(this.z, g);
/*     */     
/*  72 */     for (i = 0; i < w_size; i++) {
/*  73 */       g[i] = w[i] + 2.0D * g[i];
/*     */     }
/*     */   }
/*     */   
/*     */   public void Hv(double[] s, double[] Hs) {
/*  78 */     int l = this.prob.l;
/*  79 */     int w_size = get_nr_variable();
/*  80 */     double[] wa = new double[l];
/*     */     
/*  82 */     subXv(s, wa); int i;
/*  83 */     for (i = 0; i < this.sizeI; i++) {
/*  84 */       wa[i] = this.C[this.I[i]] * wa[i];
/*     */     }
/*  86 */     subXTv(wa, Hs);
/*  87 */     for (i = 0; i < w_size; i++) {
/*  88 */       Hs[i] = s[i] + 2.0D * Hs[i];
/*     */     }
/*     */   }
/*     */   
/*     */   private void subXTv(double[] v, double[] XTv) {
/*  93 */     int w_size = get_nr_variable();
/*     */     int i;
/*  95 */     for (i = 0; i < w_size; i++) {
/*  96 */       XTv[i] = 0.0D;
/*     */     }
/*  98 */     for (i = 0; i < this.sizeI; i++) {
/*  99 */       for (FeatureNode s : this.prob.x[this.I[i]]) {
/* 100 */         XTv[s.index - 1] = XTv[s.index - 1] + v[i] * s.value;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void subXv(double[] v, double[] Xv) {
/* 107 */     for (int i = 0; i < this.sizeI; i++) {
/* 108 */       Xv[i] = 0.0D;
/* 109 */       for (FeatureNode s : this.prob.x[this.I[i]]) {
/* 110 */         Xv[i] = Xv[i] + v[s.index - 1] * s.value;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void Xv(double[] v, double[] Xv) {
/* 117 */     for (int i = 0; i < this.prob.l; i++) {
/* 118 */       Xv[i] = 0.0D;
/* 119 */       for (FeatureNode s : this.prob.x[i])
/* 120 */         Xv[i] = Xv[i] + v[s.index - 1] * s.value; 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\L2R_L2_SvcFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */