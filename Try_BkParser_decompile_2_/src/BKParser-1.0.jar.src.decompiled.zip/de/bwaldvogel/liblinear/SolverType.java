/*    */ package de.bwaldvogel.liblinear;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public static enum SolverType
/*    */ {
/* 10 */   L2R_LR,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 17 */   L2R_L2LOSS_SVC_DUAL,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   L2R_L2LOSS_SVC,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 31 */   L2R_L1LOSS_SVC_DUAL,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   MCSVM_CS,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   L1R_L2LOSS_SVC,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   L1R_LR,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   L2R_LR_DUAL;
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\SolverType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */