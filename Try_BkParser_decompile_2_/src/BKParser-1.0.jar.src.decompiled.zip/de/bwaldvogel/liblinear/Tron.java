/*     */ package de.bwaldvogel.liblinear;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Tron
/*     */ {
/*     */   private final Function fun_obj;
/*     */   private final double eps;
/*     */   private final int max_iter;
/*     */   
/*  15 */   public Tron(Function fun_obj) { this(fun_obj, 0.1D); }
/*     */ 
/*     */ 
/*     */   
/*  19 */   public Tron(Function fun_obj, double eps) { this(fun_obj, eps, 1000); }
/*     */ 
/*     */   
/*     */   public Tron(Function fun_obj, double eps, int max_iter) {
/*  23 */     this.fun_obj = fun_obj;
/*  24 */     this.eps = eps;
/*  25 */     this.max_iter = max_iter;
/*     */   }
/*     */ 
/*     */   
/*     */   void tron(double[] w) {
/*  30 */     double eta0 = 1.0E-4D, eta1 = 0.25D, eta2 = 0.75D;
/*     */ 
/*     */     
/*  33 */     double sigma1 = 0.25D, sigma2 = 0.5D, sigma3 = 4.0D;
/*     */     
/*  35 */     int n = this.fun_obj.get_nr_variable();
/*     */     
/*  37 */     double one = 1.0D;
/*     */     
/*  39 */     int search = 1, iter = 1;
/*  40 */     double[] s = new double[n];
/*  41 */     double[] r = new double[n];
/*  42 */     double[] w_new = new double[n];
/*  43 */     double[] g = new double[n];
/*     */     
/*  45 */     for (int i = 0; i < n; i++) {
/*  46 */       w[i] = 0.0D;
/*     */     }
/*  48 */     double f = this.fun_obj.fun(w);
/*  49 */     this.fun_obj.grad(w, g);
/*  50 */     double delta = euclideanNorm(g);
/*  51 */     double gnorm1 = delta;
/*  52 */     double gnorm = gnorm1;
/*     */     
/*  54 */     if (gnorm <= this.eps * gnorm1) search = 0;
/*     */     
/*  56 */     iter = 1;
/*     */     
/*  58 */     while (iter <= this.max_iter && search != 0) {
/*  59 */       double alpha; int cg_iter = trcg(delta, g, s, r);
/*     */       
/*  61 */       System.arraycopy(w, 0, w_new, 0, n);
/*  62 */       daxpy(one, s, w_new);
/*     */       
/*  64 */       double gs = dot(g, s);
/*  65 */       double prered = -0.5D * (gs - dot(s, r));
/*  66 */       double fnew = this.fun_obj.fun(w_new);
/*     */ 
/*     */       
/*  69 */       double actred = f - fnew;
/*     */ 
/*     */       
/*  72 */       double snorm = euclideanNorm(s);
/*  73 */       if (iter == 1) delta = Math.min(delta, snorm);
/*     */ 
/*     */       
/*  76 */       if (fnew - f - gs <= 0.0D) {
/*  77 */         alpha = sigma3;
/*     */       } else {
/*  79 */         alpha = Math.max(sigma1, -0.5D * gs / (fnew - f - gs));
/*     */       } 
/*     */ 
/*     */       
/*  83 */       if (actred < eta0 * prered) {
/*  84 */         delta = Math.min(Math.max(alpha, sigma1) * snorm, sigma2 * delta);
/*  85 */       } else if (actred < eta1 * prered) {
/*  86 */         delta = Math.max(sigma1 * delta, Math.min(alpha * snorm, sigma2 * delta));
/*  87 */       } else if (actred < eta2 * prered) {
/*  88 */         delta = Math.max(sigma1 * delta, Math.min(alpha * snorm, sigma3 * delta));
/*     */       } else {
/*  90 */         delta = Math.max(delta, Math.min(alpha * snorm, sigma3 * delta));
/*     */       } 
/*  92 */       Linear.info("iter %2d act %5.3e pre %5.3e delta %5.3e f %5.3e |g| %5.3e CG %3d%n", new Object[] { Integer.valueOf(iter), Double.valueOf(actred), Double.valueOf(prered), Double.valueOf(delta), Double.valueOf(f), Double.valueOf(gnorm), Integer.valueOf(cg_iter) });
/*     */       
/*  94 */       if (actred > eta0 * prered) {
/*  95 */         iter++;
/*  96 */         System.arraycopy(w_new, 0, w, 0, n);
/*  97 */         f = fnew;
/*  98 */         this.fun_obj.grad(w, g);
/*     */         
/* 100 */         gnorm = euclideanNorm(g);
/* 101 */         if (gnorm <= this.eps * gnorm1)
/*     */           break; 
/* 103 */       }  if (f < -1.0E32D) {
/* 104 */         Linear.info("warning: f < -1.0e+32%n");
/*     */         break;
/*     */       } 
/* 107 */       if (Math.abs(actred) <= 0.0D && prered <= 0.0D) {
/* 108 */         Linear.info("warning: actred and prered <= 0%n");
/*     */         break;
/*     */       } 
/* 111 */       if (Math.abs(actred) <= 1.0E-12D * Math.abs(f) && Math.abs(prered) <= 1.0E-12D * Math.abs(f)) {
/* 112 */         Linear.info("warning: actred and prered too small%n");
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int trcg(double delta, double[] g, double[] s, double[] r) {
/* 119 */     int n = this.fun_obj.get_nr_variable();
/* 120 */     double one = 1.0D;
/* 121 */     double[] d = new double[n];
/* 122 */     double[] Hd = new double[n];
/*     */ 
/*     */     
/* 125 */     for (int i = 0; i < n; i++) {
/* 126 */       s[i] = 0.0D;
/* 127 */       r[i] = -g[i];
/* 128 */       d[i] = r[i];
/*     */     } 
/* 130 */     double cgtol = 0.1D * euclideanNorm(g);
/*     */     
/* 132 */     int cg_iter = 0;
/* 133 */     double rTr = dot(r, r);
/*     */ 
/*     */     
/* 136 */     while (euclideanNorm(r) > cgtol) {
/* 137 */       cg_iter++;
/* 138 */       this.fun_obj.Hv(d, Hd);
/*     */       
/* 140 */       double alpha = rTr / dot(d, Hd);
/* 141 */       daxpy(alpha, d, s);
/* 142 */       if (euclideanNorm(s) > delta) {
/* 143 */         Linear.info("cg reaches trust region boundary%n");
/* 144 */         alpha = -alpha;
/* 145 */         daxpy(alpha, d, s);
/*     */         
/* 147 */         double std = dot(s, d);
/* 148 */         double sts = dot(s, s);
/* 149 */         double dtd = dot(d, d);
/* 150 */         double dsq = delta * delta;
/* 151 */         double rad = Math.sqrt(std * std + dtd * (dsq - sts));
/* 152 */         if (std >= 0.0D) {
/* 153 */           alpha = (dsq - sts) / (std + rad);
/*     */         } else {
/* 155 */           alpha = (rad - std) / dtd;
/* 156 */         }  daxpy(alpha, d, s);
/* 157 */         alpha = -alpha;
/* 158 */         daxpy(alpha, Hd, r);
/*     */         break;
/*     */       } 
/* 161 */       alpha = -alpha;
/* 162 */       daxpy(alpha, Hd, r);
/* 163 */       double rnewTrnew = dot(r, r);
/* 164 */       double beta = rnewTrnew / rTr;
/* 165 */       scale(beta, d);
/* 166 */       daxpy(one, r, d);
/* 167 */       rTr = rnewTrnew;
/*     */     } 
/*     */     
/* 170 */     return cg_iter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void daxpy(double constant, double[] vector1, double[] vector2) {
/* 183 */     if (constant == 0.0D)
/*     */       return; 
/* 185 */     assert vector1.length == vector2.length;
/* 186 */     for (int i = 0; i < vector1.length; i++) {
/* 187 */       vector2[i] = vector2[i] + constant * vector1[i];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double dot(double[] vector1, double[] vector2) {
/* 198 */     double product = 0.0D;
/* 199 */     assert vector1.length == vector2.length;
/* 200 */     for (int i = 0; i < vector1.length; i++) {
/* 201 */       product += vector1[i] * vector2[i];
/*     */     }
/* 203 */     return product;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static double euclideanNorm(double[] vector) {
/* 214 */     int n = vector.length;
/*     */     
/* 216 */     if (n < 1) {
/* 217 */       return 0.0D;
/*     */     }
/*     */     
/* 220 */     if (n == 1) {
/* 221 */       return Math.abs(vector[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 226 */     double scale = 0.0D;
/* 227 */     double sum = 1.0D;
/* 228 */     for (int i = 0; i < n; i++) {
/* 229 */       if (vector[i] != 0.0D) {
/* 230 */         double abs = Math.abs(vector[i]);
/*     */         
/* 232 */         if (scale < abs) {
/* 233 */           double t = scale / abs;
/* 234 */           sum = 1.0D + sum * t * t;
/* 235 */           scale = abs;
/*     */         } else {
/* 237 */           double t = abs / scale;
/* 238 */           sum += t * t;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 243 */     return scale * Math.sqrt(sum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void scale(double constant, double[] vector) {
/* 252 */     if (constant == 1.0D)
/* 253 */       return;  for (int i = 0; i < vector.length; i++)
/* 254 */       vector[i] = vector[i] * constant; 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\Tron.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */