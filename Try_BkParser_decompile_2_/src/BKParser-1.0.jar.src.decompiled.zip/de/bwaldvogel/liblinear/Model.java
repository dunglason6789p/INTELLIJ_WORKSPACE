/*     */ package de.bwaldvogel.liblinear;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.io.Writer;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Model
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -6456047576741854834L;
/*     */   double bias;
/*     */   int[] label;
/*     */   int nr_class;
/*     */   int nr_feature;
/*     */   SolverType solverType;
/*     */   double[] w;
/*     */   
/*  40 */   public int getNrClass() { return this.nr_class; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public int getNrFeature() { return this.nr_feature; }
/*     */ 
/*     */ 
/*     */   
/*  51 */   public int[] getLabels() { return Linear.copyOf(this.label, this.nr_class); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public double[] getFeatureWeights() { return Linear.copyOf(this.w, this.w.length); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public boolean isProbabilityModel() { return (this.solverType == SolverType.L2R_LR || this.solverType == SolverType.L2R_LR_DUAL || this.solverType == SolverType.L1R_LR); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public double getBias() { return this.bias; }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  93 */     StringBuilder sb = new StringBuilder("Model");
/*  94 */     sb.append(" bias=").append(this.bias);
/*  95 */     sb.append(" nr_class=").append(this.nr_class);
/*  96 */     sb.append(" nr_feature=").append(this.nr_feature);
/*  97 */     sb.append(" solverType=").append(this.solverType);
/*  98 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 103 */     int prime = 31;
/* 104 */     result = 1;
/*     */     
/* 106 */     long temp = Double.doubleToLongBits(this.bias);
/* 107 */     result = 31 * result + (int)(temp ^ temp >>> 32);
/* 108 */     result = 31 * result + Arrays.hashCode(this.label);
/* 109 */     result = 31 * result + this.nr_class;
/* 110 */     result = 31 * result + this.nr_feature;
/* 111 */     result = 31 * result + ((this.solverType == null) ? 0 : this.solverType.hashCode());
/* 112 */     return 31 * result + Arrays.hashCode(this.w);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 118 */     if (this == obj) return true; 
/* 119 */     if (obj == null) return false; 
/* 120 */     if (getClass() != obj.getClass()) return false; 
/* 121 */     Model other = (Model)obj;
/* 122 */     if (Double.doubleToLongBits(this.bias) != Double.doubleToLongBits(other.bias)) return false; 
/* 123 */     if (!Arrays.equals(this.label, other.label)) return false; 
/* 124 */     if (this.nr_class != other.nr_class) return false; 
/* 125 */     if (this.nr_feature != other.nr_feature) return false; 
/* 126 */     if (this.solverType == null)
/* 127 */     { if (other.solverType != null) return false;  }
/* 128 */     else if (!this.solverType.equals(other.solverType)) { return false; }
/* 129 */      if (!equals(this.w, other.w)) return false; 
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean equals(double[] a, double[] a2) {
/* 139 */     if (a == a2) return true; 
/* 140 */     if (a == null || a2 == null) return false;
/*     */     
/* 142 */     int length = a.length;
/* 143 */     if (a2.length != length) return false;
/*     */     
/* 145 */     for (int i = 0; i < length; i++) {
/* 146 */       if (a[i] != a2[i]) return false; 
/*     */     } 
/* 148 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public void save(File file) throws IOException { Linear.saveModel(file, this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   public void save(Writer writer) throws IOException { Linear.saveModel(writer, this); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   public static Model load(File file) throws IOException { return Linear.loadModel(file); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   public static Model load(Reader inputReader) throws IOException { return Linear.loadModel(inputReader); }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\Model.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */