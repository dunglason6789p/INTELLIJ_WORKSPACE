/*    */ package de.bwaldvogel.liblinear;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Problem
/*    */ {
/*    */   public int l;
/*    */   public int n;
/*    */   public int[] y;
/*    */   public FeatureNode[][] x;
/*    */   public double bias;
/*    */   
/* 58 */   public static Problem readFromFile(File file, double bias) throws IOException, InvalidInputDataException { return Train.readProblem(file, bias); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\Problem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */