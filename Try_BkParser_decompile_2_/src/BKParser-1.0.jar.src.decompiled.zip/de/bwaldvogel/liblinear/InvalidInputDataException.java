/*    */ package de.bwaldvogel.liblinear;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidInputDataException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 2945131732407207308L;
/*    */   private final int _line;
/*    */   private File _file;
/*    */   
/*    */   public InvalidInputDataException(String message, File file, int line) {
/* 15 */     super(message);
/* 16 */     this._file = file;
/* 17 */     this._line = line;
/*    */   }
/*    */ 
/*    */   
/* 21 */   public InvalidInputDataException(String message, String filename, int line) { this(message, new File(filename), line); }
/*    */ 
/*    */   
/*    */   public InvalidInputDataException(String message, File file, int lineNr, Exception cause) {
/* 25 */     super(message, cause);
/* 26 */     this._file = file;
/* 27 */     this._line = lineNr;
/*    */   }
/*    */ 
/*    */   
/* 31 */   public InvalidInputDataException(String message, String filename, int lineNr, Exception cause) { this(message, new File(filename), lineNr, cause); }
/*    */ 
/*    */ 
/*    */   
/* 35 */   public File getFile() { return this._file; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public String getFilename() { return this._file.getPath(); }
/*    */ 
/*    */ 
/*    */   
/* 49 */   public int getLine() { return this._line; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public String toString() { return super.toString() + " (" + this._file + ":" + this._line + ")"; }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\InvalidInputDataException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */