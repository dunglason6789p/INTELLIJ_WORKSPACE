/*    */ package de.bwaldvogel.liblinear;
/*    */ 
/*    */ public class FeatureNode
/*    */ {
/*    */   public final int index;
/*    */   public double value;
/*    */   
/*    */   public FeatureNode(int index, double value) {
/*  9 */     if (index < 0) throw new IllegalArgumentException("index must be >= 0"); 
/* 10 */     this.index = index;
/* 11 */     this.value = value;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 16 */     int prime = 31;
/* 17 */     result = 1;
/* 18 */     result = 31 * result + this.index;
/*    */     
/* 20 */     long temp = Double.doubleToLongBits(this.value);
/* 21 */     return 31 * result + (int)(temp ^ temp >>> 32);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 27 */     if (this == obj) return true; 
/* 28 */     if (obj == null) return false; 
/* 29 */     if (getClass() != obj.getClass()) return false; 
/* 30 */     FeatureNode other = (FeatureNode)obj;
/* 31 */     if (this.index != other.index) return false; 
/* 32 */     if (Double.doubleToLongBits(this.value) != Double.doubleToLongBits(other.value)) return false; 
/* 33 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public String toString() { return "FeatureNode(idx=" + this.index + ", value=" + this.value + ")"; }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\de\bwaldvogel\liblinear\FeatureNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */