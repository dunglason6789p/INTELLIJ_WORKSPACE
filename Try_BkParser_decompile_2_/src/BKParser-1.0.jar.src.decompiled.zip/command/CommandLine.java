/*     */ package command;
/*     */ 
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.List;
/*     */ import vn.edu.hust.nlp.conll.model.CONLLToken;
/*     */ import vn.edu.hust.nlp.parser.BKParser;
/*     */ 
/*     */ public class CommandLine
/*     */ {
/*     */   public static void main(String[] args) throws IOException {
/*  13 */     if (args.length == 0) {
/*  14 */       help();
/*     */     } else {
/*  16 */       String arg1 = args[0];
/*  17 */       if (arg1.equals("--help") && args.length == 1) {
/*  18 */         help();
/*  19 */       } else if (arg1.equals("-r")) {
/*  20 */         int length = args.length;
/*  21 */         if (length == 4) {
/*  22 */           if (args[2].equals("-t")) {
/*  23 */             String text = args[3];
/*  24 */             BKParser parser = new BKParser();
/*  25 */             if (args[1].equals("tag")) {
/*  26 */               List<List<CONLLToken>> result = parser.tag(text);
/*  27 */               for (List<CONLLToken> tokenList : result) {
/*  28 */                 for (CONLLToken token : tokenList) {
/*  29 */                   System.out.println(token.toString());
/*     */                 }
/*  31 */                 System.out.println();
/*     */               }
/*     */             
/*  34 */             } else if (args[1].equals("parse")) {
/*  35 */               List<List<CONLLToken>> result = parser.parse(text);
/*  36 */               for (List<CONLLToken> tokenList : result) {
/*  37 */                 for (CONLLToken token : tokenList) {
/*  38 */                   System.out.println(token.toString());
/*     */                 }
/*  40 */                 System.out.println();
/*     */               } 
/*     */             } else {
/*  43 */               invalidCommand();
/*     */             } 
/*  45 */           } else if (args[2].equals("-i")) {
/*  46 */             String path = args[3];
/*  47 */             BKParser parser = new BKParser();
/*  48 */             if (args[1].equals("tag")) {
/*  49 */               List<List<CONLLToken>> result = parser.tagFile(path);
/*  50 */               for (List<CONLLToken> tokenList : result) {
/*  51 */                 for (CONLLToken token : tokenList) {
/*  52 */                   System.out.println(token.toString());
/*     */                 }
/*  54 */                 System.out.println();
/*     */               }
/*     */             
/*  57 */             } else if (args[1].equals("parse")) {
/*  58 */               List<List<CONLLToken>> result = parser.parseFile(path);
/*  59 */               for (List<CONLLToken> tokenList : result) {
/*  60 */                 for (CONLLToken token : tokenList) {
/*  61 */                   System.out.println(token.toString());
/*     */                 }
/*  63 */                 System.out.println();
/*     */               } 
/*     */             } else {
/*  66 */               invalidCommand();
/*     */             } 
/*     */           } 
/*  69 */         } else if (length == 6) {
/*  70 */           if (args[2].equals("-i") && args[4].equals("-o")) {
/*  71 */             String pathInput = args[3];
/*  72 */             String pathOutput = args[5];
/*  73 */             PrintWriter writer = new PrintWriter(new FileWriter(pathOutput));
/*  74 */             BKParser parser = new BKParser();
/*  75 */             if (args[1].equals("tag")) {
/*  76 */               List<List<CONLLToken>> result = parser.tagFile(pathInput);
/*  77 */               for (List<CONLLToken> tokenList : result) {
/*  78 */                 for (CONLLToken token : tokenList)
/*     */                 {
/*  80 */                   writer.println(token.toString());
/*     */                 }
/*  82 */                 writer.println();
/*     */               } 
/*  84 */               System.out.println("Done! Please check your output file");
/*  85 */             } else if (args[1].equals("parse")) {
/*  86 */               List<List<CONLLToken>> result = parser.parseFile(pathInput);
/*  87 */               for (List<CONLLToken> tokenList : result) {
/*  88 */                 for (CONLLToken token : tokenList)
/*     */                 {
/*  90 */                   writer.println(token.toString());
/*     */                 }
/*  92 */                 writer.println();
/*     */               } 
/*  94 */               System.out.println("Done! Please check your output file");
/*     */             } else {
/*  96 */               invalidCommand();
/*     */             } 
/*     */             
/*  99 */             writer.close();
/*     */           } else {
/* 101 */             invalidCommand();
/*     */           } 
/*     */         } else {
/* 104 */           invalidCommand();
/*     */         } 
/*     */       } else {
/* 107 */         invalidCommand();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/* 113 */   public static void invalidCommand() { System.out.println("Invalid command, please type:\n\tjava -jar BKParser.jar --help\nto know a valid command"); }
/*     */ 
/*     */   
/*     */   public static void help() {
/* 117 */     System.out.println("\n* Welcome to BKParser! You need the following arguments to execute:\n");
/*     */     
/* 119 */     System.out.println(" -r <what_to_execute> {additional arguments}\n");
/*     */     
/* 121 */     System.out.println("\t-r\t:\tthe method you want to execute (required: tag|parse)\n");
/*     */ 
/*     */     
/* 124 */     System.out.println("* Additional arguments for each method:\n");
/*     */     
/* 126 */     System.out.print("1) '-r tag' : ");
/* 127 */     Tagger.showHelp();
/*     */     
/* 129 */     System.out.print("2) '-r parse' : ");
/* 130 */     Parser.showHelp();
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\command\CommandLine.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */