/*    */ package command;
/*    */ 
/*    */ public class Tagger {
/*    */   protected static void showHelp() {
/*  5 */     System.out.println("Method for part of speech tagging. Needed arguments:\n");
/*    */     
/*  7 */     System.out.println("-i <input_path> -o <output_path>\nor\n-t <text>\n");
/*    */ 
/*    */ 
/*    */     
/* 11 */     System.out.println("\t-i\t:\tpath to the input text (file) (required)");
/* 12 */     System.out.println("\t-o\t:\tpath to the output text (file) (required)");
/* 13 */     System.out.println("\t-t\t:\ttext(required)");
/* 14 */     System.out.println("Example:");
/* 15 */     System.out.println("\tjava -jar BKParser.jar -r tag -i /home/user/input.txt -o /home/user/output.txt");
/* 16 */     System.out.println("\tjava -jar BKParser.jar -r tag -t \"Hôm nay, tôi đi học.\"");
/*    */     
/* 18 */     System.out.println();
/*    */   }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\command\Tagger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */