/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ConcurrentMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LocaleUtils
/*     */ {
/*  42 */   private static final ConcurrentMap<String, List<Locale>> cLanguagesByCountry = new ConcurrentHashMap();
/*     */ 
/*     */ 
/*     */   
/*  46 */   private static final ConcurrentMap<String, List<Locale>> cCountriesByLanguage = new ConcurrentHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Locale toLocale(String str) {
/*  89 */     if (str == null) {
/*  90 */       return null;
/*     */     }
/*  92 */     int len = str.length();
/*  93 */     if (len != 2 && len != 5 && len < 7) {
/*  94 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/*  96 */     char ch0 = str.charAt(0);
/*  97 */     char ch1 = str.charAt(1);
/*  98 */     if (ch0 < 'a' || ch0 > 'z' || ch1 < 'a' || ch1 > 'z') {
/*  99 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 101 */     if (len == 2) {
/* 102 */       return new Locale(str, "");
/*     */     }
/* 104 */     if (str.charAt(2) != '_') {
/* 105 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 107 */     char ch3 = str.charAt(3);
/* 108 */     if (ch3 == '_') {
/* 109 */       return new Locale(str.substring(0, 2), "", str.substring(4));
/*     */     }
/* 111 */     char ch4 = str.charAt(4);
/* 112 */     if (ch3 < 'A' || ch3 > 'Z' || ch4 < 'A' || ch4 > 'Z') {
/* 113 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 115 */     if (len == 5) {
/* 116 */       return new Locale(str.substring(0, 2), str.substring(3, 5));
/*     */     }
/* 118 */     if (str.charAt(5) != '_') {
/* 119 */       throw new IllegalArgumentException("Invalid locale format: " + str);
/*     */     }
/* 121 */     return new Locale(str.substring(0, 2), str.substring(3, 5), str.substring(6));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public static List<Locale> localeLookupList(Locale locale) { return localeLookupList(locale, locale); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<Locale> localeLookupList(Locale locale, Locale defaultLocale) {
/* 162 */     List<Locale> list = new ArrayList<Locale>(4);
/* 163 */     if (locale != null) {
/* 164 */       list.add(locale);
/* 165 */       if (locale.getVariant().length() > 0) {
/* 166 */         list.add(new Locale(locale.getLanguage(), locale.getCountry()));
/*     */       }
/* 168 */       if (locale.getCountry().length() > 0) {
/* 169 */         list.add(new Locale(locale.getLanguage(), ""));
/*     */       }
/* 171 */       if (!list.contains(defaultLocale)) {
/* 172 */         list.add(defaultLocale);
/*     */       }
/*     */     } 
/* 175 */     return Collections.unmodifiableList(list);
/*     */   } public static boolean isAvailableLocale(Locale locale) { return availableLocaleList().contains(locale); } public static List<Locale> languagesByCountry(String countryCode) { if (countryCode == null)
/*     */       return Collections.emptyList();  List<Locale> langs = (List)cLanguagesByCountry.get(countryCode); if (langs == null) {
/*     */       langs = new ArrayList<Locale>();
/*     */       List<Locale> locales = availableLocaleList();
/*     */       for (int i = 0; i < locales.size(); i++) {
/*     */         Locale locale = (Locale)locales.get(i);
/*     */         if (countryCode.equals(locale.getCountry()) && locale.getVariant().length() == 0)
/*     */           langs.add(locale); 
/*     */       } 
/*     */       langs = Collections.unmodifiableList(langs);
/*     */       cLanguagesByCountry.putIfAbsent(countryCode, langs);
/*     */       langs = (List)cLanguagesByCountry.get(countryCode);
/*     */     } 
/* 189 */     return langs; } public static List<Locale> availableLocaleList() { return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 284 */       AVAILABLE_LOCALE_LIST; } public static List<Locale> countriesByLanguage(String languageCode) { if (languageCode == null) return Collections.emptyList();  List<Locale> countries = (List)cCountriesByLanguage.get(languageCode); if (countries == null) { countries = new ArrayList<Locale>(); List<Locale> locales = availableLocaleList(); for (int i = 0; i < locales.size(); i++) { Locale locale = (Locale)locales.get(i); if (languageCode.equals(locale.getLanguage()) && locale.getCountry().length() != 0 && locale.getVariant().length() == 0) countries.add(locale);  }  countries = Collections.unmodifiableList(countries); cCountriesByLanguage.putIfAbsent(languageCode, countries); countries = (List)cCountriesByLanguage.get(languageCode); }  return countries; } public static Set<Locale> availableLocaleSet() { return AVAILABLE_LOCALE_SET; }
/*     */ 
/*     */ 
/*     */   
/*     */   static class SyncAvoid
/*     */   {
/*     */     static  {
/* 291 */       list = new ArrayList(Arrays.asList(Locale.getAvailableLocales()));
/* 292 */       AVAILABLE_LOCALE_LIST = Collections.unmodifiableList(list);
/* 293 */       AVAILABLE_LOCALE_SET = Collections.unmodifiableSet(new HashSet(LocaleUtils.availableLocaleList()));
/*     */     }
/*     */     
/*     */     private static List<Locale> AVAILABLE_LOCALE_LIST;
/*     */     private static Set<Locale> AVAILABLE_LOCALE_SET;
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\LocaleUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */