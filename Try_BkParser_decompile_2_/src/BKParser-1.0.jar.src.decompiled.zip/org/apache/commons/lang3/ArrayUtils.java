/*      */ package org.apache.commons.lang3;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.lang3.builder.EqualsBuilder;
/*      */ import org.apache.commons.lang3.builder.HashCodeBuilder;
/*      */ import org.apache.commons.lang3.builder.ToStringBuilder;
/*      */ import org.apache.commons.lang3.builder.ToStringStyle;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ArrayUtils
/*      */ {
/*   46 */   public static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*      */ 
/*      */ 
/*      */   
/*   50 */   public static final Class<?>[] EMPTY_CLASS_ARRAY = new Class[0];
/*      */ 
/*      */ 
/*      */   
/*   54 */   public static final String[] EMPTY_STRING_ARRAY = new String[0];
/*      */ 
/*      */ 
/*      */   
/*   58 */   public static final long[] EMPTY_LONG_ARRAY = new long[0];
/*      */ 
/*      */ 
/*      */   
/*   62 */   public static final Long[] EMPTY_LONG_OBJECT_ARRAY = new Long[0];
/*      */ 
/*      */ 
/*      */   
/*   66 */   public static final int[] EMPTY_INT_ARRAY = new int[0];
/*      */ 
/*      */ 
/*      */   
/*   70 */   public static final Integer[] EMPTY_INTEGER_OBJECT_ARRAY = new Integer[0];
/*      */ 
/*      */ 
/*      */   
/*   74 */   public static final short[] EMPTY_SHORT_ARRAY = new short[0];
/*      */ 
/*      */ 
/*      */   
/*   78 */   public static final Short[] EMPTY_SHORT_OBJECT_ARRAY = new Short[0];
/*      */ 
/*      */ 
/*      */   
/*   82 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*      */ 
/*      */ 
/*      */   
/*   86 */   public static final Byte[] EMPTY_BYTE_OBJECT_ARRAY = new Byte[0];
/*      */ 
/*      */ 
/*      */   
/*   90 */   public static final double[] EMPTY_DOUBLE_ARRAY = new double[0];
/*      */ 
/*      */ 
/*      */   
/*   94 */   public static final Double[] EMPTY_DOUBLE_OBJECT_ARRAY = new Double[0];
/*      */ 
/*      */ 
/*      */   
/*   98 */   public static final float[] EMPTY_FLOAT_ARRAY = new float[0];
/*      */ 
/*      */ 
/*      */   
/*  102 */   public static final Float[] EMPTY_FLOAT_OBJECT_ARRAY = new Float[0];
/*      */ 
/*      */ 
/*      */   
/*  106 */   public static final boolean[] EMPTY_BOOLEAN_ARRAY = new boolean[0];
/*      */ 
/*      */ 
/*      */   
/*  110 */   public static final Boolean[] EMPTY_BOOLEAN_OBJECT_ARRAY = new Boolean[0];
/*      */ 
/*      */ 
/*      */   
/*  114 */   public static final char[] EMPTY_CHAR_ARRAY = new char[0];
/*      */ 
/*      */ 
/*      */   
/*  118 */   public static final Character[] EMPTY_CHARACTER_OBJECT_ARRAY = new Character[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int INDEX_NOT_FOUND = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  156 */   public static String toString(Object array) { return toString(array, "{}"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(Object array, String stringIfNull) {
/*  172 */     if (array == null) {
/*  173 */       return stringIfNull;
/*      */     }
/*  175 */     return (new ToStringBuilder(array, ToStringStyle.SIMPLE_STYLE)).append(array).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  187 */   public static int hashCode(Object array) { return (new HashCodeBuilder()).append(array).toHashCode(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   public static boolean isEquals(Object array1, Object array2) { return (new EqualsBuilder()).append(array1, array2).isEquals(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<Object, Object> toMap(Object[] array) {
/*  232 */     if (array == null) {
/*  233 */       return null;
/*      */     }
/*  235 */     Map<Object, Object> map = new HashMap<Object, Object>((int)(array.length * 1.5D));
/*  236 */     for (int i = 0; i < array.length; i++) {
/*  237 */       Object object = array[i];
/*  238 */       if (object instanceof Map.Entry) {
/*  239 */         Map.Entry<?, ?> entry = (Map.Entry)object;
/*  240 */         map.put(entry.getKey(), entry.getValue());
/*  241 */       } else if (object instanceof Object[]) {
/*  242 */         Object[] entry = (Object[])object;
/*  243 */         if (entry.length < 2) {
/*  244 */           throw new IllegalArgumentException("Array element " + i + ", '" + object + "', has a length less than 2");
/*      */         }
/*      */ 
/*      */         
/*  248 */         map.put(entry[0], entry[1]);
/*      */       } else {
/*  250 */         throw new IllegalArgumentException("Array element " + i + ", '" + object + "', is neither of type Map.Entry nor an Array");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  255 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  298 */   public static <T> T[] toArray(T... items) { return items; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] clone(T[] array) {
/*  317 */     if (array == null) {
/*  318 */       return null;
/*      */     }
/*  320 */     return (T[])(Object[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] clone(long[] array) {
/*  333 */     if (array == null) {
/*  334 */       return null;
/*      */     }
/*  336 */     return (long[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] clone(int[] array) {
/*  349 */     if (array == null) {
/*  350 */       return null;
/*      */     }
/*  352 */     return (int[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] clone(short[] array) {
/*  365 */     if (array == null) {
/*  366 */       return null;
/*      */     }
/*  368 */     return (short[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] clone(char[] array) {
/*  381 */     if (array == null) {
/*  382 */       return null;
/*      */     }
/*  384 */     return (char[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] clone(byte[] array) {
/*  397 */     if (array == null) {
/*  398 */       return null;
/*      */     }
/*  400 */     return (byte[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] clone(double[] array) {
/*  413 */     if (array == null) {
/*  414 */       return null;
/*      */     }
/*  416 */     return (double[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] clone(float[] array) {
/*  429 */     if (array == null) {
/*  430 */       return null;
/*      */     }
/*  432 */     return (float[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] clone(boolean[] array) {
/*  445 */     if (array == null) {
/*  446 */       return null;
/*      */     }
/*  448 */     return (boolean[])array.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object[] nullToEmpty(Object[] array) {
/*  467 */     if (array == null || array.length == 0) {
/*  468 */       return EMPTY_OBJECT_ARRAY;
/*      */     }
/*  470 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] nullToEmpty(String[] array) {
/*  487 */     if (array == null || array.length == 0) {
/*  488 */       return EMPTY_STRING_ARRAY;
/*      */     }
/*  490 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] nullToEmpty(long[] array) {
/*  507 */     if (array == null || array.length == 0) {
/*  508 */       return EMPTY_LONG_ARRAY;
/*      */     }
/*  510 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] nullToEmpty(int[] array) {
/*  527 */     if (array == null || array.length == 0) {
/*  528 */       return EMPTY_INT_ARRAY;
/*      */     }
/*  530 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] nullToEmpty(short[] array) {
/*  547 */     if (array == null || array.length == 0) {
/*  548 */       return EMPTY_SHORT_ARRAY;
/*      */     }
/*  550 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] nullToEmpty(char[] array) {
/*  567 */     if (array == null || array.length == 0) {
/*  568 */       return EMPTY_CHAR_ARRAY;
/*      */     }
/*  570 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] nullToEmpty(byte[] array) {
/*  587 */     if (array == null || array.length == 0) {
/*  588 */       return EMPTY_BYTE_ARRAY;
/*      */     }
/*  590 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] nullToEmpty(double[] array) {
/*  607 */     if (array == null || array.length == 0) {
/*  608 */       return EMPTY_DOUBLE_ARRAY;
/*      */     }
/*  610 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] nullToEmpty(float[] array) {
/*  627 */     if (array == null || array.length == 0) {
/*  628 */       return EMPTY_FLOAT_ARRAY;
/*      */     }
/*  630 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] nullToEmpty(boolean[] array) {
/*  647 */     if (array == null || array.length == 0) {
/*  648 */       return EMPTY_BOOLEAN_ARRAY;
/*      */     }
/*  650 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long[] nullToEmpty(Long[] array) {
/*  667 */     if (array == null || array.length == 0) {
/*  668 */       return EMPTY_LONG_OBJECT_ARRAY;
/*      */     }
/*  670 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer[] nullToEmpty(Integer[] array) {
/*  687 */     if (array == null || array.length == 0) {
/*  688 */       return EMPTY_INTEGER_OBJECT_ARRAY;
/*      */     }
/*  690 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Short[] nullToEmpty(Short[] array) {
/*  707 */     if (array == null || array.length == 0) {
/*  708 */       return EMPTY_SHORT_OBJECT_ARRAY;
/*      */     }
/*  710 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Character[] nullToEmpty(Character[] array) {
/*  727 */     if (array == null || array.length == 0) {
/*  728 */       return EMPTY_CHARACTER_OBJECT_ARRAY;
/*      */     }
/*  730 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Byte[] nullToEmpty(Byte[] array) {
/*  747 */     if (array == null || array.length == 0) {
/*  748 */       return EMPTY_BYTE_OBJECT_ARRAY;
/*      */     }
/*  750 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double[] nullToEmpty(Double[] array) {
/*  767 */     if (array == null || array.length == 0) {
/*  768 */       return EMPTY_DOUBLE_OBJECT_ARRAY;
/*      */     }
/*  770 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float[] nullToEmpty(Float[] array) {
/*  787 */     if (array == null || array.length == 0) {
/*  788 */       return EMPTY_FLOAT_OBJECT_ARRAY;
/*      */     }
/*  790 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean[] nullToEmpty(Boolean[] array) {
/*  807 */     if (array == null || array.length == 0) {
/*  808 */       return EMPTY_BOOLEAN_OBJECT_ARRAY;
/*      */     }
/*  810 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] subarray(T[] array, int startIndexInclusive, int endIndexExclusive) {
/*  844 */     if (array == null) {
/*  845 */       return null;
/*      */     }
/*  847 */     if (startIndexInclusive < 0) {
/*  848 */       startIndexInclusive = 0;
/*      */     }
/*  850 */     if (endIndexExclusive > array.length) {
/*  851 */       endIndexExclusive = array.length;
/*      */     }
/*  853 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  854 */     Class<?> type = array.getClass().getComponentType();
/*  855 */     if (newSize <= 0)
/*      */     {
/*  857 */       return (T[])(Object[])Array.newInstance(type, 0);
/*      */     }
/*      */ 
/*      */     
/*  861 */     T[] subarray = (T[])(Object[])Array.newInstance(type, newSize);
/*  862 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  863 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] subarray(long[] array, int startIndexInclusive, int endIndexExclusive) {
/*  886 */     if (array == null) {
/*  887 */       return null;
/*      */     }
/*  889 */     if (startIndexInclusive < 0) {
/*  890 */       startIndexInclusive = 0;
/*      */     }
/*  892 */     if (endIndexExclusive > array.length) {
/*  893 */       endIndexExclusive = array.length;
/*      */     }
/*  895 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  896 */     if (newSize <= 0) {
/*  897 */       return EMPTY_LONG_ARRAY;
/*      */     }
/*      */     
/*  900 */     long[] subarray = new long[newSize];
/*  901 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  902 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] subarray(int[] array, int startIndexInclusive, int endIndexExclusive) {
/*  925 */     if (array == null) {
/*  926 */       return null;
/*      */     }
/*  928 */     if (startIndexInclusive < 0) {
/*  929 */       startIndexInclusive = 0;
/*      */     }
/*  931 */     if (endIndexExclusive > array.length) {
/*  932 */       endIndexExclusive = array.length;
/*      */     }
/*  934 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  935 */     if (newSize <= 0) {
/*  936 */       return EMPTY_INT_ARRAY;
/*      */     }
/*      */     
/*  939 */     int[] subarray = new int[newSize];
/*  940 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  941 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] subarray(short[] array, int startIndexInclusive, int endIndexExclusive) {
/*  964 */     if (array == null) {
/*  965 */       return null;
/*      */     }
/*  967 */     if (startIndexInclusive < 0) {
/*  968 */       startIndexInclusive = 0;
/*      */     }
/*  970 */     if (endIndexExclusive > array.length) {
/*  971 */       endIndexExclusive = array.length;
/*      */     }
/*  973 */     int newSize = endIndexExclusive - startIndexInclusive;
/*  974 */     if (newSize <= 0) {
/*  975 */       return EMPTY_SHORT_ARRAY;
/*      */     }
/*      */     
/*  978 */     short[] subarray = new short[newSize];
/*  979 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/*  980 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] subarray(char[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1003 */     if (array == null) {
/* 1004 */       return null;
/*      */     }
/* 1006 */     if (startIndexInclusive < 0) {
/* 1007 */       startIndexInclusive = 0;
/*      */     }
/* 1009 */     if (endIndexExclusive > array.length) {
/* 1010 */       endIndexExclusive = array.length;
/*      */     }
/* 1012 */     int newSize = endIndexExclusive - startIndexInclusive;
/* 1013 */     if (newSize <= 0) {
/* 1014 */       return EMPTY_CHAR_ARRAY;
/*      */     }
/*      */     
/* 1017 */     char[] subarray = new char[newSize];
/* 1018 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/* 1019 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] subarray(byte[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1042 */     if (array == null) {
/* 1043 */       return null;
/*      */     }
/* 1045 */     if (startIndexInclusive < 0) {
/* 1046 */       startIndexInclusive = 0;
/*      */     }
/* 1048 */     if (endIndexExclusive > array.length) {
/* 1049 */       endIndexExclusive = array.length;
/*      */     }
/* 1051 */     int newSize = endIndexExclusive - startIndexInclusive;
/* 1052 */     if (newSize <= 0) {
/* 1053 */       return EMPTY_BYTE_ARRAY;
/*      */     }
/*      */     
/* 1056 */     byte[] subarray = new byte[newSize];
/* 1057 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/* 1058 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] subarray(double[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1081 */     if (array == null) {
/* 1082 */       return null;
/*      */     }
/* 1084 */     if (startIndexInclusive < 0) {
/* 1085 */       startIndexInclusive = 0;
/*      */     }
/* 1087 */     if (endIndexExclusive > array.length) {
/* 1088 */       endIndexExclusive = array.length;
/*      */     }
/* 1090 */     int newSize = endIndexExclusive - startIndexInclusive;
/* 1091 */     if (newSize <= 0) {
/* 1092 */       return EMPTY_DOUBLE_ARRAY;
/*      */     }
/*      */     
/* 1095 */     double[] subarray = new double[newSize];
/* 1096 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/* 1097 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] subarray(float[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1120 */     if (array == null) {
/* 1121 */       return null;
/*      */     }
/* 1123 */     if (startIndexInclusive < 0) {
/* 1124 */       startIndexInclusive = 0;
/*      */     }
/* 1126 */     if (endIndexExclusive > array.length) {
/* 1127 */       endIndexExclusive = array.length;
/*      */     }
/* 1129 */     int newSize = endIndexExclusive - startIndexInclusive;
/* 1130 */     if (newSize <= 0) {
/* 1131 */       return EMPTY_FLOAT_ARRAY;
/*      */     }
/*      */     
/* 1134 */     float[] subarray = new float[newSize];
/* 1135 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/* 1136 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] subarray(boolean[] array, int startIndexInclusive, int endIndexExclusive) {
/* 1159 */     if (array == null) {
/* 1160 */       return null;
/*      */     }
/* 1162 */     if (startIndexInclusive < 0) {
/* 1163 */       startIndexInclusive = 0;
/*      */     }
/* 1165 */     if (endIndexExclusive > array.length) {
/* 1166 */       endIndexExclusive = array.length;
/*      */     }
/* 1168 */     int newSize = endIndexExclusive - startIndexInclusive;
/* 1169 */     if (newSize <= 0) {
/* 1170 */       return EMPTY_BOOLEAN_ARRAY;
/*      */     }
/*      */     
/* 1173 */     boolean[] subarray = new boolean[newSize];
/* 1174 */     System.arraycopy(array, startIndexInclusive, subarray, 0, newSize);
/* 1175 */     return subarray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(Object[] array1, Object[] array2) {
/* 1192 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1195 */       return false;
/*      */     }
/* 1197 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(long[] array1, long[] array2) {
/* 1210 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1213 */       return false;
/*      */     }
/* 1215 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(int[] array1, int[] array2) {
/* 1228 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1231 */       return false;
/*      */     }
/* 1233 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(short[] array1, short[] array2) {
/* 1246 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1249 */       return false;
/*      */     }
/* 1251 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(char[] array1, char[] array2) {
/* 1264 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1267 */       return false;
/*      */     }
/* 1269 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(byte[] array1, byte[] array2) {
/* 1282 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1285 */       return false;
/*      */     }
/* 1287 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(double[] array1, double[] array2) {
/* 1300 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1303 */       return false;
/*      */     }
/* 1305 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(float[] array1, float[] array2) {
/* 1318 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1321 */       return false;
/*      */     }
/* 1323 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameLength(boolean[] array1, boolean[] array2) {
/* 1336 */     if ((array1 == null && array2 != null && array2.length > 0) || (array2 == null && array1 != null && array1.length > 0) || (array1 != null && array2 != null && array1.length != array2.length))
/*      */     {
/*      */       
/* 1339 */       return false;
/*      */     }
/* 1341 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getLength(Object array) {
/* 1366 */     if (array == null) {
/* 1367 */       return 0;
/*      */     }
/* 1369 */     return Array.getLength(array);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSameType(Object array1, Object array2) {
/* 1382 */     if (array1 == null || array2 == null) {
/* 1383 */       throw new IllegalArgumentException("The Array must not be null");
/*      */     }
/* 1385 */     return array1.getClass().getName().equals(array2.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(Object[] array) {
/* 1400 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1403 */     int i = 0;
/* 1404 */     int j = array.length - 1;
/*      */     
/* 1406 */     while (j > i) {
/* 1407 */       Object tmp = array[j];
/* 1408 */       array[j] = array[i];
/* 1409 */       array[i] = tmp;
/* 1410 */       j--;
/* 1411 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(long[] array) {
/* 1423 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1426 */     int i = 0;
/* 1427 */     int j = array.length - 1;
/*      */     
/* 1429 */     while (j > i) {
/* 1430 */       long tmp = array[j];
/* 1431 */       array[j] = array[i];
/* 1432 */       array[i] = tmp;
/* 1433 */       j--;
/* 1434 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(int[] array) {
/* 1446 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1449 */     int i = 0;
/* 1450 */     int j = array.length - 1;
/*      */     
/* 1452 */     while (j > i) {
/* 1453 */       int tmp = array[j];
/* 1454 */       array[j] = array[i];
/* 1455 */       array[i] = tmp;
/* 1456 */       j--;
/* 1457 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(short[] array) {
/* 1469 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1472 */     int i = 0;
/* 1473 */     int j = array.length - 1;
/*      */     
/* 1475 */     while (j > i) {
/* 1476 */       short tmp = array[j];
/* 1477 */       array[j] = array[i];
/* 1478 */       array[i] = tmp;
/* 1479 */       j--;
/* 1480 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(char[] array) {
/* 1492 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1495 */     int i = 0;
/* 1496 */     int j = array.length - 1;
/*      */     
/* 1498 */     while (j > i) {
/* 1499 */       char tmp = array[j];
/* 1500 */       array[j] = array[i];
/* 1501 */       array[i] = tmp;
/* 1502 */       j--;
/* 1503 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(byte[] array) {
/* 1515 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1518 */     int i = 0;
/* 1519 */     int j = array.length - 1;
/*      */     
/* 1521 */     while (j > i) {
/* 1522 */       byte tmp = array[j];
/* 1523 */       array[j] = array[i];
/* 1524 */       array[i] = tmp;
/* 1525 */       j--;
/* 1526 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(double[] array) {
/* 1538 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1541 */     int i = 0;
/* 1542 */     int j = array.length - 1;
/*      */     
/* 1544 */     while (j > i) {
/* 1545 */       double tmp = array[j];
/* 1546 */       array[j] = array[i];
/* 1547 */       array[i] = tmp;
/* 1548 */       j--;
/* 1549 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(float[] array) {
/* 1561 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1564 */     int i = 0;
/* 1565 */     int j = array.length - 1;
/*      */     
/* 1567 */     while (j > i) {
/* 1568 */       float tmp = array[j];
/* 1569 */       array[j] = array[i];
/* 1570 */       array[i] = tmp;
/* 1571 */       j--;
/* 1572 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void reverse(boolean[] array) {
/* 1584 */     if (array == null) {
/*      */       return;
/*      */     }
/* 1587 */     int i = 0;
/* 1588 */     int j = array.length - 1;
/*      */     
/* 1590 */     while (j > i) {
/* 1591 */       boolean tmp = array[j];
/* 1592 */       array[j] = array[i];
/* 1593 */       array[i] = tmp;
/* 1594 */       j--;
/* 1595 */       i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1615 */   public static int indexOf(Object[] array, Object objectToFind) { return indexOf(array, objectToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(Object[] array, Object objectToFind, int startIndex) {
/* 1633 */     if (array == null) {
/* 1634 */       return -1;
/*      */     }
/* 1636 */     if (startIndex < 0) {
/* 1637 */       startIndex = 0;
/*      */     }
/* 1639 */     if (objectToFind == null) {
/* 1640 */       for (int i = startIndex; i < array.length; i++) {
/* 1641 */         if (array[i] == null) {
/* 1642 */           return i;
/*      */         }
/*      */       } 
/* 1645 */     } else if (array.getClass().getComponentType().isInstance(objectToFind)) {
/* 1646 */       for (int i = startIndex; i < array.length; i++) {
/* 1647 */         if (objectToFind.equals(array[i])) {
/* 1648 */           return i;
/*      */         }
/*      */       } 
/*      */     } 
/* 1652 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1666 */   public static int lastIndexOf(Object[] array, Object objectToFind) { return lastIndexOf(array, objectToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(Object[] array, Object objectToFind, int startIndex) {
/* 1684 */     if (array == null) {
/* 1685 */       return -1;
/*      */     }
/* 1687 */     if (startIndex < 0)
/* 1688 */       return -1; 
/* 1689 */     if (startIndex >= array.length) {
/* 1690 */       startIndex = array.length - 1;
/*      */     }
/* 1692 */     if (objectToFind == null) {
/* 1693 */       for (int i = startIndex; i >= 0; i--) {
/* 1694 */         if (array[i] == null) {
/* 1695 */           return i;
/*      */         }
/*      */       } 
/* 1698 */     } else if (array.getClass().getComponentType().isInstance(objectToFind)) {
/* 1699 */       for (int i = startIndex; i >= 0; i--) {
/* 1700 */         if (objectToFind.equals(array[i])) {
/* 1701 */           return i;
/*      */         }
/*      */       } 
/*      */     } 
/* 1705 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1718 */   public static boolean contains(Object[] array, Object objectToFind) { return (indexOf(array, objectToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1734 */   public static int indexOf(long[] array, long valueToFind) { return indexOf(array, valueToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(long[] array, long valueToFind, int startIndex) {
/* 1752 */     if (array == null) {
/* 1753 */       return -1;
/*      */     }
/* 1755 */     if (startIndex < 0) {
/* 1756 */       startIndex = 0;
/*      */     }
/* 1758 */     for (int i = startIndex; i < array.length; i++) {
/* 1759 */       if (valueToFind == array[i]) {
/* 1760 */         return i;
/*      */       }
/*      */     } 
/* 1763 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1777 */   public static int lastIndexOf(long[] array, long valueToFind) { return lastIndexOf(array, valueToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(long[] array, long valueToFind, int startIndex) {
/* 1795 */     if (array == null) {
/* 1796 */       return -1;
/*      */     }
/* 1798 */     if (startIndex < 0)
/* 1799 */       return -1; 
/* 1800 */     if (startIndex >= array.length) {
/* 1801 */       startIndex = array.length - 1;
/*      */     }
/* 1803 */     for (int i = startIndex; i >= 0; i--) {
/* 1804 */       if (valueToFind == array[i]) {
/* 1805 */         return i;
/*      */       }
/*      */     } 
/* 1808 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1821 */   public static boolean contains(long[] array, long valueToFind) { return (indexOf(array, valueToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1837 */   public static int indexOf(int[] array, int valueToFind) { return indexOf(array, valueToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(int[] array, int valueToFind, int startIndex) {
/* 1855 */     if (array == null) {
/* 1856 */       return -1;
/*      */     }
/* 1858 */     if (startIndex < 0) {
/* 1859 */       startIndex = 0;
/*      */     }
/* 1861 */     for (int i = startIndex; i < array.length; i++) {
/* 1862 */       if (valueToFind == array[i]) {
/* 1863 */         return i;
/*      */       }
/*      */     } 
/* 1866 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1880 */   public static int lastIndexOf(int[] array, int valueToFind) { return lastIndexOf(array, valueToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(int[] array, int valueToFind, int startIndex) {
/* 1898 */     if (array == null) {
/* 1899 */       return -1;
/*      */     }
/* 1901 */     if (startIndex < 0)
/* 1902 */       return -1; 
/* 1903 */     if (startIndex >= array.length) {
/* 1904 */       startIndex = array.length - 1;
/*      */     }
/* 1906 */     for (int i = startIndex; i >= 0; i--) {
/* 1907 */       if (valueToFind == array[i]) {
/* 1908 */         return i;
/*      */       }
/*      */     } 
/* 1911 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1924 */   public static boolean contains(int[] array, int valueToFind) { return (indexOf(array, valueToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1940 */   public static int indexOf(short[] array, short valueToFind) { return indexOf(array, valueToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(short[] array, short valueToFind, int startIndex) {
/* 1958 */     if (array == null) {
/* 1959 */       return -1;
/*      */     }
/* 1961 */     if (startIndex < 0) {
/* 1962 */       startIndex = 0;
/*      */     }
/* 1964 */     for (int i = startIndex; i < array.length; i++) {
/* 1965 */       if (valueToFind == array[i]) {
/* 1966 */         return i;
/*      */       }
/*      */     } 
/* 1969 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1983 */   public static int lastIndexOf(short[] array, short valueToFind) { return lastIndexOf(array, valueToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(short[] array, short valueToFind, int startIndex) {
/* 2001 */     if (array == null) {
/* 2002 */       return -1;
/*      */     }
/* 2004 */     if (startIndex < 0)
/* 2005 */       return -1; 
/* 2006 */     if (startIndex >= array.length) {
/* 2007 */       startIndex = array.length - 1;
/*      */     }
/* 2009 */     for (int i = startIndex; i >= 0; i--) {
/* 2010 */       if (valueToFind == array[i]) {
/* 2011 */         return i;
/*      */       }
/*      */     } 
/* 2014 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2027 */   public static boolean contains(short[] array, short valueToFind) { return (indexOf(array, valueToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2044 */   public static int indexOf(char[] array, char valueToFind) { return indexOf(array, valueToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(char[] array, char valueToFind, int startIndex) {
/* 2063 */     if (array == null) {
/* 2064 */       return -1;
/*      */     }
/* 2066 */     if (startIndex < 0) {
/* 2067 */       startIndex = 0;
/*      */     }
/* 2069 */     for (int i = startIndex; i < array.length; i++) {
/* 2070 */       if (valueToFind == array[i]) {
/* 2071 */         return i;
/*      */       }
/*      */     } 
/* 2074 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2089 */   public static int lastIndexOf(char[] array, char valueToFind) { return lastIndexOf(array, valueToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(char[] array, char valueToFind, int startIndex) {
/* 2108 */     if (array == null) {
/* 2109 */       return -1;
/*      */     }
/* 2111 */     if (startIndex < 0)
/* 2112 */       return -1; 
/* 2113 */     if (startIndex >= array.length) {
/* 2114 */       startIndex = array.length - 1;
/*      */     }
/* 2116 */     for (int i = startIndex; i >= 0; i--) {
/* 2117 */       if (valueToFind == array[i]) {
/* 2118 */         return i;
/*      */       }
/*      */     } 
/* 2121 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2135 */   public static boolean contains(char[] array, char valueToFind) { return (indexOf(array, valueToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2151 */   public static int indexOf(byte[] array, byte valueToFind) { return indexOf(array, valueToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(byte[] array, byte valueToFind, int startIndex) {
/* 2169 */     if (array == null) {
/* 2170 */       return -1;
/*      */     }
/* 2172 */     if (startIndex < 0) {
/* 2173 */       startIndex = 0;
/*      */     }
/* 2175 */     for (int i = startIndex; i < array.length; i++) {
/* 2176 */       if (valueToFind == array[i]) {
/* 2177 */         return i;
/*      */       }
/*      */     } 
/* 2180 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2194 */   public static int lastIndexOf(byte[] array, byte valueToFind) { return lastIndexOf(array, valueToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(byte[] array, byte valueToFind, int startIndex) {
/* 2212 */     if (array == null) {
/* 2213 */       return -1;
/*      */     }
/* 2215 */     if (startIndex < 0)
/* 2216 */       return -1; 
/* 2217 */     if (startIndex >= array.length) {
/* 2218 */       startIndex = array.length - 1;
/*      */     }
/* 2220 */     for (int i = startIndex; i >= 0; i--) {
/* 2221 */       if (valueToFind == array[i]) {
/* 2222 */         return i;
/*      */       }
/*      */     } 
/* 2225 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2238 */   public static boolean contains(byte[] array, byte valueToFind) { return (indexOf(array, valueToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2254 */   public static int indexOf(double[] array, double valueToFind) { return indexOf(array, valueToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2271 */   public static int indexOf(double[] array, double valueToFind, double tolerance) { return indexOf(array, valueToFind, 0, tolerance); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(double[] array, double valueToFind, int startIndex) {
/* 2289 */     if (isEmpty(array)) {
/* 2290 */       return -1;
/*      */     }
/* 2292 */     if (startIndex < 0) {
/* 2293 */       startIndex = 0;
/*      */     }
/* 2295 */     for (int i = startIndex; i < array.length; i++) {
/* 2296 */       if (valueToFind == array[i]) {
/* 2297 */         return i;
/*      */       }
/*      */     } 
/* 2300 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(double[] array, double valueToFind, int startIndex, double tolerance) {
/* 2321 */     if (isEmpty(array)) {
/* 2322 */       return -1;
/*      */     }
/* 2324 */     if (startIndex < 0) {
/* 2325 */       startIndex = 0;
/*      */     }
/* 2327 */     double min = valueToFind - tolerance;
/* 2328 */     double max = valueToFind + tolerance;
/* 2329 */     for (int i = startIndex; i < array.length; i++) {
/* 2330 */       if (array[i] >= min && array[i] <= max) {
/* 2331 */         return i;
/*      */       }
/*      */     } 
/* 2334 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2348 */   public static int lastIndexOf(double[] array, double valueToFind) { return lastIndexOf(array, valueToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2365 */   public static int lastIndexOf(double[] array, double valueToFind, double tolerance) { return lastIndexOf(array, valueToFind, 2147483647, tolerance); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(double[] array, double valueToFind, int startIndex) {
/* 2383 */     if (isEmpty(array)) {
/* 2384 */       return -1;
/*      */     }
/* 2386 */     if (startIndex < 0)
/* 2387 */       return -1; 
/* 2388 */     if (startIndex >= array.length) {
/* 2389 */       startIndex = array.length - 1;
/*      */     }
/* 2391 */     for (int i = startIndex; i >= 0; i--) {
/* 2392 */       if (valueToFind == array[i]) {
/* 2393 */         return i;
/*      */       }
/*      */     } 
/* 2396 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(double[] array, double valueToFind, int startIndex, double tolerance) {
/* 2417 */     if (isEmpty(array)) {
/* 2418 */       return -1;
/*      */     }
/* 2420 */     if (startIndex < 0)
/* 2421 */       return -1; 
/* 2422 */     if (startIndex >= array.length) {
/* 2423 */       startIndex = array.length - 1;
/*      */     }
/* 2425 */     double min = valueToFind - tolerance;
/* 2426 */     double max = valueToFind + tolerance;
/* 2427 */     for (int i = startIndex; i >= 0; i--) {
/* 2428 */       if (array[i] >= min && array[i] <= max) {
/* 2429 */         return i;
/*      */       }
/*      */     } 
/* 2432 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2445 */   public static boolean contains(double[] array, double valueToFind) { return (indexOf(array, valueToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2462 */   public static boolean contains(double[] array, double valueToFind, double tolerance) { return (indexOf(array, valueToFind, 0, tolerance) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2478 */   public static int indexOf(float[] array, float valueToFind) { return indexOf(array, valueToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(float[] array, float valueToFind, int startIndex) {
/* 2496 */     if (isEmpty(array)) {
/* 2497 */       return -1;
/*      */     }
/* 2499 */     if (startIndex < 0) {
/* 2500 */       startIndex = 0;
/*      */     }
/* 2502 */     for (int i = startIndex; i < array.length; i++) {
/* 2503 */       if (valueToFind == array[i]) {
/* 2504 */         return i;
/*      */       }
/*      */     } 
/* 2507 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2521 */   public static int lastIndexOf(float[] array, float valueToFind) { return lastIndexOf(array, valueToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(float[] array, float valueToFind, int startIndex) {
/* 2539 */     if (isEmpty(array)) {
/* 2540 */       return -1;
/*      */     }
/* 2542 */     if (startIndex < 0)
/* 2543 */       return -1; 
/* 2544 */     if (startIndex >= array.length) {
/* 2545 */       startIndex = array.length - 1;
/*      */     }
/* 2547 */     for (int i = startIndex; i >= 0; i--) {
/* 2548 */       if (valueToFind == array[i]) {
/* 2549 */         return i;
/*      */       }
/*      */     } 
/* 2552 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2565 */   public static boolean contains(float[] array, float valueToFind) { return (indexOf(array, valueToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2581 */   public static int indexOf(boolean[] array, boolean valueToFind) { return indexOf(array, valueToFind, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(boolean[] array, boolean valueToFind, int startIndex) {
/* 2600 */     if (isEmpty(array)) {
/* 2601 */       return -1;
/*      */     }
/* 2603 */     if (startIndex < 0) {
/* 2604 */       startIndex = 0;
/*      */     }
/* 2606 */     for (int i = startIndex; i < array.length; i++) {
/* 2607 */       if (valueToFind == array[i]) {
/* 2608 */         return i;
/*      */       }
/*      */     } 
/* 2611 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2626 */   public static int lastIndexOf(boolean[] array, boolean valueToFind) { return lastIndexOf(array, valueToFind, 2147483647); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(boolean[] array, boolean valueToFind, int startIndex) {
/* 2644 */     if (isEmpty(array)) {
/* 2645 */       return -1;
/*      */     }
/* 2647 */     if (startIndex < 0)
/* 2648 */       return -1; 
/* 2649 */     if (startIndex >= array.length) {
/* 2650 */       startIndex = array.length - 1;
/*      */     }
/* 2652 */     for (int i = startIndex; i >= 0; i--) {
/* 2653 */       if (valueToFind == array[i]) {
/* 2654 */         return i;
/*      */       }
/*      */     } 
/* 2657 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2670 */   public static boolean contains(boolean[] array, boolean valueToFind) { return (indexOf(array, valueToFind) != -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toPrimitive(Character[] array) {
/* 2688 */     if (array == null)
/* 2689 */       return null; 
/* 2690 */     if (array.length == 0) {
/* 2691 */       return EMPTY_CHAR_ARRAY;
/*      */     }
/* 2693 */     char[] result = new char[array.length];
/* 2694 */     for (int i = 0; i < array.length; i++) {
/* 2695 */       result[i] = array[i].charValue();
/*      */     }
/* 2697 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toPrimitive(Character[] array, char valueForNull) {
/* 2710 */     if (array == null)
/* 2711 */       return null; 
/* 2712 */     if (array.length == 0) {
/* 2713 */       return EMPTY_CHAR_ARRAY;
/*      */     }
/* 2715 */     char[] result = new char[array.length];
/* 2716 */     for (int i = 0; i < array.length; i++) {
/* 2717 */       Character b = array[i];
/* 2718 */       result[i] = (b == null) ? valueForNull : b.charValue();
/*      */     } 
/* 2720 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Character[] toObject(char[] array) {
/* 2732 */     if (array == null)
/* 2733 */       return null; 
/* 2734 */     if (array.length == 0) {
/* 2735 */       return EMPTY_CHARACTER_OBJECT_ARRAY;
/*      */     }
/* 2737 */     Character[] result = new Character[array.length];
/* 2738 */     for (int i = 0; i < array.length; i++) {
/* 2739 */       result[i] = Character.valueOf(array[i]);
/*      */     }
/* 2741 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] toPrimitive(Long[] array) {
/* 2756 */     if (array == null)
/* 2757 */       return null; 
/* 2758 */     if (array.length == 0) {
/* 2759 */       return EMPTY_LONG_ARRAY;
/*      */     }
/* 2761 */     long[] result = new long[array.length];
/* 2762 */     for (int i = 0; i < array.length; i++) {
/* 2763 */       result[i] = array[i].longValue();
/*      */     }
/* 2765 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] toPrimitive(Long[] array, long valueForNull) {
/* 2778 */     if (array == null)
/* 2779 */       return null; 
/* 2780 */     if (array.length == 0) {
/* 2781 */       return EMPTY_LONG_ARRAY;
/*      */     }
/* 2783 */     long[] result = new long[array.length];
/* 2784 */     for (int i = 0; i < array.length; i++) {
/* 2785 */       Long b = array[i];
/* 2786 */       result[i] = (b == null) ? valueForNull : b.longValue();
/*      */     } 
/* 2788 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long[] toObject(long[] array) {
/* 2800 */     if (array == null)
/* 2801 */       return null; 
/* 2802 */     if (array.length == 0) {
/* 2803 */       return EMPTY_LONG_OBJECT_ARRAY;
/*      */     }
/* 2805 */     Long[] result = new Long[array.length];
/* 2806 */     for (int i = 0; i < array.length; i++) {
/* 2807 */       result[i] = Long.valueOf(array[i]);
/*      */     }
/* 2809 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] toPrimitive(Integer[] array) {
/* 2824 */     if (array == null)
/* 2825 */       return null; 
/* 2826 */     if (array.length == 0) {
/* 2827 */       return EMPTY_INT_ARRAY;
/*      */     }
/* 2829 */     int[] result = new int[array.length];
/* 2830 */     for (int i = 0; i < array.length; i++) {
/* 2831 */       result[i] = array[i].intValue();
/*      */     }
/* 2833 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] toPrimitive(Integer[] array, int valueForNull) {
/* 2846 */     if (array == null)
/* 2847 */       return null; 
/* 2848 */     if (array.length == 0) {
/* 2849 */       return EMPTY_INT_ARRAY;
/*      */     }
/* 2851 */     int[] result = new int[array.length];
/* 2852 */     for (int i = 0; i < array.length; i++) {
/* 2853 */       Integer b = array[i];
/* 2854 */       result[i] = (b == null) ? valueForNull : b.intValue();
/*      */     } 
/* 2856 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer[] toObject(int[] array) {
/* 2868 */     if (array == null)
/* 2869 */       return null; 
/* 2870 */     if (array.length == 0) {
/* 2871 */       return EMPTY_INTEGER_OBJECT_ARRAY;
/*      */     }
/* 2873 */     Integer[] result = new Integer[array.length];
/* 2874 */     for (int i = 0; i < array.length; i++) {
/* 2875 */       result[i] = Integer.valueOf(array[i]);
/*      */     }
/* 2877 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] toPrimitive(Short[] array) {
/* 2892 */     if (array == null)
/* 2893 */       return null; 
/* 2894 */     if (array.length == 0) {
/* 2895 */       return EMPTY_SHORT_ARRAY;
/*      */     }
/* 2897 */     short[] result = new short[array.length];
/* 2898 */     for (int i = 0; i < array.length; i++) {
/* 2899 */       result[i] = array[i].shortValue();
/*      */     }
/* 2901 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] toPrimitive(Short[] array, short valueForNull) {
/* 2914 */     if (array == null)
/* 2915 */       return null; 
/* 2916 */     if (array.length == 0) {
/* 2917 */       return EMPTY_SHORT_ARRAY;
/*      */     }
/* 2919 */     short[] result = new short[array.length];
/* 2920 */     for (int i = 0; i < array.length; i++) {
/* 2921 */       Short b = array[i];
/* 2922 */       result[i] = (b == null) ? valueForNull : b.shortValue();
/*      */     } 
/* 2924 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Short[] toObject(short[] array) {
/* 2936 */     if (array == null)
/* 2937 */       return null; 
/* 2938 */     if (array.length == 0) {
/* 2939 */       return EMPTY_SHORT_OBJECT_ARRAY;
/*      */     }
/* 2941 */     Short[] result = new Short[array.length];
/* 2942 */     for (int i = 0; i < array.length; i++) {
/* 2943 */       result[i] = Short.valueOf(array[i]);
/*      */     }
/* 2945 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toPrimitive(Byte[] array) {
/* 2960 */     if (array == null)
/* 2961 */       return null; 
/* 2962 */     if (array.length == 0) {
/* 2963 */       return EMPTY_BYTE_ARRAY;
/*      */     }
/* 2965 */     byte[] result = new byte[array.length];
/* 2966 */     for (int i = 0; i < array.length; i++) {
/* 2967 */       result[i] = array[i].byteValue();
/*      */     }
/* 2969 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toPrimitive(Byte[] array, byte valueForNull) {
/* 2982 */     if (array == null)
/* 2983 */       return null; 
/* 2984 */     if (array.length == 0) {
/* 2985 */       return EMPTY_BYTE_ARRAY;
/*      */     }
/* 2987 */     byte[] result = new byte[array.length];
/* 2988 */     for (int i = 0; i < array.length; i++) {
/* 2989 */       Byte b = array[i];
/* 2990 */       result[i] = (b == null) ? valueForNull : b.byteValue();
/*      */     } 
/* 2992 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Byte[] toObject(byte[] array) {
/* 3004 */     if (array == null)
/* 3005 */       return null; 
/* 3006 */     if (array.length == 0) {
/* 3007 */       return EMPTY_BYTE_OBJECT_ARRAY;
/*      */     }
/* 3009 */     Byte[] result = new Byte[array.length];
/* 3010 */     for (int i = 0; i < array.length; i++) {
/* 3011 */       result[i] = Byte.valueOf(array[i]);
/*      */     }
/* 3013 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] toPrimitive(Double[] array) {
/* 3028 */     if (array == null)
/* 3029 */       return null; 
/* 3030 */     if (array.length == 0) {
/* 3031 */       return EMPTY_DOUBLE_ARRAY;
/*      */     }
/* 3033 */     double[] result = new double[array.length];
/* 3034 */     for (int i = 0; i < array.length; i++) {
/* 3035 */       result[i] = array[i].doubleValue();
/*      */     }
/* 3037 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] toPrimitive(Double[] array, double valueForNull) {
/* 3050 */     if (array == null)
/* 3051 */       return null; 
/* 3052 */     if (array.length == 0) {
/* 3053 */       return EMPTY_DOUBLE_ARRAY;
/*      */     }
/* 3055 */     double[] result = new double[array.length];
/* 3056 */     for (int i = 0; i < array.length; i++) {
/* 3057 */       Double b = array[i];
/* 3058 */       result[i] = (b == null) ? valueForNull : b.doubleValue();
/*      */     } 
/* 3060 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double[] toObject(double[] array) {
/* 3072 */     if (array == null)
/* 3073 */       return null; 
/* 3074 */     if (array.length == 0) {
/* 3075 */       return EMPTY_DOUBLE_OBJECT_ARRAY;
/*      */     }
/* 3077 */     Double[] result = new Double[array.length];
/* 3078 */     for (int i = 0; i < array.length; i++) {
/* 3079 */       result[i] = Double.valueOf(array[i]);
/*      */     }
/* 3081 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] toPrimitive(Float[] array) {
/* 3096 */     if (array == null)
/* 3097 */       return null; 
/* 3098 */     if (array.length == 0) {
/* 3099 */       return EMPTY_FLOAT_ARRAY;
/*      */     }
/* 3101 */     float[] result = new float[array.length];
/* 3102 */     for (int i = 0; i < array.length; i++) {
/* 3103 */       result[i] = array[i].floatValue();
/*      */     }
/* 3105 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] toPrimitive(Float[] array, float valueForNull) {
/* 3118 */     if (array == null)
/* 3119 */       return null; 
/* 3120 */     if (array.length == 0) {
/* 3121 */       return EMPTY_FLOAT_ARRAY;
/*      */     }
/* 3123 */     float[] result = new float[array.length];
/* 3124 */     for (int i = 0; i < array.length; i++) {
/* 3125 */       Float b = array[i];
/* 3126 */       result[i] = (b == null) ? valueForNull : b.floatValue();
/*      */     } 
/* 3128 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float[] toObject(float[] array) {
/* 3140 */     if (array == null)
/* 3141 */       return null; 
/* 3142 */     if (array.length == 0) {
/* 3143 */       return EMPTY_FLOAT_OBJECT_ARRAY;
/*      */     }
/* 3145 */     Float[] result = new Float[array.length];
/* 3146 */     for (int i = 0; i < array.length; i++) {
/* 3147 */       result[i] = Float.valueOf(array[i]);
/*      */     }
/* 3149 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] toPrimitive(Boolean[] array) {
/* 3164 */     if (array == null)
/* 3165 */       return null; 
/* 3166 */     if (array.length == 0) {
/* 3167 */       return EMPTY_BOOLEAN_ARRAY;
/*      */     }
/* 3169 */     boolean[] result = new boolean[array.length];
/* 3170 */     for (int i = 0; i < array.length; i++) {
/* 3171 */       result[i] = array[i].booleanValue();
/*      */     }
/* 3173 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] toPrimitive(Boolean[] array, boolean valueForNull) {
/* 3186 */     if (array == null)
/* 3187 */       return null; 
/* 3188 */     if (array.length == 0) {
/* 3189 */       return EMPTY_BOOLEAN_ARRAY;
/*      */     }
/* 3191 */     boolean[] result = new boolean[array.length];
/* 3192 */     for (int i = 0; i < array.length; i++) {
/* 3193 */       Boolean b = array[i];
/* 3194 */       result[i] = (b == null) ? valueForNull : b.booleanValue();
/*      */     } 
/* 3196 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Boolean[] toObject(boolean[] array) {
/* 3208 */     if (array == null)
/* 3209 */       return null; 
/* 3210 */     if (array.length == 0) {
/* 3211 */       return EMPTY_BOOLEAN_OBJECT_ARRAY;
/*      */     }
/* 3213 */     Boolean[] result = new Boolean[array.length];
/* 3214 */     for (int i = 0; i < array.length; i++) {
/* 3215 */       result[i] = array[i] ? Boolean.TRUE : Boolean.FALSE;
/*      */     }
/* 3217 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3229 */   public static boolean isEmpty(Object[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3240 */   public static boolean isEmpty(long[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3251 */   public static boolean isEmpty(int[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3262 */   public static boolean isEmpty(short[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3273 */   public static boolean isEmpty(char[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3284 */   public static boolean isEmpty(byte[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3295 */   public static boolean isEmpty(double[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3306 */   public static boolean isEmpty(float[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3317 */   public static boolean isEmpty(boolean[] array) { return (array == null || array.length == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3330 */   public static <T> boolean isNotEmpty(T[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3341 */   public static boolean isNotEmpty(long[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3352 */   public static boolean isNotEmpty(int[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3363 */   public static boolean isNotEmpty(short[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3374 */   public static boolean isNotEmpty(char[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3385 */   public static boolean isNotEmpty(byte[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3396 */   public static boolean isNotEmpty(double[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3407 */   public static boolean isNotEmpty(float[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3418 */   public static boolean isNotEmpty(boolean[] array) { return (array != null && array.length != 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] addAll(T[] array1, T... array2) {
/* 3446 */     if (array1 == null)
/* 3447 */       return (T[])clone(array2); 
/* 3448 */     if (array2 == null) {
/* 3449 */       return (T[])clone(array1);
/*      */     }
/* 3451 */     Class<?> type1 = array1.getClass().getComponentType();
/*      */     
/* 3453 */     T[] joinedArray = (T[])(Object[])Array.newInstance(type1, array1.length + array2.length);
/* 3454 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/*      */     try {
/* 3456 */       System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3457 */     } catch (ArrayStoreException ase) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3464 */       Class<?> type2 = array2.getClass().getComponentType();
/* 3465 */       if (!type1.isAssignableFrom(type2)) {
/* 3466 */         throw new IllegalArgumentException("Cannot store " + type2.getName() + " in an array of " + type1.getName(), ase);
/*      */       }
/*      */       
/* 3469 */       throw ase;
/*      */     } 
/* 3471 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] addAll(boolean[] array1, boolean... array2) {
/* 3492 */     if (array1 == null)
/* 3493 */       return clone(array2); 
/* 3494 */     if (array2 == null) {
/* 3495 */       return clone(array1);
/*      */     }
/* 3497 */     boolean[] joinedArray = new boolean[array1.length + array2.length];
/* 3498 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3499 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3500 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] addAll(char[] array1, char... array2) {
/* 3521 */     if (array1 == null)
/* 3522 */       return clone(array2); 
/* 3523 */     if (array2 == null) {
/* 3524 */       return clone(array1);
/*      */     }
/* 3526 */     char[] joinedArray = new char[array1.length + array2.length];
/* 3527 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3528 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3529 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] addAll(byte[] array1, byte... array2) {
/* 3550 */     if (array1 == null)
/* 3551 */       return clone(array2); 
/* 3552 */     if (array2 == null) {
/* 3553 */       return clone(array1);
/*      */     }
/* 3555 */     byte[] joinedArray = new byte[array1.length + array2.length];
/* 3556 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3557 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3558 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] addAll(short[] array1, short... array2) {
/* 3579 */     if (array1 == null)
/* 3580 */       return clone(array2); 
/* 3581 */     if (array2 == null) {
/* 3582 */       return clone(array1);
/*      */     }
/* 3584 */     short[] joinedArray = new short[array1.length + array2.length];
/* 3585 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3586 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3587 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] addAll(int[] array1, int... array2) {
/* 3608 */     if (array1 == null)
/* 3609 */       return clone(array2); 
/* 3610 */     if (array2 == null) {
/* 3611 */       return clone(array1);
/*      */     }
/* 3613 */     int[] joinedArray = new int[array1.length + array2.length];
/* 3614 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3615 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3616 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] addAll(long[] array1, long... array2) {
/* 3637 */     if (array1 == null)
/* 3638 */       return clone(array2); 
/* 3639 */     if (array2 == null) {
/* 3640 */       return clone(array1);
/*      */     }
/* 3642 */     long[] joinedArray = new long[array1.length + array2.length];
/* 3643 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3644 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3645 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] addAll(float[] array1, float... array2) {
/* 3666 */     if (array1 == null)
/* 3667 */       return clone(array2); 
/* 3668 */     if (array2 == null) {
/* 3669 */       return clone(array1);
/*      */     }
/* 3671 */     float[] joinedArray = new float[array1.length + array2.length];
/* 3672 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3673 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3674 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] addAll(double[] array1, double... array2) {
/* 3695 */     if (array1 == null)
/* 3696 */       return clone(array2); 
/* 3697 */     if (array2 == null) {
/* 3698 */       return clone(array1);
/*      */     }
/* 3700 */     double[] joinedArray = new double[array1.length + array2.length];
/* 3701 */     System.arraycopy(array1, 0, joinedArray, 0, array1.length);
/* 3702 */     System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
/* 3703 */     return joinedArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] add(T[] array, T element) {
/*      */     Class<?> type;
/* 3737 */     if (array != null) {
/* 3738 */       type = array.getClass();
/* 3739 */     } else if (element != null) {
/* 3740 */       type = element.getClass();
/*      */     } else {
/* 3742 */       throw new IllegalArgumentException("Arguments cannot both be null");
/*      */     } 
/*      */     
/* 3745 */     T[] newArray = (T[])(Object[])copyArrayGrow1(array, type);
/* 3746 */     newArray[newArray.length - 1] = element;
/* 3747 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] add(boolean[] array, boolean element) {
/* 3772 */     boolean[] newArray = (boolean[])copyArrayGrow1(array, boolean.class);
/* 3773 */     newArray[newArray.length - 1] = element;
/* 3774 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] add(byte[] array, byte element) {
/* 3799 */     byte[] newArray = (byte[])copyArrayGrow1(array, byte.class);
/* 3800 */     newArray[newArray.length - 1] = element;
/* 3801 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] add(char[] array, char element) {
/* 3826 */     char[] newArray = (char[])copyArrayGrow1(array, char.class);
/* 3827 */     newArray[newArray.length - 1] = element;
/* 3828 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] add(double[] array, double element) {
/* 3853 */     double[] newArray = (double[])copyArrayGrow1(array, double.class);
/* 3854 */     newArray[newArray.length - 1] = element;
/* 3855 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] add(float[] array, float element) {
/* 3880 */     float[] newArray = (float[])copyArrayGrow1(array, float.class);
/* 3881 */     newArray[newArray.length - 1] = element;
/* 3882 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] add(int[] array, int element) {
/* 3907 */     int[] newArray = (int[])copyArrayGrow1(array, int.class);
/* 3908 */     newArray[newArray.length - 1] = element;
/* 3909 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] add(long[] array, long element) {
/* 3934 */     long[] newArray = (long[])copyArrayGrow1(array, long.class);
/* 3935 */     newArray[newArray.length - 1] = element;
/* 3936 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] add(short[] array, short element) {
/* 3961 */     short[] newArray = (short[])copyArrayGrow1(array, short.class);
/* 3962 */     newArray[newArray.length - 1] = element;
/* 3963 */     return newArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object copyArrayGrow1(Object array, Class<?> newArrayComponentType) {
/* 3976 */     if (array != null) {
/* 3977 */       int arrayLength = Array.getLength(array);
/* 3978 */       Object newArray = Array.newInstance(array.getClass().getComponentType(), arrayLength + 1);
/* 3979 */       System.arraycopy(array, 0, newArray, 0, arrayLength);
/* 3980 */       return newArray;
/*      */     } 
/* 3982 */     return Array.newInstance(newArrayComponentType, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] add(T[] array, int index, T element) {
/* 4016 */     Class<?> clss = null;
/* 4017 */     if (array != null) {
/* 4018 */       clss = array.getClass().getComponentType();
/* 4019 */     } else if (element != null) {
/* 4020 */       clss = element.getClass();
/*      */     } else {
/* 4022 */       throw new IllegalArgumentException("Array and element cannot both be null");
/*      */     } 
/*      */     
/* 4025 */     return (T[])(Object[])add(array, index, element, clss);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4057 */   public static boolean[] add(boolean[] array, int index, boolean element) { return (boolean[])add(array, index, Boolean.valueOf(element), boolean.class); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4089 */   public static char[] add(char[] array, int index, char element) { return (char[])add(array, index, Character.valueOf(element), char.class); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4120 */   public static byte[] add(byte[] array, int index, byte element) { return (byte[])add(array, index, Byte.valueOf(element), byte.class); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4151 */   public static short[] add(short[] array, int index, short element) { return (short[])add(array, index, Short.valueOf(element), short.class); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4182 */   public static int[] add(int[] array, int index, int element) { return (int[])add(array, index, Integer.valueOf(element), int.class); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4213 */   public static long[] add(long[] array, int index, long element) { return (long[])add(array, index, Long.valueOf(element), long.class); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4244 */   public static float[] add(float[] array, int index, float element) { return (float[])add(array, index, Float.valueOf(element), float.class); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4275 */   public static double[] add(double[] array, int index, double element) { return (double[])add(array, index, Double.valueOf(element), double.class); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object add(Object array, int index, Object element, Class<?> clss) {
/* 4290 */     if (array == null) {
/* 4291 */       if (index != 0) {
/* 4292 */         throw new IndexOutOfBoundsException("Index: " + index + ", Length: 0");
/*      */       }
/* 4294 */       Object joinedArray = Array.newInstance(clss, 1);
/* 4295 */       Array.set(joinedArray, 0, element);
/* 4296 */       return joinedArray;
/*      */     } 
/* 4298 */     int length = Array.getLength(array);
/* 4299 */     if (index > length || index < 0) {
/* 4300 */       throw new IndexOutOfBoundsException("Index: " + index + ", Length: " + length);
/*      */     }
/* 4302 */     Object result = Array.newInstance(clss, length + 1);
/* 4303 */     System.arraycopy(array, 0, result, 0, index);
/* 4304 */     Array.set(result, index, element);
/* 4305 */     if (index < length) {
/* 4306 */       System.arraycopy(array, index, result, index + 1, length - index);
/*      */     }
/* 4308 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4342 */   public static <T> T[] remove(T[] array, int index) { return (T[])(Object[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T> T[] removeElement(T[] array, Object element) {
/* 4372 */     int index = indexOf(array, element);
/* 4373 */     if (index == -1) {
/* 4374 */       return (T[])clone(array);
/*      */     }
/* 4376 */     return (T[])remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4408 */   public static boolean[] remove(boolean[] array, int index) { return (boolean[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean[] removeElement(boolean[] array, boolean element) {
/* 4437 */     int index = indexOf(array, element);
/* 4438 */     if (index == -1) {
/* 4439 */       return clone(array);
/*      */     }
/* 4441 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4473 */   public static byte[] remove(byte[] array, int index) { return (byte[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] removeElement(byte[] array, byte element) {
/* 4502 */     int index = indexOf(array, element);
/* 4503 */     if (index == -1) {
/* 4504 */       return clone(array);
/*      */     }
/* 4506 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4538 */   public static char[] remove(char[] array, int index) { return (char[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] removeElement(char[] array, char element) {
/* 4567 */     int index = indexOf(array, element);
/* 4568 */     if (index == -1) {
/* 4569 */       return clone(array);
/*      */     }
/* 4571 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4603 */   public static double[] remove(double[] array, int index) { return (double[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double[] removeElement(double[] array, double element) {
/* 4632 */     int index = indexOf(array, element);
/* 4633 */     if (index == -1) {
/* 4634 */       return clone(array);
/*      */     }
/* 4636 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4668 */   public static float[] remove(float[] array, int index) { return (float[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float[] removeElement(float[] array, float element) {
/* 4697 */     int index = indexOf(array, element);
/* 4698 */     if (index == -1) {
/* 4699 */       return clone(array);
/*      */     }
/* 4701 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4733 */   public static int[] remove(int[] array, int index) { return (int[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int[] removeElement(int[] array, int element) {
/* 4762 */     int index = indexOf(array, element);
/* 4763 */     if (index == -1) {
/* 4764 */       return clone(array);
/*      */     }
/* 4766 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4798 */   public static long[] remove(long[] array, int index) { return (long[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long[] removeElement(long[] array, long element) {
/* 4827 */     int index = indexOf(array, element);
/* 4828 */     if (index == -1) {
/* 4829 */       return clone(array);
/*      */     }
/* 4831 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4863 */   public static short[] remove(short[] array, int index) { return (short[])remove(array, index); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short[] removeElement(short[] array, short element) {
/* 4892 */     int index = indexOf(array, element);
/* 4893 */     if (index == -1) {
/* 4894 */       return clone(array);
/*      */     }
/* 4896 */     return remove(array, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object remove(Object array, int index) {
/* 4921 */     int length = getLength(array);
/* 4922 */     if (index < 0 || index >= length) {
/* 4923 */       throw new IndexOutOfBoundsException("Index: " + index + ", Length: " + length);
/*      */     }
/*      */     
/* 4926 */     Object result = Array.newInstance(array.getClass().getComponentType(), length - 1);
/* 4927 */     System.arraycopy(array, 0, result, 0, index);
/* 4928 */     if (index < length - 1) {
/* 4929 */       System.arraycopy(array, index + 1, result, index, length - index - 1);
/*      */     }
/*      */     
/* 4932 */     return result;
/*      */   }
/*      */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\ArrayUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */