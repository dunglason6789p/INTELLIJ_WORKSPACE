/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnumUtils
/*     */ {
/*     */   public static <E extends Enum<E>> Map<String, E> getEnumMap(Class<E> enumClass) {
/*  52 */     Map<String, E> map = new LinkedHashMap<String, E>(); Enum[] arr$; int len$, i$;
/*  53 */     for (arr$ = (Enum[])enumClass.getEnumConstants(), len$ = arr$.length, i$ = 0; i$ < len$; ) { E e = (E)arr$[i$];
/*  54 */       map.put(e.name(), e); i$++; }
/*     */     
/*  56 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static <E extends Enum<E>> List<E> getEnumList(Class<E> enumClass) { return new ArrayList(Arrays.asList(enumClass.getEnumConstants())); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends Enum<E>> boolean isValidEnum(Class<E> enumClass, String enumName) {
/*  84 */     if (enumName == null) {
/*  85 */       return false;
/*     */     }
/*     */     try {
/*  88 */       Enum.valueOf(enumClass, enumName);
/*  89 */       return true;
/*  90 */     } catch (IllegalArgumentException ex) {
/*  91 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends Enum<E>> E getEnum(Class<E> enumClass, String enumName) {
/* 107 */     if (enumName == null) {
/* 108 */       return null;
/*     */     }
/*     */     try {
/* 111 */       return (E)Enum.valueOf(enumClass, enumName);
/* 112 */     } catch (IllegalArgumentException ex) {
/* 113 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\EnumUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */