/*     */ package org.apache.commons.lang3.concurrent;
/*     */ 
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BackgroundInitializer<T>
/*     */   extends Object
/*     */   implements ConcurrentInitializer<T>
/*     */ {
/*     */   private ExecutorService externalExecutor;
/*     */   private ExecutorService executor;
/*     */   private Future<T> future;
/*     */   
/* 102 */   protected BackgroundInitializer() { this(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   protected BackgroundInitializer(ExecutorService exec) { setExternalExecutor(exec); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public final ExecutorService getExternalExecutor() { return this.externalExecutor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public boolean isStarted() { return (this.future != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setExternalExecutor(ExecutorService externalExecutor) {
/* 155 */     if (isStarted()) {
/* 156 */       throw new IllegalStateException("Cannot set ExecutorService after start()!");
/*     */     }
/*     */ 
/*     */     
/* 160 */     this.externalExecutor = externalExecutor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean start() {
/* 175 */     if (!isStarted()) {
/*     */       ExecutorService tempExec;
/*     */ 
/*     */ 
/*     */       
/* 180 */       this.executor = getExternalExecutor();
/* 181 */       if (this.executor == null) {
/* 182 */         this.executor = tempExec = createExecutor();
/*     */       } else {
/* 184 */         tempExec = null;
/*     */       } 
/*     */       
/* 187 */       this.future = this.executor.submit(createTask(tempExec));
/*     */       
/* 189 */       return true;
/*     */     } 
/*     */     
/* 192 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T get() throws ConcurrentException {
/*     */     try {
/* 211 */       return (T)getFuture().get();
/* 212 */     } catch (ExecutionException execex) {
/* 213 */       ConcurrentUtils.handleCause(execex);
/* 214 */       return null;
/* 215 */     } catch (InterruptedException iex) {
/*     */       
/* 217 */       Thread.currentThread().interrupt();
/* 218 */       throw new ConcurrentException(iex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Future<T> getFuture() {
/* 231 */     if (this.future == null) {
/* 232 */       throw new IllegalStateException("start() must be called first!");
/*     */     }
/*     */     
/* 235 */     return this.future;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   protected final ExecutorService getActiveExecutor() { return this.executor; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   protected int getTaskCount() { return 1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract T initialize() throws ConcurrentException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   private Callable<T> createTask(ExecutorService execDestroy) { return new InitializationTask(execDestroy); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   private ExecutorService createExecutor() { return Executors.newFixedThreadPool(getTaskCount()); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class InitializationTask
/*     */     extends Object
/*     */     implements Callable<T>
/*     */   {
/*     */     private final ExecutorService execFinally;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 314 */     public InitializationTask(ExecutorService exec) { this.execFinally = exec; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T call() throws ConcurrentException {
/*     */       
/* 325 */       try { object = BackgroundInitializer.this.initialize();
/*     */ 
/*     */         
/* 328 */         return (T)object; } finally { if (this.execFinally != null) this.execFinally.shutdown();  }
/*     */     
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\concurrent\BackgroundInitializer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */