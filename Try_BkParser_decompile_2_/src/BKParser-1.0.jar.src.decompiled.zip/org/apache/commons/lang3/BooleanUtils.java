/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import org.apache.commons.lang3.math.NumberUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BooleanUtils
/*     */ {
/*     */   public static Boolean negate(Boolean bool) {
/*  64 */     if (bool == null) {
/*  65 */       return null;
/*     */     }
/*  67 */     return bool.booleanValue() ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public static boolean isTrue(Boolean bool) { return Boolean.TRUE.equals(bool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public static boolean isNotTrue(Boolean bool) { return !isTrue(bool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public static boolean isFalse(Boolean bool) { return Boolean.FALSE.equals(bool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   public static boolean isNotFalse(Boolean bool) { return !isFalse(bool); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public static boolean toBoolean(Boolean bool) { return (bool != null && bool.booleanValue()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBooleanDefaultIfNull(Boolean bool, boolean valueIfNull) {
/* 176 */     if (bool == null) {
/* 177 */       return valueIfNull;
/*     */     }
/* 179 */     return bool.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   public static boolean toBoolean(int value) { return (value != 0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 217 */   public static Boolean toBooleanObject(int value) { return (value == 0) ? Boolean.FALSE : Boolean.TRUE; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(Integer value) {
/* 239 */     if (value == null) {
/* 240 */       return null;
/*     */     }
/* 242 */     return (value.intValue() == 0) ? Boolean.FALSE : Boolean.TRUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(int value, int trueValue, int falseValue) {
/* 262 */     if (value == trueValue) {
/* 263 */       return true;
/*     */     }
/* 265 */     if (value == falseValue) {
/* 266 */       return false;
/*     */     }
/*     */     
/* 269 */     throw new IllegalArgumentException("The Integer did not match either specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(Integer value, Integer trueValue, Integer falseValue) {
/* 290 */     if (value == null) {
/* 291 */       if (trueValue == null) {
/* 292 */         return true;
/*     */       }
/* 294 */       if (falseValue == null)
/* 295 */         return false; 
/*     */     } else {
/* 297 */       if (value.equals(trueValue))
/* 298 */         return true; 
/* 299 */       if (value.equals(falseValue)) {
/* 300 */         return false;
/*     */       }
/*     */     } 
/* 303 */     throw new IllegalArgumentException("The Integer did not match either specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(int value, int trueValue, int falseValue, int nullValue) {
/* 325 */     if (value == trueValue) {
/* 326 */       return Boolean.TRUE;
/*     */     }
/* 328 */     if (value == falseValue) {
/* 329 */       return Boolean.FALSE;
/*     */     }
/* 331 */     if (value == nullValue) {
/* 332 */       return null;
/*     */     }
/*     */     
/* 335 */     throw new IllegalArgumentException("The Integer did not match any specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(Integer value, Integer trueValue, Integer falseValue, Integer nullValue) {
/* 357 */     if (value == null) {
/* 358 */       if (trueValue == null) {
/* 359 */         return Boolean.TRUE;
/*     */       }
/* 361 */       if (falseValue == null) {
/* 362 */         return Boolean.FALSE;
/*     */       }
/* 364 */       if (nullValue == null)
/* 365 */         return null; 
/*     */     } else {
/* 367 */       if (value.equals(trueValue))
/* 368 */         return Boolean.TRUE; 
/* 369 */       if (value.equals(falseValue))
/* 370 */         return Boolean.FALSE; 
/* 371 */       if (value.equals(nullValue)) {
/* 372 */         return null;
/*     */       }
/*     */     } 
/* 375 */     throw new IllegalArgumentException("The Integer did not match any specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 393 */   public static int toInteger(boolean bool) { return bool ? 1 : 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 409 */   public static Integer toIntegerObject(boolean bool) { return bool ? NumberUtils.INTEGER_ONE : NumberUtils.INTEGER_ZERO; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer toIntegerObject(Boolean bool) {
/* 427 */     if (bool == null) {
/* 428 */       return null;
/*     */     }
/* 430 */     return bool.booleanValue() ? NumberUtils.INTEGER_ONE : NumberUtils.INTEGER_ZERO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 447 */   public static int toInteger(boolean bool, int trueValue, int falseValue) { return bool ? trueValue : falseValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int toInteger(Boolean bool, int trueValue, int falseValue, int nullValue) {
/* 466 */     if (bool == null) {
/* 467 */       return nullValue;
/*     */     }
/* 469 */     return bool.booleanValue() ? trueValue : falseValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 486 */   public static Integer toIntegerObject(boolean bool, Integer trueValue, Integer falseValue) { return bool ? trueValue : falseValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer toIntegerObject(Boolean bool, Integer trueValue, Integer falseValue, Integer nullValue) {
/* 505 */     if (bool == null) {
/* 506 */       return nullValue;
/*     */     }
/* 508 */     return bool.booleanValue() ? trueValue : falseValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(String str) {
/*     */     char ch4;
/*     */     char ch3;
/*     */     char ch3;
/*     */     char ch2;
/*     */     char ch2;
/*     */     char ch2;
/*     */     char ch1;
/*     */     char ch1;
/*     */     char ch1;
/*     */     char ch1;
/*     */     char ch0;
/*     */     char ch0;
/*     */     char ch0;
/*     */     char ch0;
/*     */     char ch0;
/* 545 */     if (str == "true") {
/* 546 */       return Boolean.TRUE;
/*     */     }
/* 548 */     if (str == null) {
/* 549 */       return null;
/*     */     }
/* 551 */     switch (str.length()) {
/*     */       case 1:
/* 553 */         ch0 = str.charAt(0);
/* 554 */         if (ch0 == 'y' || ch0 == 'Y' || ch0 == 't' || ch0 == 'T')
/*     */         {
/* 556 */           return Boolean.TRUE;
/*     */         }
/* 558 */         if (ch0 == 'n' || ch0 == 'N' || ch0 == 'f' || ch0 == 'F')
/*     */         {
/* 560 */           return Boolean.FALSE;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 2:
/* 565 */         ch0 = str.charAt(0);
/* 566 */         ch1 = str.charAt(1);
/* 567 */         if ((ch0 == 'o' || ch0 == 'O') && (ch1 == 'n' || ch1 == 'N'))
/*     */         {
/* 569 */           return Boolean.TRUE;
/*     */         }
/* 571 */         if ((ch0 == 'n' || ch0 == 'N') && (ch1 == 'o' || ch1 == 'O'))
/*     */         {
/* 573 */           return Boolean.FALSE;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 3:
/* 578 */         ch0 = str.charAt(0);
/* 579 */         ch1 = str.charAt(1);
/* 580 */         ch2 = str.charAt(2);
/* 581 */         if ((ch0 == 'y' || ch0 == 'Y') && (ch1 == 'e' || ch1 == 'E') && (ch2 == 's' || ch2 == 'S'))
/*     */         {
/*     */           
/* 584 */           return Boolean.TRUE;
/*     */         }
/* 586 */         if ((ch0 == 'o' || ch0 == 'O') && (ch1 == 'f' || ch1 == 'F') && (ch2 == 'f' || ch2 == 'F'))
/*     */         {
/*     */           
/* 589 */           return Boolean.FALSE;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 4:
/* 594 */         ch0 = str.charAt(0);
/* 595 */         ch1 = str.charAt(1);
/* 596 */         ch2 = str.charAt(2);
/* 597 */         ch3 = str.charAt(3);
/* 598 */         if ((ch0 == 't' || ch0 == 'T') && (ch1 == 'r' || ch1 == 'R') && (ch2 == 'u' || ch2 == 'U') && (ch3 == 'e' || ch3 == 'E'))
/*     */         {
/*     */ 
/*     */           
/* 602 */           return Boolean.TRUE;
/*     */         }
/*     */         break;
/*     */       
/*     */       case 5:
/* 607 */         ch0 = str.charAt(0);
/* 608 */         ch1 = str.charAt(1);
/* 609 */         ch2 = str.charAt(2);
/* 610 */         ch3 = str.charAt(3);
/* 611 */         ch4 = str.charAt(4);
/* 612 */         if ((ch0 == 'f' || ch0 == 'F') && (ch1 == 'a' || ch1 == 'A') && (ch2 == 'l' || ch2 == 'L') && (ch3 == 's' || ch3 == 'S') && (ch4 == 'e' || ch4 == 'E'))
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 617 */           return Boolean.FALSE;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 623 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean toBooleanObject(String str, String trueString, String falseString, String nullString) {
/* 646 */     if (str == null) {
/* 647 */       if (trueString == null) {
/* 648 */         return Boolean.TRUE;
/*     */       }
/* 650 */       if (falseString == null) {
/* 651 */         return Boolean.FALSE;
/*     */       }
/* 653 */       if (nullString == null)
/* 654 */         return null; 
/*     */     } else {
/* 656 */       if (str.equals(trueString))
/* 657 */         return Boolean.TRUE; 
/* 658 */       if (str.equals(falseString))
/* 659 */         return Boolean.FALSE; 
/* 660 */       if (str.equals(nullString)) {
/* 661 */         return null;
/*     */       }
/*     */     } 
/* 664 */     throw new IllegalArgumentException("The String did not match any specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 695 */   public static boolean toBoolean(String str) { return (toBooleanObject(str) == Boolean.TRUE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean toBoolean(String str, String trueString, String falseString) {
/* 713 */     if (str == trueString)
/* 714 */       return true; 
/* 715 */     if (str == falseString)
/* 716 */       return false; 
/* 717 */     if (str != null) {
/* 718 */       if (str.equals(trueString))
/* 719 */         return true; 
/* 720 */       if (str.equals(falseString)) {
/* 721 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 725 */     throw new IllegalArgumentException("The String did not match either specified value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 744 */   public static String toStringTrueFalse(Boolean bool) { return toString(bool, "true", "false", null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 761 */   public static String toStringOnOff(Boolean bool) { return toString(bool, "on", "off", null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 778 */   public static String toStringYesNo(Boolean bool) { return toString(bool, "yes", "no", null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toString(Boolean bool, String trueString, String falseString, String nullString) {
/* 797 */     if (bool == null) {
/* 798 */       return nullString;
/*     */     }
/* 800 */     return bool.booleanValue() ? trueString : falseString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 818 */   public static String toStringTrueFalse(boolean bool) { return toString(bool, "true", "false"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 834 */   public static String toStringOnOff(boolean bool) { return toString(bool, "on", "off"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 850 */   public static String toStringYesNo(boolean bool) { return toString(bool, "yes", "no"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 867 */   public static String toString(boolean bool, String trueString, String falseString) { return bool ? trueString : falseString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean xor(boolean... array) {
/* 888 */     if (array == null) {
/* 889 */       throw new IllegalArgumentException("The Array must not be null");
/*     */     }
/* 891 */     if (array.length == 0) {
/* 892 */       throw new IllegalArgumentException("Array is empty");
/*     */     }
/*     */ 
/*     */     
/* 896 */     int trueCount = 0;
/* 897 */     for (boolean element : array) {
/*     */ 
/*     */       
/* 900 */       if (element) {
/* 901 */         if (trueCount < 1) {
/* 902 */           trueCount++;
/*     */         } else {
/* 904 */           return false;
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 910 */     return (trueCount == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Boolean xor(Boolean... array) {
/* 929 */     if (array == null) {
/* 930 */       throw new IllegalArgumentException("The Array must not be null");
/*     */     }
/* 932 */     if (array.length == 0) {
/* 933 */       throw new IllegalArgumentException("Array is empty");
/*     */     }
/* 935 */     boolean[] primitive = null;
/*     */     try {
/* 937 */       primitive = ArrayUtils.toPrimitive(array);
/* 938 */     } catch (NullPointerException ex) {
/* 939 */       throw new IllegalArgumentException("The array must not contain any null elements");
/*     */     } 
/* 941 */     return xor(primitive) ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\BooleanUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */