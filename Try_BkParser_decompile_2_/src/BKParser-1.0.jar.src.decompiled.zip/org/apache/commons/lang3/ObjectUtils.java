/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.lang3.exception.CloneFailedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectUtils
/*     */ {
/*  55 */   public static final Null NULL = new Null();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public static <T> T defaultIfNull(T object, T defaultValue) { return (object != null) ? object : defaultValue; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T firstNonNull(T... values) {
/* 114 */     if (values != null) {
/* 115 */       for (T val : values) {
/* 116 */         if (val != null) {
/* 117 */           return val;
/*     */         }
/*     */       } 
/*     */     }
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(Object object1, Object object2) {
/* 146 */     if (object1 == object2) {
/* 147 */       return true;
/*     */     }
/* 149 */     if (object1 == null || object2 == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     return object1.equals(object2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public static boolean notEqual(Object object1, Object object2) { return !equals(object1, object2); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   public static int hashCode(Object obj) { return (obj == null) ? 0 : obj.hashCode(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int hashCodeMulti(Object... objects) {
/* 217 */     int hash = 1;
/* 218 */     if (objects != null) {
/* 219 */       for (Object object : objects) {
/* 220 */         hash = hash * 31 + hashCode(object);
/*     */       }
/*     */     }
/* 223 */     return hash;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String identityToString(Object object) {
/* 245 */     if (object == null) {
/* 246 */       return null;
/*     */     }
/* 248 */     StringBuffer buffer = new StringBuffer();
/* 249 */     identityToString(buffer, object);
/* 250 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void identityToString(StringBuffer buffer, Object object) {
/* 269 */     if (object == null) {
/* 270 */       throw new NullPointerException("Cannot get the toString of a null identity");
/*     */     }
/* 272 */     buffer.append(object.getClass().getName()).append('@').append(Integer.toHexString(System.identityHashCode(object)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 297 */   public static String toString(Object obj) { return (obj == null) ? "" : obj.toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 320 */   public static String toString(Object obj, String nullStr) { return (obj == null) ? nullStr : obj.toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Comparable<? super T>> T min(T... values) {
/* 339 */     T result = null;
/* 340 */     if (values != null) {
/* 341 */       for (T value : values) {
/* 342 */         if (compare(value, result, true) < 0) {
/* 343 */           result = value;
/*     */         }
/*     */       } 
/*     */     }
/* 347 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Comparable<? super T>> T max(T... values) {
/* 364 */     T result = null;
/* 365 */     if (values != null) {
/* 366 */       for (T value : values) {
/* 367 */         if (compare(value, result, false) > 0) {
/* 368 */           result = value;
/*     */         }
/*     */       } 
/*     */     }
/* 372 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 386 */   public static <T extends Comparable<? super T>> int compare(T c1, T c2) { return compare(c1, c2, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Comparable<? super T>> int compare(T c1, T c2, boolean nullGreater) {
/* 403 */     if (c1 == c2)
/* 404 */       return 0; 
/* 405 */     if (c1 == null)
/* 406 */       return nullGreater ? 1 : -1; 
/* 407 */     if (c2 == null) {
/* 408 */       return nullGreater ? -1 : 1;
/*     */     }
/* 410 */     return c1.compareTo(c2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T clone(T obj) {
/* 423 */     if (obj instanceof Cloneable) {
/*     */       Object result;
/* 425 */       if (obj.getClass().isArray()) {
/* 426 */         Class<?> componentType = obj.getClass().getComponentType();
/* 427 */         if (!componentType.isPrimitive()) {
/* 428 */           result = ((Object[])obj).clone();
/*     */         } else {
/* 430 */           int length = Array.getLength(obj);
/* 431 */           result = Array.newInstance(componentType, length);
/* 432 */           while (length-- > 0) {
/* 433 */             Array.set(result, length, Array.get(obj, length));
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         try {
/* 438 */           Method clone = obj.getClass().getMethod("clone", new Class[0]);
/* 439 */           result = clone.invoke(obj, new Object[0]);
/* 440 */         } catch (NoSuchMethodException e) {
/* 441 */           throw new CloneFailedException("Cloneable type " + obj.getClass().getName() + " has no clone method", e);
/*     */         
/*     */         }
/* 444 */         catch (IllegalAccessException e) {
/* 445 */           throw new CloneFailedException("Cannot clone Cloneable type " + obj.getClass().getName(), e);
/*     */         }
/* 447 */         catch (InvocationTargetException e) {
/* 448 */           throw new CloneFailedException("Exception cloning Cloneable type " + obj.getClass().getName(), e.getCause());
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 453 */       return (T)result;
/*     */     } 
/*     */ 
/*     */     
/* 457 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T cloneIfPossible(T obj) {
/* 477 */     T clone = (T)clone(obj);
/* 478 */     return (clone == null) ? obj : clone;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Null
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 7092611880189329093L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 517 */     private Object readResolve() { return ObjectUtils.NULL; }
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\ObjectUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */