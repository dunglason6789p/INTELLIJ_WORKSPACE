/*      */ package org.apache.commons.lang3;
/*      */ 
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   public static final String EMPTY = "";
/*      */   public static final int INDEX_NOT_FOUND = -1;
/*      */   private static final int PAD_LIMIT = 8192;
/*  147 */   private static final Pattern WHITESPACE_BLOCK = Pattern.compile("\\s+");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   public static boolean isEmpty(CharSequence cs) { return (cs == null || cs.length() == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   public static boolean isNotEmpty(CharSequence cs) { return !isEmpty(cs); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isBlank(CharSequence cs) {
/*      */     int strLen;
/*  223 */     if (cs == null || (strLen = cs.length()) == 0) {
/*  224 */       return true;
/*      */     }
/*  226 */     for (int i = 0; i < strLen; i++) {
/*  227 */       if (!Character.isWhitespace(cs.charAt(i))) {
/*  228 */         return false;
/*      */       }
/*      */     } 
/*  231 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  252 */   public static boolean isNotBlank(CharSequence cs) { return !isBlank(cs); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  281 */   public static String trim(String str) { return (str == null) ? null : str.trim(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trimToNull(String str) {
/*  307 */     String ts = trim(str);
/*  308 */     return isEmpty(ts) ? null : ts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  333 */   public static String trimToEmpty(String str) { return (str == null) ? "" : str.trim(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  361 */   public static String strip(String str) { return strip(str, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripToNull(String str) {
/*  388 */     if (str == null) {
/*  389 */       return null;
/*      */     }
/*  391 */     str = strip(str, null);
/*  392 */     return (str.length() == 0) ? null : str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  418 */   public static String stripToEmpty(String str) { return (str == null) ? "" : strip(str, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String strip(String str, String stripChars) {
/*  448 */     if (isEmpty(str)) {
/*  449 */       return str;
/*      */     }
/*  451 */     str = stripStart(str, stripChars);
/*  452 */     return stripEnd(str, stripChars);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripStart(String str, String stripChars) {
/*      */     int strLen;
/*  481 */     if (str == null || (strLen = str.length()) == 0) {
/*  482 */       return str;
/*      */     }
/*  484 */     int start = 0;
/*  485 */     if (stripChars == null) {
/*  486 */       while (start != strLen && Character.isWhitespace(str.charAt(start)))
/*  487 */         start++; 
/*      */     } else {
/*  489 */       if (stripChars.length() == 0) {
/*  490 */         return str;
/*      */       }
/*  492 */       while (start != strLen && stripChars.indexOf(str.charAt(start)) != -1) {
/*  493 */         start++;
/*      */       }
/*      */     } 
/*  496 */     return str.substring(start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripEnd(String str, String stripChars) {
/*      */     int end;
/*  526 */     if (str == null || (end = str.length()) == 0) {
/*  527 */       return str;
/*      */     }
/*      */     
/*  530 */     if (stripChars == null) {
/*  531 */       while (end != 0 && Character.isWhitespace(str.charAt(end - 1)))
/*  532 */         end--; 
/*      */     } else {
/*  534 */       if (stripChars.length() == 0) {
/*  535 */         return str;
/*      */       }
/*  537 */       while (end != 0 && stripChars.indexOf(str.charAt(end - 1)) != -1) {
/*  538 */         end--;
/*      */       }
/*      */     } 
/*  541 */     return str.substring(0, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  566 */   public static String[] stripAll(String... strs) { return stripAll(strs, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] stripAll(String[] strs, String stripChars) {
/*      */     int strsLen;
/*  596 */     if (strs == null || (strsLen = strs.length) == 0) {
/*  597 */       return strs;
/*      */     }
/*  599 */     String[] newArr = new String[strsLen];
/*  600 */     for (int i = 0; i < strsLen; i++) {
/*  601 */       newArr[i] = strip(strs[i], stripChars);
/*      */     }
/*  603 */     return newArr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String stripAccents(String input) {
/*  628 */     if (input == null) {
/*  629 */       return null;
/*      */     }
/*      */     try {
/*  632 */       String result = null;
/*  633 */       if (java6Available) {
/*  634 */         result = removeAccentsJava6(input);
/*  635 */       } else if (sunAvailable) {
/*  636 */         result = removeAccentsSUN(input);
/*      */       } else {
/*  638 */         throw new UnsupportedOperationException("The stripAccents(CharSequence) method requires at least Java 1.6 or a Sun JVM");
/*      */       } 
/*      */ 
/*      */       
/*  642 */       return result;
/*  643 */     } catch (IllegalArgumentException iae) {
/*  644 */       throw new RuntimeException("IllegalArgumentException occurred", iae);
/*  645 */     } catch (IllegalAccessException iae) {
/*  646 */       throw new RuntimeException("IllegalAccessException occurred", iae);
/*  647 */     } catch (InvocationTargetException ite) {
/*  648 */       throw new RuntimeException("InvocationTargetException occurred", ite);
/*  649 */     } catch (SecurityException se) {
/*  650 */       throw new RuntimeException("SecurityException occurred", se);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String removeAccentsJava6(CharSequence text) throws IllegalAccessException, InvocationTargetException {
/*  670 */     if (!java6Available || java6NormalizerFormNFD == null) {
/*  671 */       throw new IllegalStateException("java.text.Normalizer is not available");
/*      */     }
/*      */     
/*  674 */     result = (String)java6NormalizeMethod.invoke(null, new Object[] { text, java6NormalizerFormNFD });
/*  675 */     return java6Pattern.matcher(result).replaceAll("");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String removeAccentsSUN(CharSequence text) throws IllegalAccessException, InvocationTargetException {
/*  694 */     if (!sunAvailable) {
/*  695 */       throw new IllegalStateException("sun.text.Normalizer is not available");
/*      */     }
/*      */     
/*  698 */     result = (String)sunDecomposeMethod.invoke(null, new Object[] { text, Boolean.FALSE, Integer.valueOf(0) });
/*  699 */     return sunPattern.matcher(result).replaceAll("");
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean sunAvailable = false;
/*      */   
/*  705 */   private static Method sunDecomposeMethod = null;
/*  706 */   private static final Pattern sunPattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
/*      */   
/*      */   private static boolean java6Available = false;
/*  709 */   private static Method java6NormalizeMethod = null;
/*  710 */   private static Object java6NormalizerFormNFD = null;
/*  711 */   private static final Pattern java6Pattern = sunPattern;
/*      */ 
/*      */ 
/*      */   
/*      */   static  {
/*      */     try {
/*  717 */       normalizerFormClass = Thread.currentThread().getContextClassLoader().loadClass("java.text.Normalizer$Form");
/*      */       
/*  719 */       java6NormalizerFormNFD = normalizerFormClass.getField("NFD").get(null);
/*  720 */       Class<?> normalizerClass = Thread.currentThread().getContextClassLoader().loadClass("java.text.Normalizer");
/*      */       
/*  722 */       java6NormalizeMethod = normalizerClass.getMethod("normalize", new Class[] { CharSequence.class, normalizerFormClass });
/*      */       
/*  724 */       java6Available = true;
/*  725 */     } catch (ClassNotFoundException e) {
/*  726 */       java6Available = false;
/*  727 */     } catch (NoSuchFieldException e) {
/*  728 */       java6Available = false;
/*  729 */     } catch (IllegalAccessException e) {
/*  730 */       java6Available = false;
/*  731 */     } catch (NoSuchMethodException e) {
/*  732 */       java6Available = false;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  737 */       Class clazz = Thread.currentThread().getContextClassLoader().loadClass("sun.text.Normalizer");
/*      */       
/*  739 */       sunDecomposeMethod = clazz.getMethod("decompose", new Class[] { String.class, boolean.class, int.class });
/*      */       
/*  741 */       sunAvailable = true;
/*  742 */     } catch (ClassNotFoundException e) {
/*  743 */       sunAvailable = false;
/*  744 */     } catch (NoSuchMethodException e) {
/*  745 */       sunAvailable = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  773 */   public static boolean equals(CharSequence cs1, CharSequence cs2) { return (cs1 == null) ? ((cs2 == null)) : cs1.equals(cs2); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean equalsIgnoreCase(CharSequence str1, CharSequence str2) {
/*  798 */     if (str1 == null || str2 == null) {
/*  799 */       return (str1 == str2);
/*      */     }
/*  801 */     return CharSequenceUtils.regionMatches(str1, true, 0, str2, 0, Math.max(str1.length(), str2.length()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence seq, int searchChar) {
/*  828 */     if (isEmpty(seq)) {
/*  829 */       return -1;
/*      */     }
/*  831 */     return CharSequenceUtils.indexOf(seq, searchChar, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence seq, int searchChar, int startPos) {
/*  861 */     if (isEmpty(seq)) {
/*  862 */       return -1;
/*      */     }
/*  864 */     return CharSequenceUtils.indexOf(seq, searchChar, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence seq, CharSequence searchSeq) {
/*  892 */     if (seq == null || searchSeq == null) {
/*  893 */       return -1;
/*      */     }
/*  895 */     return CharSequenceUtils.indexOf(seq, searchSeq, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOf(CharSequence seq, CharSequence searchSeq, int startPos) {
/*  932 */     if (seq == null || searchSeq == null) {
/*  933 */       return -1;
/*      */     }
/*  935 */     return CharSequenceUtils.indexOf(seq, searchSeq, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  973 */   public static int ordinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal) { return ordinalIndexOf(str, searchStr, ordinal, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int ordinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal, boolean lastIndex) {
/*  991 */     if (str == null || searchStr == null || ordinal <= 0) {
/*  992 */       return -1;
/*      */     }
/*  994 */     if (searchStr.length() == 0) {
/*  995 */       return lastIndex ? str.length() : 0;
/*      */     }
/*  997 */     int found = 0;
/*  998 */     int index = lastIndex ? str.length() : -1;
/*      */     do {
/* 1000 */       if (lastIndex) {
/* 1001 */         index = CharSequenceUtils.lastIndexOf(str, searchStr, index - 1);
/*      */       } else {
/* 1003 */         index = CharSequenceUtils.indexOf(str, searchStr, index + 1);
/*      */       } 
/* 1005 */       if (index < 0) {
/* 1006 */         return index;
/*      */       }
/* 1008 */       ++found;
/* 1009 */     } while (found < ordinal);
/* 1010 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1039 */   public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr) { return indexOfIgnoreCase(str, searchStr, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos) {
/* 1075 */     if (str == null || searchStr == null) {
/* 1076 */       return -1;
/*      */     }
/* 1078 */     if (startPos < 0) {
/* 1079 */       startPos = 0;
/*      */     }
/* 1081 */     int endLimit = str.length() - searchStr.length() + 1;
/* 1082 */     if (startPos > endLimit) {
/* 1083 */       return -1;
/*      */     }
/* 1085 */     if (searchStr.length() == 0) {
/* 1086 */       return startPos;
/*      */     }
/* 1088 */     for (int i = startPos; i < endLimit; i++) {
/* 1089 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, searchStr.length())) {
/* 1090 */         return i;
/*      */       }
/*      */     } 
/* 1093 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(CharSequence seq, int searchChar) {
/* 1119 */     if (isEmpty(seq)) {
/* 1120 */       return -1;
/*      */     }
/* 1122 */     return CharSequenceUtils.lastIndexOf(seq, searchChar, seq.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(CharSequence seq, int searchChar, int startPos) {
/* 1154 */     if (isEmpty(seq)) {
/* 1155 */       return -1;
/*      */     }
/* 1157 */     return CharSequenceUtils.lastIndexOf(seq, searchChar, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(CharSequence seq, CharSequence searchSeq) {
/* 1184 */     if (seq == null || searchSeq == null) {
/* 1185 */       return -1;
/*      */     }
/* 1187 */     return CharSequenceUtils.lastIndexOf(seq, searchSeq, seq.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1225 */   public static int lastOrdinalIndexOf(CharSequence str, CharSequence searchStr, int ordinal) { return ordinalIndexOf(str, searchStr, ordinal, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOf(CharSequence seq, CharSequence searchSeq, int startPos) {
/* 1258 */     if (seq == null || searchSeq == null) {
/* 1259 */       return -1;
/*      */     }
/* 1261 */     return CharSequenceUtils.lastIndexOf(seq, searchSeq, startPos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOfIgnoreCase(CharSequence str, CharSequence searchStr) {
/* 1288 */     if (str == null || searchStr == null) {
/* 1289 */       return -1;
/*      */     }
/* 1291 */     return lastIndexOfIgnoreCase(str, searchStr, str.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOfIgnoreCase(CharSequence str, CharSequence searchStr, int startPos) {
/* 1324 */     if (str == null || searchStr == null) {
/* 1325 */       return -1;
/*      */     }
/* 1327 */     if (startPos > str.length() - searchStr.length()) {
/* 1328 */       startPos = str.length() - searchStr.length();
/*      */     }
/* 1330 */     if (startPos < 0) {
/* 1331 */       return -1;
/*      */     }
/* 1333 */     if (searchStr.length() == 0) {
/* 1334 */       return startPos;
/*      */     }
/*      */     
/* 1337 */     for (int i = startPos; i >= 0; i--) {
/* 1338 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, searchStr.length())) {
/* 1339 */         return i;
/*      */       }
/*      */     } 
/* 1342 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(CharSequence seq, int searchChar) {
/* 1368 */     if (isEmpty(seq)) {
/* 1369 */       return false;
/*      */     }
/* 1371 */     return (CharSequenceUtils.indexOf(seq, searchChar, 0) >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean contains(CharSequence seq, CharSequence searchSeq) {
/* 1397 */     if (seq == null || searchSeq == null) {
/* 1398 */       return false;
/*      */     }
/* 1400 */     return (CharSequenceUtils.indexOf(seq, searchSeq, 0) >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsIgnoreCase(CharSequence str, CharSequence searchStr) {
/* 1428 */     if (str == null || searchStr == null) {
/* 1429 */       return false;
/*      */     }
/* 1431 */     int len = searchStr.length();
/* 1432 */     int max = str.length() - len;
/* 1433 */     for (int i = 0; i <= max; i++) {
/* 1434 */       if (CharSequenceUtils.regionMatches(str, true, i, searchStr, 0, len)) {
/* 1435 */         return true;
/*      */       }
/*      */     } 
/* 1438 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsWhitespace(CharSequence seq) {
/* 1451 */     if (isEmpty(seq)) {
/* 1452 */       return false;
/*      */     }
/* 1454 */     int strLen = seq.length();
/* 1455 */     for (int i = 0; i < strLen; i++) {
/* 1456 */       if (Character.isWhitespace(seq.charAt(i))) {
/* 1457 */         return true;
/*      */       }
/*      */     } 
/* 1460 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(CharSequence cs, char... searchChars) {
/* 1489 */     if (isEmpty(cs) || ArrayUtils.isEmpty(searchChars)) {
/* 1490 */       return -1;
/*      */     }
/* 1492 */     int csLen = cs.length();
/* 1493 */     int csLast = csLen - 1;
/* 1494 */     int searchLen = searchChars.length;
/* 1495 */     int searchLast = searchLen - 1;
/* 1496 */     for (int i = 0; i < csLen; i++) {
/* 1497 */       char ch = cs.charAt(i);
/* 1498 */       for (int j = 0; j < searchLen; j++) {
/* 1499 */         if (searchChars[j] == ch) {
/* 1500 */           if (i < csLast && j < searchLast && Character.isHighSurrogate(ch)) {
/*      */             
/* 1502 */             if (searchChars[j + 1] == cs.charAt(i + 1)) {
/* 1503 */               return i;
/*      */             }
/*      */           } else {
/* 1506 */             return i;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 1511 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(CharSequence cs, String searchChars) {
/* 1538 */     if (isEmpty(cs) || isEmpty(searchChars)) {
/* 1539 */       return -1;
/*      */     }
/* 1541 */     return indexOfAny(cs, searchChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsAny(CharSequence cs, char... searchChars) {
/* 1571 */     if (isEmpty(cs) || ArrayUtils.isEmpty(searchChars)) {
/* 1572 */       return false;
/*      */     }
/* 1574 */     int csLength = cs.length();
/* 1575 */     int searchLength = searchChars.length;
/* 1576 */     int csLast = csLength - 1;
/* 1577 */     int searchLast = searchLength - 1;
/* 1578 */     for (int i = 0; i < csLength; i++) {
/* 1579 */       char ch = cs.charAt(i);
/* 1580 */       for (int j = 0; j < searchLength; j++) {
/* 1581 */         if (searchChars[j] == ch) {
/* 1582 */           if (Character.isHighSurrogate(ch)) {
/* 1583 */             if (j == searchLast)
/*      */             {
/* 1585 */               return true;
/*      */             }
/* 1587 */             if (i < csLast && searchChars[j + 1] == cs.charAt(i + 1)) {
/* 1588 */               return true;
/*      */             }
/*      */           } else {
/*      */             
/* 1592 */             return true;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 1597 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsAny(CharSequence cs, CharSequence searchChars) {
/* 1629 */     if (searchChars == null) {
/* 1630 */       return false;
/*      */     }
/* 1632 */     return containsAny(cs, CharSequenceUtils.toCharArray(searchChars));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAnyBut(CharSequence cs, char... searchChars) {
/* 1662 */     if (isEmpty(cs) || ArrayUtils.isEmpty(searchChars)) {
/* 1663 */       return -1;
/*      */     }
/* 1665 */     int csLen = cs.length();
/* 1666 */     int csLast = csLen - 1;
/* 1667 */     int searchLen = searchChars.length;
/* 1668 */     int searchLast = searchLen - 1;
/*      */     
/* 1670 */     for (int i = 0; i < csLen; i++) {
/* 1671 */       char ch = cs.charAt(i);
/* 1672 */       int j = 0; while (true) { if (j < searchLen) {
/* 1673 */           if (searchChars[j] == ch && (
/* 1674 */             i >= csLast || j >= searchLast || !Character.isHighSurrogate(ch) || 
/* 1675 */             searchChars[j + 1] == cs.charAt(i + 1))) {
/*      */             break;
/*      */           }
/*      */           
/*      */           j++;
/*      */           
/*      */           continue;
/*      */         } 
/* 1683 */         return i; }
/*      */     
/* 1685 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAnyBut(CharSequence seq, CharSequence searchChars) {
/* 1712 */     if (isEmpty(seq) || isEmpty(searchChars)) {
/* 1713 */       return -1;
/*      */     }
/* 1715 */     int strLen = seq.length();
/* 1716 */     for (int i = 0; i < strLen; i++) {
/* 1717 */       char ch = seq.charAt(i);
/* 1718 */       boolean chFound = (CharSequenceUtils.indexOf(searchChars, ch, 0) >= 0);
/* 1719 */       if (i + 1 < strLen && Character.isHighSurrogate(ch)) {
/* 1720 */         char ch2 = seq.charAt(i + 1);
/* 1721 */         if (chFound && CharSequenceUtils.indexOf(searchChars, ch2, 0) < 0) {
/* 1722 */           return i;
/*      */         }
/*      */       }
/* 1725 */       else if (!chFound) {
/* 1726 */         return i;
/*      */       } 
/*      */     } 
/*      */     
/* 1730 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsOnly(CharSequence cs, char... valid) {
/* 1759 */     if (valid == null || cs == null) {
/* 1760 */       return false;
/*      */     }
/* 1762 */     if (cs.length() == 0) {
/* 1763 */       return true;
/*      */     }
/* 1765 */     if (valid.length == 0) {
/* 1766 */       return false;
/*      */     }
/* 1768 */     return (indexOfAnyBut(cs, valid) == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsOnly(CharSequence cs, String validChars) {
/* 1795 */     if (cs == null || validChars == null) {
/* 1796 */       return false;
/*      */     }
/* 1798 */     return containsOnly(cs, validChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsNone(CharSequence cs, char... searchChars) {
/* 1827 */     if (cs == null || searchChars == null) {
/* 1828 */       return true;
/*      */     }
/* 1830 */     int csLen = cs.length();
/* 1831 */     int csLast = csLen - 1;
/* 1832 */     int searchLen = searchChars.length;
/* 1833 */     int searchLast = searchLen - 1;
/* 1834 */     for (int i = 0; i < csLen; i++) {
/* 1835 */       char ch = cs.charAt(i);
/* 1836 */       for (int j = 0; j < searchLen; j++) {
/* 1837 */         if (searchChars[j] == ch) {
/* 1838 */           if (Character.isHighSurrogate(ch)) {
/* 1839 */             if (j == searchLast)
/*      */             {
/* 1841 */               return false;
/*      */             }
/* 1843 */             if (i < csLast && searchChars[j + 1] == cs.charAt(i + 1)) {
/* 1844 */               return false;
/*      */             }
/*      */           } else {
/*      */             
/* 1848 */             return false;
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 1853 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsNone(CharSequence cs, String invalidChars) {
/* 1880 */     if (cs == null || invalidChars == null) {
/* 1881 */       return true;
/*      */     }
/* 1883 */     return containsNone(cs, invalidChars.toCharArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfAny(CharSequence str, CharSequence... searchStrs) {
/* 1916 */     if (str == null || searchStrs == null) {
/* 1917 */       return -1;
/*      */     }
/* 1919 */     int sz = searchStrs.length;
/*      */ 
/*      */     
/* 1922 */     int ret = Integer.MAX_VALUE;
/*      */     
/* 1924 */     int tmp = 0;
/* 1925 */     for (int i = 0; i < sz; i++) {
/* 1926 */       CharSequence search = searchStrs[i];
/* 1927 */       if (search != null) {
/*      */ 
/*      */         
/* 1930 */         tmp = CharSequenceUtils.indexOf(str, search, 0);
/* 1931 */         if (tmp != -1)
/*      */         {
/*      */ 
/*      */           
/* 1935 */           if (tmp < ret)
/* 1936 */             ret = tmp; 
/*      */         }
/*      */       } 
/*      */     } 
/* 1940 */     return (ret == Integer.MAX_VALUE) ? -1 : ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int lastIndexOfAny(CharSequence str, CharSequence... searchStrs) {
/* 1970 */     if (str == null || searchStrs == null) {
/* 1971 */       return -1;
/*      */     }
/* 1973 */     int sz = searchStrs.length;
/* 1974 */     int ret = -1;
/* 1975 */     int tmp = 0;
/* 1976 */     for (int i = 0; i < sz; i++) {
/* 1977 */       CharSequence search = searchStrs[i];
/* 1978 */       if (search != null) {
/*      */ 
/*      */         
/* 1981 */         tmp = CharSequenceUtils.lastIndexOf(str, search, str.length());
/* 1982 */         if (tmp > ret)
/* 1983 */           ret = tmp; 
/*      */       } 
/*      */     } 
/* 1986 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substring(String str, int start) {
/* 2016 */     if (str == null) {
/* 2017 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 2021 */     if (start < 0) {
/* 2022 */       start = str.length() + start;
/*      */     }
/*      */     
/* 2025 */     if (start < 0) {
/* 2026 */       start = 0;
/*      */     }
/* 2028 */     if (start > str.length()) {
/* 2029 */       return "";
/*      */     }
/*      */     
/* 2032 */     return str.substring(start);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substring(String str, int start, int end) {
/* 2071 */     if (str == null) {
/* 2072 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 2076 */     if (end < 0) {
/* 2077 */       end = str.length() + end;
/*      */     }
/* 2079 */     if (start < 0) {
/* 2080 */       start = str.length() + start;
/*      */     }
/*      */ 
/*      */     
/* 2084 */     if (end > str.length()) {
/* 2085 */       end = str.length();
/*      */     }
/*      */ 
/*      */     
/* 2089 */     if (start > end) {
/* 2090 */       return "";
/*      */     }
/*      */     
/* 2093 */     if (start < 0) {
/* 2094 */       start = 0;
/*      */     }
/* 2096 */     if (end < 0) {
/* 2097 */       end = 0;
/*      */     }
/*      */     
/* 2100 */     return str.substring(start, end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String left(String str, int len) {
/* 2126 */     if (str == null) {
/* 2127 */       return null;
/*      */     }
/* 2129 */     if (len < 0) {
/* 2130 */       return "";
/*      */     }
/* 2132 */     if (str.length() <= len) {
/* 2133 */       return str;
/*      */     }
/* 2135 */     return str.substring(0, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String right(String str, int len) {
/* 2159 */     if (str == null) {
/* 2160 */       return null;
/*      */     }
/* 2162 */     if (len < 0) {
/* 2163 */       return "";
/*      */     }
/* 2165 */     if (str.length() <= len) {
/* 2166 */       return str;
/*      */     }
/* 2168 */     return str.substring(str.length() - len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String mid(String str, int pos, int len) {
/* 2197 */     if (str == null) {
/* 2198 */       return null;
/*      */     }
/* 2200 */     if (len < 0 || pos > str.length()) {
/* 2201 */       return "";
/*      */     }
/* 2203 */     if (pos < 0) {
/* 2204 */       pos = 0;
/*      */     }
/* 2206 */     if (str.length() <= pos + len) {
/* 2207 */       return str.substring(pos);
/*      */     }
/* 2209 */     return str.substring(pos, pos + len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBefore(String str, String separator) {
/* 2242 */     if (isEmpty(str) || separator == null) {
/* 2243 */       return str;
/*      */     }
/* 2245 */     if (separator.length() == 0) {
/* 2246 */       return "";
/*      */     }
/* 2248 */     int pos = str.indexOf(separator);
/* 2249 */     if (pos == -1) {
/* 2250 */       return str;
/*      */     }
/* 2252 */     return str.substring(0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringAfter(String str, String separator) {
/* 2284 */     if (isEmpty(str)) {
/* 2285 */       return str;
/*      */     }
/* 2287 */     if (separator == null) {
/* 2288 */       return "";
/*      */     }
/* 2290 */     int pos = str.indexOf(separator);
/* 2291 */     if (pos == -1) {
/* 2292 */       return "";
/*      */     }
/* 2294 */     return str.substring(pos + separator.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBeforeLast(String str, String separator) {
/* 2325 */     if (isEmpty(str) || isEmpty(separator)) {
/* 2326 */       return str;
/*      */     }
/* 2328 */     int pos = str.lastIndexOf(separator);
/* 2329 */     if (pos == -1) {
/* 2330 */       return str;
/*      */     }
/* 2332 */     return str.substring(0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringAfterLast(String str, String separator) {
/* 2365 */     if (isEmpty(str)) {
/* 2366 */       return str;
/*      */     }
/* 2368 */     if (isEmpty(separator)) {
/* 2369 */       return "";
/*      */     }
/* 2371 */     int pos = str.lastIndexOf(separator);
/* 2372 */     if (pos == -1 || pos == str.length() - separator.length()) {
/* 2373 */       return "";
/*      */     }
/* 2375 */     return str.substring(pos + separator.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2402 */   public static String substringBetween(String str, String tag) { return substringBetween(str, tag, tag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBetween(String str, String open, String close) {
/* 2433 */     if (str == null || open == null || close == null) {
/* 2434 */       return null;
/*      */     }
/* 2436 */     int start = str.indexOf(open);
/* 2437 */     if (start != -1) {
/* 2438 */       int end = str.indexOf(close, start + open.length());
/* 2439 */       if (end != -1) {
/* 2440 */         return str.substring(start + open.length(), end);
/*      */       }
/*      */     } 
/* 2443 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] substringsBetween(String str, String open, String close) {
/* 2469 */     if (str == null || isEmpty(open) || isEmpty(close)) {
/* 2470 */       return null;
/*      */     }
/* 2472 */     int strLen = str.length();
/* 2473 */     if (strLen == 0) {
/* 2474 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2476 */     int closeLen = close.length();
/* 2477 */     int openLen = open.length();
/* 2478 */     List<String> list = new ArrayList<String>();
/* 2479 */     int pos = 0;
/* 2480 */     while (pos < strLen - closeLen) {
/* 2481 */       int start = str.indexOf(open, pos);
/* 2482 */       if (start < 0) {
/*      */         break;
/*      */       }
/* 2485 */       start += openLen;
/* 2486 */       int end = str.indexOf(close, start);
/* 2487 */       if (end < 0) {
/*      */         break;
/*      */       }
/* 2490 */       list.add(str.substring(start, end));
/* 2491 */       pos = end + closeLen;
/*      */     } 
/* 2493 */     if (list.isEmpty()) {
/* 2494 */       return null;
/*      */     }
/* 2496 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2527 */   public static String[] split(String str) { return split(str, null, -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2555 */   public static String[] split(String str, char separatorChar) { return splitWorker(str, separatorChar, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2584 */   public static String[] split(String str, String separatorChars) { return splitWorker(str, separatorChars, -1, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2618 */   public static String[] split(String str, String separatorChars, int max) { return splitWorker(str, separatorChars, max, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2645 */   public static String[] splitByWholeSeparator(String str, String separator) { return splitByWholeSeparatorWorker(str, separator, -1, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2676 */   public static String[] splitByWholeSeparator(String str, String separator, int max) { return splitByWholeSeparatorWorker(str, separator, max, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2705 */   public static String[] splitByWholeSeparatorPreserveAllTokens(String str, String separator) { return splitByWholeSeparatorWorker(str, separator, -1, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2738 */   public static String[] splitByWholeSeparatorPreserveAllTokens(String str, String separator, int max) { return splitByWholeSeparatorWorker(str, separator, max, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitByWholeSeparatorWorker(String str, String separator, int max, boolean preserveAllTokens) {
/* 2757 */     if (str == null) {
/* 2758 */       return null;
/*      */     }
/*      */     
/* 2761 */     int len = str.length();
/*      */     
/* 2763 */     if (len == 0) {
/* 2764 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/*      */     
/* 2767 */     if (separator == null || "".equals(separator))
/*      */     {
/* 2769 */       return splitWorker(str, null, max, preserveAllTokens);
/*      */     }
/*      */     
/* 2772 */     int separatorLength = separator.length();
/*      */     
/* 2774 */     ArrayList<String> substrings = new ArrayList<String>();
/* 2775 */     int numberOfSubstrings = 0;
/* 2776 */     int beg = 0;
/* 2777 */     int end = 0;
/* 2778 */     while (end < len) {
/* 2779 */       end = str.indexOf(separator, beg);
/*      */       
/* 2781 */       if (end > -1) {
/* 2782 */         if (end > beg) {
/* 2783 */           numberOfSubstrings++;
/*      */           
/* 2785 */           if (numberOfSubstrings == max) {
/* 2786 */             end = len;
/* 2787 */             substrings.add(str.substring(beg));
/*      */             
/*      */             continue;
/*      */           } 
/* 2791 */           substrings.add(str.substring(beg, end));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2796 */           beg = end + separatorLength;
/*      */           
/*      */           continue;
/*      */         } 
/* 2800 */         if (preserveAllTokens) {
/* 2801 */           numberOfSubstrings++;
/* 2802 */           if (numberOfSubstrings == max) {
/* 2803 */             end = len;
/* 2804 */             substrings.add(str.substring(beg));
/*      */           } else {
/* 2806 */             substrings.add("");
/*      */           } 
/*      */         } 
/* 2809 */         beg = end + separatorLength;
/*      */         
/*      */         continue;
/*      */       } 
/* 2813 */       substrings.add(str.substring(beg));
/* 2814 */       end = len;
/*      */     } 
/*      */ 
/*      */     
/* 2818 */     return (String[])substrings.toArray(new String[substrings.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2847 */   public static String[] splitPreserveAllTokens(String str) { return splitWorker(str, null, -1, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2883 */   public static String[] splitPreserveAllTokens(String str, char separatorChar) { return splitWorker(str, separatorChar, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitWorker(String str, char separatorChar, boolean preserveAllTokens) {
/* 2901 */     if (str == null) {
/* 2902 */       return null;
/*      */     }
/* 2904 */     int len = str.length();
/* 2905 */     if (len == 0) {
/* 2906 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 2908 */     List<String> list = new ArrayList<String>();
/* 2909 */     int i = 0, start = 0;
/* 2910 */     boolean match = false;
/* 2911 */     boolean lastMatch = false;
/* 2912 */     while (i < len) {
/* 2913 */       if (str.charAt(i) == separatorChar) {
/* 2914 */         if (match || preserveAllTokens) {
/* 2915 */           list.add(str.substring(start, i));
/* 2916 */           match = false;
/* 2917 */           lastMatch = true;
/*      */         } 
/* 2919 */         start = ++i;
/*      */         continue;
/*      */       } 
/* 2922 */       lastMatch = false;
/* 2923 */       match = true;
/* 2924 */       i++;
/*      */     } 
/* 2926 */     if (match || (preserveAllTokens && lastMatch)) {
/* 2927 */       list.add(str.substring(start, i));
/*      */     }
/* 2929 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2966 */   public static String[] splitPreserveAllTokens(String str, String separatorChars) { return splitWorker(str, separatorChars, -1, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3006 */   public static String[] splitPreserveAllTokens(String str, String separatorChars, int max) { return splitWorker(str, separatorChars, max, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitWorker(String str, String separatorChars, int max, boolean preserveAllTokens) {
/* 3028 */     if (str == null) {
/* 3029 */       return null;
/*      */     }
/* 3031 */     int len = str.length();
/* 3032 */     if (len == 0) {
/* 3033 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 3035 */     List<String> list = new ArrayList<String>();
/* 3036 */     int sizePlus1 = 1;
/* 3037 */     int i = 0, start = 0;
/* 3038 */     boolean match = false;
/* 3039 */     boolean lastMatch = false;
/* 3040 */     if (separatorChars == null) {
/*      */       
/* 3042 */       while (i < len) {
/* 3043 */         if (Character.isWhitespace(str.charAt(i))) {
/* 3044 */           if (match || preserveAllTokens) {
/* 3045 */             lastMatch = true;
/* 3046 */             if (sizePlus1++ == max) {
/* 3047 */               i = len;
/* 3048 */               lastMatch = false;
/*      */             } 
/* 3050 */             list.add(str.substring(start, i));
/* 3051 */             match = false;
/*      */           } 
/* 3053 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 3056 */         lastMatch = false;
/* 3057 */         match = true;
/* 3058 */         i++;
/*      */       } 
/* 3060 */     } else if (separatorChars.length() == 1) {
/*      */       
/* 3062 */       char sep = separatorChars.charAt(0);
/* 3063 */       while (i < len) {
/* 3064 */         if (str.charAt(i) == sep) {
/* 3065 */           if (match || preserveAllTokens) {
/* 3066 */             lastMatch = true;
/* 3067 */             if (sizePlus1++ == max) {
/* 3068 */               i = len;
/* 3069 */               lastMatch = false;
/*      */             } 
/* 3071 */             list.add(str.substring(start, i));
/* 3072 */             match = false;
/*      */           } 
/* 3074 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 3077 */         lastMatch = false;
/* 3078 */         match = true;
/* 3079 */         i++;
/*      */       } 
/*      */     } else {
/*      */       
/* 3083 */       while (i < len) {
/* 3084 */         if (separatorChars.indexOf(str.charAt(i)) >= 0) {
/* 3085 */           if (match || preserveAllTokens) {
/* 3086 */             lastMatch = true;
/* 3087 */             if (sizePlus1++ == max) {
/* 3088 */               i = len;
/* 3089 */               lastMatch = false;
/*      */             } 
/* 3091 */             list.add(str.substring(start, i));
/* 3092 */             match = false;
/*      */           } 
/* 3094 */           start = ++i;
/*      */           continue;
/*      */         } 
/* 3097 */         lastMatch = false;
/* 3098 */         match = true;
/* 3099 */         i++;
/*      */       } 
/*      */     } 
/* 3102 */     if (match || (preserveAllTokens && lastMatch)) {
/* 3103 */       list.add(str.substring(start, i));
/*      */     }
/* 3105 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3128 */   public static String[] splitByCharacterType(String str) { return splitByCharacterType(str, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3156 */   public static String[] splitByCharacterTypeCamelCase(String str) { return splitByCharacterType(str, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] splitByCharacterType(String str, boolean camelCase) {
/* 3174 */     if (str == null) {
/* 3175 */       return null;
/*      */     }
/* 3177 */     if (str.length() == 0) {
/* 3178 */       return ArrayUtils.EMPTY_STRING_ARRAY;
/*      */     }
/* 3180 */     char[] c = str.toCharArray();
/* 3181 */     List<String> list = new ArrayList<String>();
/* 3182 */     int tokenStart = 0;
/* 3183 */     int currentType = Character.getType(c[tokenStart]);
/* 3184 */     for (int pos = tokenStart + 1; pos < c.length; pos++) {
/* 3185 */       int type = Character.getType(c[pos]);
/* 3186 */       if (type != currentType) {
/*      */ 
/*      */         
/* 3189 */         if (camelCase && type == 2 && currentType == 1) {
/* 3190 */           int newTokenStart = pos - 1;
/* 3191 */           if (newTokenStart != tokenStart) {
/* 3192 */             list.add(new String(c, tokenStart, newTokenStart - tokenStart));
/* 3193 */             tokenStart = newTokenStart;
/*      */           } 
/*      */         } else {
/* 3196 */           list.add(new String(c, tokenStart, pos - tokenStart));
/* 3197 */           tokenStart = pos;
/*      */         } 
/* 3199 */         currentType = type;
/*      */       } 
/* 3201 */     }  list.add(new String(c, tokenStart, c.length - tokenStart));
/* 3202 */     return (String[])list.toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3230 */   public static <T> String join(T... elements) { return join(elements, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, char separator) {
/* 3256 */     if (array == null) {
/* 3257 */       return null;
/*      */     }
/*      */     
/* 3260 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, char separator, int startIndex, int endIndex) {
/* 3290 */     if (array == null) {
/* 3291 */       return null;
/*      */     }
/* 3293 */     int noOfItems = endIndex - startIndex;
/* 3294 */     if (noOfItems <= 0) {
/* 3295 */       return "";
/*      */     }
/*      */     
/* 3298 */     StringBuilder buf = new StringBuilder(noOfItems * 16);
/*      */     
/* 3300 */     for (int i = startIndex; i < endIndex; i++) {
/* 3301 */       if (i > startIndex) {
/* 3302 */         buf.append(separator);
/*      */       }
/* 3304 */       if (array[i] != null) {
/* 3305 */         buf.append(array[i]);
/*      */       }
/*      */     } 
/* 3308 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, String separator) {
/* 3335 */     if (array == null) {
/* 3336 */       return null;
/*      */     }
/* 3338 */     return join(array, separator, 0, array.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Object[] array, String separator, int startIndex, int endIndex) {
/* 3369 */     if (array == null) {
/* 3370 */       return null;
/*      */     }
/* 3372 */     if (separator == null) {
/* 3373 */       separator = "";
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3378 */     int noOfItems = endIndex - startIndex;
/* 3379 */     if (noOfItems <= 0) {
/* 3380 */       return "";
/*      */     }
/*      */     
/* 3383 */     StringBuilder buf = new StringBuilder(noOfItems * 16);
/*      */     
/* 3385 */     for (int i = startIndex; i < endIndex; i++) {
/* 3386 */       if (i > startIndex) {
/* 3387 */         buf.append(separator);
/*      */       }
/* 3389 */       if (array[i] != null) {
/* 3390 */         buf.append(array[i]);
/*      */       }
/*      */     } 
/* 3393 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterator<?> iterator, char separator) {
/* 3413 */     if (iterator == null) {
/* 3414 */       return null;
/*      */     }
/* 3416 */     if (!iterator.hasNext()) {
/* 3417 */       return "";
/*      */     }
/* 3419 */     Object first = iterator.next();
/* 3420 */     if (!iterator.hasNext()) {
/* 3421 */       return ObjectUtils.toString(first);
/*      */     }
/*      */ 
/*      */     
/* 3425 */     StringBuilder buf = new StringBuilder(256);
/* 3426 */     if (first != null) {
/* 3427 */       buf.append(first);
/*      */     }
/*      */     
/* 3430 */     while (iterator.hasNext()) {
/* 3431 */       buf.append(separator);
/* 3432 */       Object obj = iterator.next();
/* 3433 */       if (obj != null) {
/* 3434 */         buf.append(obj);
/*      */       }
/*      */     } 
/*      */     
/* 3438 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterator<?> iterator, String separator) {
/* 3457 */     if (iterator == null) {
/* 3458 */       return null;
/*      */     }
/* 3460 */     if (!iterator.hasNext()) {
/* 3461 */       return "";
/*      */     }
/* 3463 */     Object first = iterator.next();
/* 3464 */     if (!iterator.hasNext()) {
/* 3465 */       return ObjectUtils.toString(first);
/*      */     }
/*      */ 
/*      */     
/* 3469 */     StringBuilder buf = new StringBuilder(256);
/* 3470 */     if (first != null) {
/* 3471 */       buf.append(first);
/*      */     }
/*      */     
/* 3474 */     while (iterator.hasNext()) {
/* 3475 */       if (separator != null) {
/* 3476 */         buf.append(separator);
/*      */       }
/* 3478 */       Object obj = iterator.next();
/* 3479 */       if (obj != null) {
/* 3480 */         buf.append(obj);
/*      */       }
/*      */     } 
/* 3483 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterable<?> iterable, char separator) {
/* 3501 */     if (iterable == null) {
/* 3502 */       return null;
/*      */     }
/* 3504 */     return join(iterable.iterator(), separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(Iterable<?> iterable, String separator) {
/* 3522 */     if (iterable == null) {
/* 3523 */       return null;
/*      */     }
/* 3525 */     return join(iterable.iterator(), separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String deleteWhitespace(String str) {
/* 3545 */     if (isEmpty(str)) {
/* 3546 */       return str;
/*      */     }
/* 3548 */     int sz = str.length();
/* 3549 */     char[] chs = new char[sz];
/* 3550 */     int count = 0;
/* 3551 */     for (int i = 0; i < sz; i++) {
/* 3552 */       if (!Character.isWhitespace(str.charAt(i))) {
/* 3553 */         chs[count++] = str.charAt(i);
/*      */       }
/*      */     } 
/* 3556 */     if (count == sz) {
/* 3557 */       return str;
/*      */     }
/* 3559 */     return new String(chs, 0, count);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeStart(String str, String remove) {
/* 3589 */     if (isEmpty(str) || isEmpty(remove)) {
/* 3590 */       return str;
/*      */     }
/* 3592 */     if (str.startsWith(remove)) {
/* 3593 */       return str.substring(remove.length());
/*      */     }
/* 3595 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeStartIgnoreCase(String str, String remove) {
/* 3624 */     if (isEmpty(str) || isEmpty(remove)) {
/* 3625 */       return str;
/*      */     }
/* 3627 */     if (startsWithIgnoreCase(str, remove)) {
/* 3628 */       return str.substring(remove.length());
/*      */     }
/* 3630 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeEnd(String str, String remove) {
/* 3658 */     if (isEmpty(str) || isEmpty(remove)) {
/* 3659 */       return str;
/*      */     }
/* 3661 */     if (str.endsWith(remove)) {
/* 3662 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 3664 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String removeEndIgnoreCase(String str, String remove) {
/* 3694 */     if (isEmpty(str) || isEmpty(remove)) {
/* 3695 */       return str;
/*      */     }
/* 3697 */     if (endsWithIgnoreCase(str, remove)) {
/* 3698 */       return str.substring(0, str.length() - remove.length());
/*      */     }
/* 3700 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String remove(String str, String remove) {
/* 3727 */     if (isEmpty(str) || isEmpty(remove)) {
/* 3728 */       return str;
/*      */     }
/* 3730 */     return replace(str, remove, "", -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String remove(String str, char remove) {
/* 3753 */     if (isEmpty(str) || str.indexOf(remove) == -1) {
/* 3754 */       return str;
/*      */     }
/* 3756 */     char[] chars = str.toCharArray();
/* 3757 */     int pos = 0;
/* 3758 */     for (int i = 0; i < chars.length; i++) {
/* 3759 */       if (chars[i] != remove) {
/* 3760 */         chars[pos++] = chars[i];
/*      */       }
/*      */     } 
/* 3763 */     return new String(chars, 0, pos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3792 */   public static String replaceOnce(String text, String searchString, String replacement) { return replace(text, searchString, replacement, 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3819 */   public static String replace(String text, String searchString, String replacement) { return replace(text, searchString, replacement, -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replace(String text, String searchString, String replacement, int max) {
/* 3851 */     if (isEmpty(text) || isEmpty(searchString) || replacement == null || max == 0) {
/* 3852 */       return text;
/*      */     }
/* 3854 */     int start = 0;
/* 3855 */     int end = text.indexOf(searchString, start);
/* 3856 */     if (end == -1) {
/* 3857 */       return text;
/*      */     }
/* 3859 */     int replLength = searchString.length();
/* 3860 */     int increase = replacement.length() - replLength;
/* 3861 */     increase = (increase < 0) ? 0 : increase;
/* 3862 */     increase *= ((max < 0) ? 16 : ((max > 64) ? 64 : max));
/* 3863 */     StringBuilder buf = new StringBuilder(text.length() + increase);
/* 3864 */     while (end != -1) {
/* 3865 */       buf.append(text.substring(start, end)).append(replacement);
/* 3866 */       start = end + replLength;
/* 3867 */       if (--max == 0) {
/*      */         break;
/*      */       }
/* 3870 */       end = text.indexOf(searchString, start);
/*      */     } 
/* 3872 */     buf.append(text.substring(start));
/* 3873 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3916 */   public static String replaceEach(String text, String[] searchList, String[] replacementList) { return replaceEach(text, searchList, replacementList, false, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceEachRepeatedly(String text, String[] searchList, String[] replacementList) {
/* 3967 */     int timeToLive = (searchList == null) ? 0 : searchList.length;
/* 3968 */     return replaceEach(text, searchList, replacementList, true, timeToLive);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String replaceEach(String text, String[] searchList, String[] replacementList, boolean repeat, int timeToLive) {
/* 4025 */     if (text == null || text.length() == 0 || searchList == null || searchList.length == 0 || replacementList == null || replacementList.length == 0)
/*      */     {
/* 4027 */       return text;
/*      */     }
/*      */ 
/*      */     
/* 4031 */     if (timeToLive < 0) {
/* 4032 */       throw new IllegalStateException("TimeToLive of " + timeToLive + " is less than 0: " + text);
/*      */     }
/*      */     
/* 4035 */     int searchLength = searchList.length;
/* 4036 */     int replacementLength = replacementList.length;
/*      */ 
/*      */     
/* 4039 */     if (searchLength != replacementLength) {
/* 4040 */       throw new IllegalArgumentException("Search and Replace array lengths don't match: " + searchLength + " vs " + replacementLength);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4047 */     boolean[] noMoreMatchesForReplIndex = new boolean[searchLength];
/*      */ 
/*      */     
/* 4050 */     int textIndex = -1;
/* 4051 */     int replaceIndex = -1;
/* 4052 */     int tempIndex = -1;
/*      */ 
/*      */ 
/*      */     
/* 4056 */     for (int i = 0; i < searchLength; i++) {
/* 4057 */       if (!noMoreMatchesForReplIndex[i] && searchList[i] != null && searchList[i].length() != 0 && replacementList[i] != null) {
/*      */ 
/*      */ 
/*      */         
/* 4061 */         tempIndex = text.indexOf(searchList[i]);
/*      */ 
/*      */         
/* 4064 */         if (tempIndex == -1) {
/* 4065 */           noMoreMatchesForReplIndex[i] = true;
/*      */         }
/* 4067 */         else if (textIndex == -1 || tempIndex < textIndex) {
/* 4068 */           textIndex = tempIndex;
/* 4069 */           replaceIndex = i;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4076 */     if (textIndex == -1) {
/* 4077 */       return text;
/*      */     }
/*      */     
/* 4080 */     int start = 0;
/*      */ 
/*      */     
/* 4083 */     int increase = 0;
/*      */ 
/*      */     
/* 4086 */     for (int i = 0; i < searchList.length; i++) {
/* 4087 */       if (searchList[i] != null && replacementList[i] != null) {
/*      */ 
/*      */         
/* 4090 */         int greater = replacementList[i].length() - searchList[i].length();
/* 4091 */         if (greater > 0) {
/* 4092 */           increase += 3 * greater;
/*      */         }
/*      */       } 
/*      */     } 
/* 4096 */     increase = Math.min(increase, text.length() / 5);
/*      */     
/* 4098 */     StringBuilder buf = new StringBuilder(text.length() + increase);
/*      */     
/* 4100 */     while (textIndex != -1) {
/*      */       
/* 4102 */       for (int i = start; i < textIndex; i++) {
/* 4103 */         buf.append(text.charAt(i));
/*      */       }
/* 4105 */       buf.append(replacementList[replaceIndex]);
/*      */       
/* 4107 */       start = textIndex + searchList[replaceIndex].length();
/*      */       
/* 4109 */       textIndex = -1;
/* 4110 */       replaceIndex = -1;
/* 4111 */       tempIndex = -1;
/*      */ 
/*      */       
/* 4114 */       for (int i = 0; i < searchLength; i++) {
/* 4115 */         if (!noMoreMatchesForReplIndex[i] && searchList[i] != null && searchList[i].length() != 0 && replacementList[i] != null) {
/*      */ 
/*      */ 
/*      */           
/* 4119 */           tempIndex = text.indexOf(searchList[i], start);
/*      */ 
/*      */           
/* 4122 */           if (tempIndex == -1) {
/* 4123 */             noMoreMatchesForReplIndex[i] = true;
/*      */           }
/* 4125 */           else if (textIndex == -1 || tempIndex < textIndex) {
/* 4126 */             textIndex = tempIndex;
/* 4127 */             replaceIndex = i;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 4134 */     int textLength = text.length();
/* 4135 */     for (int i = start; i < textLength; i++) {
/* 4136 */       buf.append(text.charAt(i));
/*      */     }
/* 4138 */     String result = buf.toString();
/* 4139 */     if (!repeat) {
/* 4140 */       return result;
/*      */     }
/*      */     
/* 4143 */     return replaceEach(result, searchList, replacementList, repeat, timeToLive - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceChars(String str, char searchChar, char replaceChar) {
/* 4169 */     if (str == null) {
/* 4170 */       return null;
/*      */     }
/* 4172 */     return str.replace(searchChar, replaceChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String replaceChars(String str, String searchChars, String replaceChars) {
/* 4212 */     if (isEmpty(str) || isEmpty(searchChars)) {
/* 4213 */       return str;
/*      */     }
/* 4215 */     if (replaceChars == null) {
/* 4216 */       replaceChars = "";
/*      */     }
/* 4218 */     boolean modified = false;
/* 4219 */     int replaceCharsLength = replaceChars.length();
/* 4220 */     int strLength = str.length();
/* 4221 */     StringBuilder buf = new StringBuilder(strLength);
/* 4222 */     for (int i = 0; i < strLength; i++) {
/* 4223 */       char ch = str.charAt(i);
/* 4224 */       int index = searchChars.indexOf(ch);
/* 4225 */       if (index >= 0) {
/* 4226 */         modified = true;
/* 4227 */         if (index < replaceCharsLength) {
/* 4228 */           buf.append(replaceChars.charAt(index));
/*      */         }
/*      */       } else {
/* 4231 */         buf.append(ch);
/*      */       } 
/*      */     } 
/* 4234 */     if (modified) {
/* 4235 */       return buf.toString();
/*      */     }
/* 4237 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String overlay(String str, String overlay, int start, int end) {
/* 4272 */     if (str == null) {
/* 4273 */       return null;
/*      */     }
/* 4275 */     if (overlay == null) {
/* 4276 */       overlay = "";
/*      */     }
/* 4278 */     int len = str.length();
/* 4279 */     if (start < 0) {
/* 4280 */       start = 0;
/*      */     }
/* 4282 */     if (start > len) {
/* 4283 */       start = len;
/*      */     }
/* 4285 */     if (end < 0) {
/* 4286 */       end = 0;
/*      */     }
/* 4288 */     if (end > len) {
/* 4289 */       end = len;
/*      */     }
/* 4291 */     if (start > end) {
/* 4292 */       int temp = start;
/* 4293 */       start = end;
/* 4294 */       end = temp;
/*      */     } 
/* 4296 */     return (len + start - end + overlay.length() + 1).toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chomp(String str) {
/* 4331 */     if (isEmpty(str)) {
/* 4332 */       return str;
/*      */     }
/*      */     
/* 4335 */     if (str.length() == 1) {
/* 4336 */       char ch = str.charAt(0);
/* 4337 */       if (ch == '\r' || ch == '\n') {
/* 4338 */         return "";
/*      */       }
/* 4340 */       return str;
/*      */     } 
/*      */     
/* 4343 */     int lastIdx = str.length() - 1;
/* 4344 */     char last = str.charAt(lastIdx);
/*      */     
/* 4346 */     if (last == '\n') {
/* 4347 */       if (str.charAt(lastIdx - 1) == '\r') {
/* 4348 */         lastIdx--;
/*      */       }
/* 4350 */     } else if (last != '\r') {
/* 4351 */       lastIdx++;
/*      */     } 
/* 4353 */     return str.substring(0, lastIdx);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chomp(String str, String separator) {
/* 4383 */     if (isEmpty(str) || separator == null) {
/* 4384 */       return str;
/*      */     }
/* 4386 */     if (str.endsWith(separator)) {
/* 4387 */       return str.substring(0, str.length() - separator.length());
/*      */     }
/* 4389 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String chop(String str) {
/* 4418 */     if (str == null) {
/* 4419 */       return null;
/*      */     }
/* 4421 */     int strLen = str.length();
/* 4422 */     if (strLen < 2) {
/* 4423 */       return "";
/*      */     }
/* 4425 */     int lastIdx = strLen - 1;
/* 4426 */     String ret = str.substring(0, lastIdx);
/* 4427 */     char last = str.charAt(lastIdx);
/* 4428 */     if (last == '\n' && 
/* 4429 */       ret.charAt(lastIdx - 1) == '\r') {
/* 4430 */       return ret.substring(0, lastIdx - 1);
/*      */     }
/*      */     
/* 4433 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String repeat(String str, int repeat) {
/*      */     int i;
/*      */     char output2[], ch1, ch0;
/* 4462 */     if (str == null) {
/* 4463 */       return null;
/*      */     }
/* 4465 */     if (repeat <= 0) {
/* 4466 */       return "";
/*      */     }
/* 4468 */     int inputLength = str.length();
/* 4469 */     if (repeat == 1 || inputLength == 0) {
/* 4470 */       return str;
/*      */     }
/* 4472 */     if (inputLength == 1 && repeat <= 8192) {
/* 4473 */       return repeat(str.charAt(0), repeat);
/*      */     }
/*      */     
/* 4476 */     int outputLength = inputLength * repeat;
/* 4477 */     switch (inputLength) {
/*      */       case 1:
/* 4479 */         return repeat(str.charAt(0), repeat);
/*      */       case 2:
/* 4481 */         ch0 = str.charAt(0);
/* 4482 */         ch1 = str.charAt(1);
/* 4483 */         output2 = new char[outputLength];
/* 4484 */         for (i = repeat * 2 - 2; i >= 0; i--, i--) {
/* 4485 */           output2[i] = ch0;
/* 4486 */           output2[i + 1] = ch1;
/*      */         } 
/* 4488 */         return new String(output2);
/*      */     } 
/* 4490 */     StringBuilder buf = new StringBuilder(outputLength);
/* 4491 */     for (int i = 0; i < repeat; i++) {
/* 4492 */       buf.append(str);
/*      */     }
/* 4494 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String repeat(String str, String separator, int repeat) {
/* 4519 */     if (str == null || separator == null) {
/* 4520 */       return repeat(str, repeat);
/*      */     }
/*      */     
/* 4523 */     String result = repeat(str + separator, repeat);
/* 4524 */     return removeEnd(result, separator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String repeat(char ch, int repeat) {
/* 4551 */     char[] buf = new char[repeat];
/* 4552 */     for (int i = repeat - 1; i >= 0; i--) {
/* 4553 */       buf[i] = ch;
/*      */     }
/* 4555 */     return new String(buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4578 */   public static String rightPad(String str, int size) { return rightPad(str, size, ' '); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size, char padChar) {
/* 4603 */     if (str == null) {
/* 4604 */       return null;
/*      */     }
/* 4606 */     int pads = size - str.length();
/* 4607 */     if (pads <= 0) {
/* 4608 */       return str;
/*      */     }
/* 4610 */     if (pads > 8192) {
/* 4611 */       return rightPad(str, size, String.valueOf(padChar));
/*      */     }
/* 4613 */     return str.concat(repeat(padChar, pads));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size, String padStr) {
/* 4640 */     if (str == null) {
/* 4641 */       return null;
/*      */     }
/* 4643 */     if (isEmpty(padStr)) {
/* 4644 */       padStr = " ";
/*      */     }
/* 4646 */     int padLen = padStr.length();
/* 4647 */     int strLen = str.length();
/* 4648 */     int pads = size - strLen;
/* 4649 */     if (pads <= 0) {
/* 4650 */       return str;
/*      */     }
/* 4652 */     if (padLen == 1 && pads <= 8192) {
/* 4653 */       return rightPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 4656 */     if (pads == padLen)
/* 4657 */       return str.concat(padStr); 
/* 4658 */     if (pads < padLen) {
/* 4659 */       return str.concat(padStr.substring(0, pads));
/*      */     }
/* 4661 */     char[] padding = new char[pads];
/* 4662 */     char[] padChars = padStr.toCharArray();
/* 4663 */     for (int i = 0; i < pads; i++) {
/* 4664 */       padding[i] = padChars[i % padLen];
/*      */     }
/* 4666 */     return str.concat(new String(padding));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4690 */   public static String leftPad(String str, int size) { return leftPad(str, size, ' '); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String leftPad(String str, int size, char padChar) {
/* 4715 */     if (str == null) {
/* 4716 */       return null;
/*      */     }
/* 4718 */     int pads = size - str.length();
/* 4719 */     if (pads <= 0) {
/* 4720 */       return str;
/*      */     }
/* 4722 */     if (pads > 8192) {
/* 4723 */       return leftPad(str, size, String.valueOf(padChar));
/*      */     }
/* 4725 */     return repeat(padChar, pads).concat(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String leftPad(String str, int size, String padStr) {
/* 4752 */     if (str == null) {
/* 4753 */       return null;
/*      */     }
/* 4755 */     if (isEmpty(padStr)) {
/* 4756 */       padStr = " ";
/*      */     }
/* 4758 */     int padLen = padStr.length();
/* 4759 */     int strLen = str.length();
/* 4760 */     int pads = size - strLen;
/* 4761 */     if (pads <= 0) {
/* 4762 */       return str;
/*      */     }
/* 4764 */     if (padLen == 1 && pads <= 8192) {
/* 4765 */       return leftPad(str, size, padStr.charAt(0));
/*      */     }
/*      */     
/* 4768 */     if (pads == padLen)
/* 4769 */       return padStr.concat(str); 
/* 4770 */     if (pads < padLen) {
/* 4771 */       return padStr.substring(0, pads).concat(str);
/*      */     }
/* 4773 */     char[] padding = new char[pads];
/* 4774 */     char[] padChars = padStr.toCharArray();
/* 4775 */     for (int i = 0; i < pads; i++) {
/* 4776 */       padding[i] = padChars[i % padLen];
/*      */     }
/* 4778 */     return (new String(padding)).concat(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4794 */   public static int length(CharSequence cs) { return (cs == null) ? 0 : cs.length(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4823 */   public static String center(String str, int size) { return center(str, size, ' '); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String center(String str, int size, char padChar) {
/* 4851 */     if (str == null || size <= 0) {
/* 4852 */       return str;
/*      */     }
/* 4854 */     int strLen = str.length();
/* 4855 */     int pads = size - strLen;
/* 4856 */     if (pads <= 0) {
/* 4857 */       return str;
/*      */     }
/* 4859 */     str = leftPad(str, strLen + pads / 2, padChar);
/* 4860 */     return rightPad(str, size, padChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String center(String str, int size, String padStr) {
/* 4891 */     if (str == null || size <= 0) {
/* 4892 */       return str;
/*      */     }
/* 4894 */     if (isEmpty(padStr)) {
/* 4895 */       padStr = " ";
/*      */     }
/* 4897 */     int strLen = str.length();
/* 4898 */     int pads = size - strLen;
/* 4899 */     if (pads <= 0) {
/* 4900 */       return str;
/*      */     }
/* 4902 */     str = leftPad(str, strLen + pads / 2, padStr);
/* 4903 */     return rightPad(str, size, padStr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String upperCase(String str) {
/* 4929 */     if (str == null) {
/* 4930 */       return null;
/*      */     }
/* 4932 */     return str.toUpperCase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String upperCase(String str, Locale locale) {
/* 4952 */     if (str == null) {
/* 4953 */       return null;
/*      */     }
/* 4955 */     return str.toUpperCase(locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String lowerCase(String str) {
/* 4978 */     if (str == null) {
/* 4979 */       return null;
/*      */     }
/* 4981 */     return str.toLowerCase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String lowerCase(String str, Locale locale) {
/* 5001 */     if (str == null) {
/* 5002 */       return null;
/*      */     }
/* 5004 */     return str.toLowerCase(locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String capitalize(String str) {
/*      */     int strLen;
/* 5029 */     if (str == null || (strLen = str.length()) == 0) {
/* 5030 */       return str;
/*      */     }
/* 5032 */     return strLen.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String uncapitalize(String str) {
/*      */     int strLen;
/* 5060 */     if (str == null || (strLen = str.length()) == 0) {
/* 5061 */       return str;
/*      */     }
/* 5063 */     return strLen.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String swapCase(String str) {
/* 5097 */     if (isEmpty(str)) {
/* 5098 */       return str;
/*      */     }
/*      */     
/* 5101 */     char[] buffer = str.toCharArray();
/*      */     
/* 5103 */     for (int i = 0; i < buffer.length; i++) {
/* 5104 */       char ch = buffer[i];
/* 5105 */       if (Character.isUpperCase(ch)) {
/* 5106 */         buffer[i] = Character.toLowerCase(ch);
/* 5107 */       } else if (Character.isTitleCase(ch)) {
/* 5108 */         buffer[i] = Character.toLowerCase(ch);
/* 5109 */       } else if (Character.isLowerCase(ch)) {
/* 5110 */         buffer[i] = Character.toUpperCase(ch);
/*      */       } 
/*      */     } 
/* 5113 */     return new String(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int countMatches(CharSequence str, CharSequence sub) {
/* 5139 */     if (isEmpty(str) || isEmpty(sub)) {
/* 5140 */       return 0;
/*      */     }
/* 5142 */     int count = 0;
/* 5143 */     int idx = 0;
/* 5144 */     while ((idx = CharSequenceUtils.indexOf(str, sub, idx)) != -1) {
/* 5145 */       count++;
/* 5146 */       idx += sub.length();
/*      */     } 
/* 5148 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlpha(CharSequence cs) {
/* 5174 */     if (cs == null || cs.length() == 0) {
/* 5175 */       return false;
/*      */     }
/* 5177 */     int sz = cs.length();
/* 5178 */     for (int i = 0; i < sz; i++) {
/* 5179 */       if (!Character.isLetter(cs.charAt(i))) {
/* 5180 */         return false;
/*      */       }
/*      */     } 
/* 5183 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphaSpace(CharSequence cs) {
/* 5209 */     if (cs == null) {
/* 5210 */       return false;
/*      */     }
/* 5212 */     int sz = cs.length();
/* 5213 */     for (int i = 0; i < sz; i++) {
/* 5214 */       if (!Character.isLetter(cs.charAt(i)) && cs.charAt(i) != ' ') {
/* 5215 */         return false;
/*      */       }
/*      */     } 
/* 5218 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphanumeric(CharSequence cs) {
/* 5244 */     if (cs == null || cs.length() == 0) {
/* 5245 */       return false;
/*      */     }
/* 5247 */     int sz = cs.length();
/* 5248 */     for (int i = 0; i < sz; i++) {
/* 5249 */       if (!Character.isLetterOrDigit(cs.charAt(i))) {
/* 5250 */         return false;
/*      */       }
/*      */     } 
/* 5253 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAlphanumericSpace(CharSequence cs) {
/* 5279 */     if (cs == null) {
/* 5280 */       return false;
/*      */     }
/* 5282 */     int sz = cs.length();
/* 5283 */     for (int i = 0; i < sz; i++) {
/* 5284 */       if (!Character.isLetterOrDigit(cs.charAt(i)) && cs.charAt(i) != ' ') {
/* 5285 */         return false;
/*      */       }
/*      */     } 
/* 5288 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAsciiPrintable(CharSequence cs) {
/* 5318 */     if (cs == null) {
/* 5319 */       return false;
/*      */     }
/* 5321 */     int sz = cs.length();
/* 5322 */     for (int i = 0; i < sz; i++) {
/* 5323 */       if (!CharUtils.isAsciiPrintable(cs.charAt(i))) {
/* 5324 */         return false;
/*      */       }
/*      */     } 
/* 5327 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumeric(CharSequence cs) {
/* 5354 */     if (cs == null || cs.length() == 0) {
/* 5355 */       return false;
/*      */     }
/* 5357 */     int sz = cs.length();
/* 5358 */     for (int i = 0; i < sz; i++) {
/* 5359 */       if (!Character.isDigit(cs.charAt(i))) {
/* 5360 */         return false;
/*      */       }
/*      */     } 
/* 5363 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumericSpace(CharSequence cs) {
/* 5391 */     if (cs == null) {
/* 5392 */       return false;
/*      */     }
/* 5394 */     int sz = cs.length();
/* 5395 */     for (int i = 0; i < sz; i++) {
/* 5396 */       if (!Character.isDigit(cs.charAt(i)) && cs.charAt(i) != ' ') {
/* 5397 */         return false;
/*      */       }
/*      */     } 
/* 5400 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWhitespace(CharSequence cs) {
/* 5424 */     if (cs == null) {
/* 5425 */       return false;
/*      */     }
/* 5427 */     int sz = cs.length();
/* 5428 */     for (int i = 0; i < sz; i++) {
/* 5429 */       if (!Character.isWhitespace(cs.charAt(i))) {
/* 5430 */         return false;
/*      */       }
/*      */     } 
/* 5433 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAllLowerCase(CharSequence cs) {
/* 5456 */     if (cs == null || isEmpty(cs)) {
/* 5457 */       return false;
/*      */     }
/* 5459 */     int sz = cs.length();
/* 5460 */     for (int i = 0; i < sz; i++) {
/* 5461 */       if (!Character.isLowerCase(cs.charAt(i))) {
/* 5462 */         return false;
/*      */       }
/*      */     } 
/* 5465 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAllUpperCase(CharSequence cs) {
/* 5488 */     if (cs == null || isEmpty(cs)) {
/* 5489 */       return false;
/*      */     }
/* 5491 */     int sz = cs.length();
/* 5492 */     for (int i = 0; i < sz; i++) {
/* 5493 */       if (!Character.isUpperCase(cs.charAt(i))) {
/* 5494 */         return false;
/*      */       }
/*      */     } 
/* 5497 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5519 */   public static String defaultString(String str) { return (str == null) ? "" : str; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5540 */   public static String defaultString(String str, String defaultStr) { return (str == null) ? defaultStr : str; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5562 */   public static <T extends CharSequence> T defaultIfBlank(T str, T defaultStr) { return isBlank(str) ? defaultStr : str; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5583 */   public static <T extends CharSequence> T defaultIfEmpty(T str, T defaultStr) { return isEmpty(str) ? defaultStr : str; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String reverse(String str) {
/* 5603 */     if (str == null) {
/* 5604 */       return null;
/*      */     }
/* 5606 */     return (new StringBuilder(str)).reverse().toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String reverseDelimited(String str, char separatorChar) {
/* 5629 */     if (str == null) {
/* 5630 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 5634 */     String[] strs = split(str, separatorChar);
/* 5635 */     ArrayUtils.reverse(strs);
/* 5636 */     return join(strs, separatorChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5674 */   public static String abbreviate(String str, int maxWidth) { return abbreviate(str, 0, maxWidth); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviate(String str, int offset, int maxWidth) {
/* 5713 */     if (str == null) {
/* 5714 */       return null;
/*      */     }
/* 5716 */     if (maxWidth < 4) {
/* 5717 */       throw new IllegalArgumentException("Minimum abbreviation width is 4");
/*      */     }
/* 5719 */     if (str.length() <= maxWidth) {
/* 5720 */       return str;
/*      */     }
/* 5722 */     if (offset > str.length()) {
/* 5723 */       offset = str.length();
/*      */     }
/* 5725 */     if (str.length() - offset < maxWidth - 3) {
/* 5726 */       offset = str.length() - maxWidth - 3;
/*      */     }
/* 5728 */     String abrevMarker = "...";
/* 5729 */     if (offset <= 4) {
/* 5730 */       return str.substring(0, maxWidth - 3) + "...";
/*      */     }
/* 5732 */     if (maxWidth < 7) {
/* 5733 */       throw new IllegalArgumentException("Minimum abbreviation width with offset is 7");
/*      */     }
/* 5735 */     if (offset + maxWidth - 3 < str.length()) {
/* 5736 */       return "..." + abbreviate(str.substring(offset), maxWidth - 3);
/*      */     }
/* 5738 */     return "..." + str.substring(str.length() - maxWidth - 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String abbreviateMiddle(String str, String middle, int length) {
/* 5771 */     if (isEmpty(str) || isEmpty(middle)) {
/* 5772 */       return str;
/*      */     }
/*      */     
/* 5775 */     if (length >= str.length() || length < middle.length() + 2) {
/* 5776 */       return str;
/*      */     }
/*      */     
/* 5779 */     int targetSting = length - middle.length();
/* 5780 */     int startOffset = targetSting / 2 + targetSting % 2;
/* 5781 */     int endOffset = str.length() - targetSting / 2;
/*      */     
/* 5783 */     StringBuilder builder = new StringBuilder(length);
/* 5784 */     builder.append(str.substring(0, startOffset));
/* 5785 */     builder.append(middle);
/* 5786 */     builder.append(str.substring(endOffset));
/*      */     
/* 5788 */     return builder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String difference(String str1, String str2) {
/* 5819 */     if (str1 == null) {
/* 5820 */       return str2;
/*      */     }
/* 5822 */     if (str2 == null) {
/* 5823 */       return str1;
/*      */     }
/* 5825 */     int at = indexOfDifference(str1, str2);
/* 5826 */     if (at == -1) {
/* 5827 */       return "";
/*      */     }
/* 5829 */     return str2.substring(at);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfDifference(CharSequence cs1, CharSequence cs2) {
/* 5858 */     if (cs1 == cs2) {
/* 5859 */       return -1;
/*      */     }
/* 5861 */     if (cs1 == null || cs2 == null) {
/* 5862 */       return 0;
/*      */     }
/*      */     int i;
/* 5865 */     for (i = 0; i < cs1.length() && i < cs2.length() && 
/* 5866 */       cs1.charAt(i) == cs2.charAt(i); i++);
/*      */ 
/*      */ 
/*      */     
/* 5870 */     if (i < cs2.length() || i < cs1.length()) {
/* 5871 */       return i;
/*      */     }
/* 5873 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int indexOfDifference(CharSequence... css) {
/* 5909 */     if (css == null || css.length <= 1) {
/* 5910 */       return -1;
/*      */     }
/* 5912 */     boolean anyStringNull = false;
/* 5913 */     boolean allStringsNull = true;
/* 5914 */     int arrayLen = css.length;
/* 5915 */     int shortestStrLen = Integer.MAX_VALUE;
/* 5916 */     int longestStrLen = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5921 */     for (int i = 0; i < arrayLen; i++) {
/* 5922 */       if (css[i] == null) {
/* 5923 */         anyStringNull = true;
/* 5924 */         shortestStrLen = 0;
/*      */       } else {
/* 5926 */         allStringsNull = false;
/* 5927 */         shortestStrLen = Math.min(css[i].length(), shortestStrLen);
/* 5928 */         longestStrLen = Math.max(css[i].length(), longestStrLen);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 5933 */     if (allStringsNull || (longestStrLen == 0 && !anyStringNull)) {
/* 5934 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 5938 */     if (shortestStrLen == 0) {
/* 5939 */       return 0;
/*      */     }
/*      */ 
/*      */     
/* 5943 */     int firstDiff = -1;
/* 5944 */     for (int stringPos = 0; stringPos < shortestStrLen; stringPos++) {
/* 5945 */       char comparisonChar = css[0].charAt(stringPos);
/* 5946 */       for (int arrayPos = 1; arrayPos < arrayLen; arrayPos++) {
/* 5947 */         if (css[arrayPos].charAt(stringPos) != comparisonChar) {
/* 5948 */           firstDiff = stringPos;
/*      */           break;
/*      */         } 
/*      */       } 
/* 5952 */       if (firstDiff != -1) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 5957 */     if (firstDiff == -1 && shortestStrLen != longestStrLen)
/*      */     {
/*      */ 
/*      */       
/* 5961 */       return shortestStrLen;
/*      */     }
/* 5963 */     return firstDiff;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getCommonPrefix(String... strs) {
/* 6000 */     if (strs == null || strs.length == 0) {
/* 6001 */       return "";
/*      */     }
/* 6003 */     int smallestIndexOfDiff = indexOfDifference(strs);
/* 6004 */     if (smallestIndexOfDiff == -1) {
/*      */       
/* 6006 */       if (strs[false] == null) {
/* 6007 */         return "";
/*      */       }
/* 6009 */       return strs[0];
/* 6010 */     }  if (smallestIndexOfDiff == 0)
/*      */     {
/* 6012 */       return "";
/*      */     }
/*      */     
/* 6015 */     return strs[0].substring(0, smallestIndexOfDiff);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getLevenshteinDistance(CharSequence s, CharSequence t) {
/* 6058 */     if (s == null || t == null) {
/* 6059 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6079 */     int n = s.length();
/* 6080 */     int m = t.length();
/*      */     
/* 6082 */     if (n == 0)
/* 6083 */       return m; 
/* 6084 */     if (m == 0) {
/* 6085 */       return n;
/*      */     }
/*      */     
/* 6088 */     if (n > m) {
/*      */       
/* 6090 */       CharSequence tmp = s;
/* 6091 */       s = t;
/* 6092 */       t = tmp;
/* 6093 */       n = m;
/* 6094 */       m = t.length();
/*      */     } 
/*      */     
/* 6097 */     int[] p = new int[n + 1];
/* 6098 */     int[] d = new int[n + 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int i;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6109 */     for (i = 0; i <= n; i++) {
/* 6110 */       p[i] = i;
/*      */     }
/*      */     
/* 6113 */     for (int j = 1; j <= m; j++) {
/* 6114 */       char t_j = t.charAt(j - 1);
/* 6115 */       d[0] = j;
/*      */       
/* 6117 */       for (i = 1; i <= n; i++) {
/* 6118 */         int cost = (s.charAt(i - 1) == t_j) ? 0 : 1;
/*      */         
/* 6120 */         d[i] = Math.min(Math.min(d[i - 1] + 1, p[i] + 1), p[i - 1] + cost);
/*      */       } 
/*      */ 
/*      */       
/* 6124 */       int[] _d = p;
/* 6125 */       p = d;
/* 6126 */       d = _d;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 6131 */     return p[n];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getLevenshteinDistance(CharSequence s, CharSequence t, int threshold) {
/* 6167 */     if (s == null || t == null) {
/* 6168 */       throw new IllegalArgumentException("Strings must not be null");
/*      */     }
/* 6170 */     if (threshold < 0) {
/* 6171 */       throw new IllegalArgumentException("Threshold must not be negative");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6218 */     int n = s.length();
/* 6219 */     int m = t.length();
/*      */ 
/*      */     
/* 6222 */     if (n == 0)
/* 6223 */       return (m <= threshold) ? m : -1; 
/* 6224 */     if (m == 0) {
/* 6225 */       return (n <= threshold) ? n : -1;
/*      */     }
/*      */     
/* 6228 */     if (n > m) {
/*      */       
/* 6230 */       CharSequence tmp = s;
/* 6231 */       s = t;
/* 6232 */       t = tmp;
/* 6233 */       n = m;
/* 6234 */       m = t.length();
/*      */     } 
/*      */     
/* 6237 */     int[] p = new int[n + 1];
/* 6238 */     int[] d = new int[n + 1];
/*      */ 
/*      */ 
/*      */     
/* 6242 */     int boundary = Math.min(n, threshold) + 1;
/* 6243 */     for (int i = 0; i < boundary; i++) {
/* 6244 */       p[i] = i;
/*      */     }
/*      */ 
/*      */     
/* 6248 */     Arrays.fill(p, boundary, p.length, 2147483647);
/* 6249 */     Arrays.fill(d, 2147483647);
/*      */ 
/*      */     
/* 6252 */     for (int j = 1; j <= m; j++) {
/* 6253 */       char t_j = t.charAt(j - 1);
/* 6254 */       d[0] = j;
/*      */ 
/*      */       
/* 6257 */       int min = Math.max(1, j - threshold);
/* 6258 */       int max = Math.min(n, j + threshold);
/*      */ 
/*      */       
/* 6261 */       if (min > max) {
/* 6262 */         return -1;
/*      */       }
/*      */ 
/*      */       
/* 6266 */       if (min > 1) {
/* 6267 */         d[min - 1] = Integer.MAX_VALUE;
/*      */       }
/*      */ 
/*      */       
/* 6271 */       for (int i = min; i <= max; i++) {
/* 6272 */         if (s.charAt(i - 1) == t_j) {
/*      */           
/* 6274 */           d[i] = p[i - 1];
/*      */         } else {
/*      */           
/* 6277 */           d[i] = 1 + Math.min(Math.min(d[i - 1], p[i]), p[i - 1]);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 6282 */       int[] _d = p;
/* 6283 */       p = d;
/* 6284 */       d = _d;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 6289 */     if (p[n] <= threshold) {
/* 6290 */       return p[n];
/*      */     }
/* 6292 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6322 */   public static boolean startsWith(CharSequence str, CharSequence prefix) { return startsWith(str, prefix, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6348 */   public static boolean startsWithIgnoreCase(CharSequence str, CharSequence prefix) { return startsWith(str, prefix, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean startsWith(CharSequence str, CharSequence prefix, boolean ignoreCase) {
/* 6363 */     if (str == null || prefix == null) {
/* 6364 */       return (str == null && prefix == null);
/*      */     }
/* 6366 */     if (prefix.length() > str.length()) {
/* 6367 */       return false;
/*      */     }
/* 6369 */     return CharSequenceUtils.regionMatches(str, ignoreCase, 0, prefix, 0, prefix.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean startsWithAny(CharSequence string, CharSequence... searchStrings) {
/* 6392 */     if (isEmpty(string) || ArrayUtils.isEmpty(searchStrings)) {
/* 6393 */       return false;
/*      */     }
/* 6395 */     for (CharSequence searchString : searchStrings) {
/* 6396 */       if (startsWith(string, searchString)) {
/* 6397 */         return true;
/*      */       }
/*      */     } 
/* 6400 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6430 */   public static boolean endsWith(CharSequence str, CharSequence suffix) { return endsWith(str, suffix, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6457 */   public static boolean endsWithIgnoreCase(CharSequence str, CharSequence suffix) { return endsWith(str, suffix, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean endsWith(CharSequence str, CharSequence suffix, boolean ignoreCase) {
/* 6472 */     if (str == null || suffix == null) {
/* 6473 */       return (str == null && suffix == null);
/*      */     }
/* 6475 */     if (suffix.length() > str.length()) {
/* 6476 */       return false;
/*      */     }
/* 6478 */     int strOffset = str.length() - suffix.length();
/* 6479 */     return CharSequenceUtils.regionMatches(str, ignoreCase, strOffset, suffix, 0, suffix.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String normalizeSpace(String str) {
/* 6524 */     if (str == null) {
/* 6525 */       return null;
/*      */     }
/* 6527 */     return WHITESPACE_BLOCK.matcher(trim(str)).replaceAll(" ");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean endsWithAny(CharSequence string, CharSequence... searchStrings) {
/* 6549 */     if (isEmpty(string) || ArrayUtils.isEmpty(searchStrings)) {
/* 6550 */       return false;
/*      */     }
/* 6552 */     for (CharSequence searchString : searchStrings) {
/* 6553 */       if (endsWith(string, searchString)) {
/* 6554 */         return true;
/*      */       }
/*      */     } 
/* 6557 */     return false;
/*      */   }
/*      */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\StringUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */