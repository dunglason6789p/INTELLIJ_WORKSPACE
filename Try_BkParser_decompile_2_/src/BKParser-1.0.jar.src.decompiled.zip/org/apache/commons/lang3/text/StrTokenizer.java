/*      */ package org.apache.commons.lang3.text;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.NoSuchElementException;
/*      */ import org.apache.commons.lang3.ArrayUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StrTokenizer
/*      */   extends Object
/*      */   implements ListIterator<String>, Cloneable
/*      */ {
/*   92 */   private static final StrTokenizer CSV_TOKENIZER_PROTOTYPE = new StrTokenizer(); static  {
/*   93 */     CSV_TOKENIZER_PROTOTYPE.setDelimiterMatcher(StrMatcher.commaMatcher());
/*   94 */     CSV_TOKENIZER_PROTOTYPE.setQuoteMatcher(StrMatcher.doubleQuoteMatcher());
/*   95 */     CSV_TOKENIZER_PROTOTYPE.setIgnoredMatcher(StrMatcher.noneMatcher());
/*   96 */     CSV_TOKENIZER_PROTOTYPE.setTrimmerMatcher(StrMatcher.trimMatcher());
/*   97 */     CSV_TOKENIZER_PROTOTYPE.setEmptyTokenAsNull(false);
/*   98 */     CSV_TOKENIZER_PROTOTYPE.setIgnoreEmptyTokens(false);
/*      */     
/*  100 */     TSV_TOKENIZER_PROTOTYPE = new StrTokenizer();
/*  101 */     TSV_TOKENIZER_PROTOTYPE.setDelimiterMatcher(StrMatcher.tabMatcher());
/*  102 */     TSV_TOKENIZER_PROTOTYPE.setQuoteMatcher(StrMatcher.doubleQuoteMatcher());
/*  103 */     TSV_TOKENIZER_PROTOTYPE.setIgnoredMatcher(StrMatcher.noneMatcher());
/*  104 */     TSV_TOKENIZER_PROTOTYPE.setTrimmerMatcher(StrMatcher.trimMatcher());
/*  105 */     TSV_TOKENIZER_PROTOTYPE.setEmptyTokenAsNull(false);
/*  106 */     TSV_TOKENIZER_PROTOTYPE.setIgnoreEmptyTokens(false);
/*      */   }
/*      */ 
/*      */   
/*      */   private static final StrTokenizer TSV_TOKENIZER_PROTOTYPE;
/*      */   
/*      */   private char[] chars;
/*      */   
/*      */   private String[] tokens;
/*      */   
/*      */   private int tokenPos;
/*  117 */   private StrMatcher delimMatcher = StrMatcher.splitMatcher();
/*      */   
/*  119 */   private StrMatcher quoteMatcher = StrMatcher.noneMatcher();
/*      */   
/*  121 */   private StrMatcher ignoredMatcher = StrMatcher.noneMatcher();
/*      */   
/*  123 */   private StrMatcher trimmerMatcher = StrMatcher.noneMatcher();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean emptyAsNull = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ignoreEmptyTokens = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private static StrTokenizer getCSVClone() { return (StrTokenizer)CSV_TOKENIZER_PROTOTYPE.clone(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   public static StrTokenizer getCSVInstance() { return getCSVClone(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StrTokenizer getCSVInstance(String input) {
/*  164 */     StrTokenizer tok = getCSVClone();
/*  165 */     tok.reset(input);
/*  166 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StrTokenizer getCSVInstance(char[] input) {
/*  179 */     StrTokenizer tok = getCSVClone();
/*  180 */     tok.reset(input);
/*  181 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   private static StrTokenizer getTSVClone() { return (StrTokenizer)TSV_TOKENIZER_PROTOTYPE.clone(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  203 */   public static StrTokenizer getTSVInstance() { return getTSVClone(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StrTokenizer getTSVInstance(String input) {
/*  214 */     StrTokenizer tok = getTSVClone();
/*  215 */     tok.reset(input);
/*  216 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static StrTokenizer getTSVInstance(char[] input) {
/*  227 */     StrTokenizer tok = getTSVClone();
/*  228 */     tok.reset(input);
/*  229 */     return tok;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  241 */   public StrTokenizer() { this.chars = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(String input) {
/*  252 */     if (input != null) {
/*  253 */       this.chars = input.toCharArray();
/*      */     } else {
/*  255 */       this.chars = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(String input, char delim) {
/*  266 */     this(input);
/*  267 */     setDelimiterChar(delim);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(String input, String delim) {
/*  277 */     this(input);
/*  278 */     setDelimiterString(delim);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(String input, StrMatcher delim) {
/*  288 */     this(input);
/*  289 */     setDelimiterMatcher(delim);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(String input, char delim, char quote) {
/*  301 */     this(input, delim);
/*  302 */     setQuoteChar(quote);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(String input, StrMatcher delim, StrMatcher quote) {
/*  314 */     this(input, delim);
/*  315 */     setQuoteMatcher(quote);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  326 */   public StrTokenizer(char[] input) { this.chars = ArrayUtils.clone(input); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(char[] input, char delim) {
/*  336 */     this(input);
/*  337 */     setDelimiterChar(delim);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(char[] input, String delim) {
/*  347 */     this(input);
/*  348 */     setDelimiterString(delim);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(char[] input, StrMatcher delim) {
/*  358 */     this(input);
/*  359 */     setDelimiterMatcher(delim);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(char[] input, char delim, char quote) {
/*  371 */     this(input, delim);
/*  372 */     setQuoteChar(quote);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer(char[] input, StrMatcher delim, StrMatcher quote) {
/*  384 */     this(input, delim);
/*  385 */     setQuoteMatcher(quote);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  396 */     checkTokenized();
/*  397 */     return this.tokens.length;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nextToken() {
/*  408 */     if (hasNext()) {
/*  409 */       return this.tokens[this.tokenPos++];
/*      */     }
/*  411 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String previousToken() {
/*  420 */     if (hasPrevious()) {
/*  421 */       return this.tokens[--this.tokenPos];
/*      */     }
/*  423 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getTokenArray() {
/*  432 */     checkTokenized();
/*  433 */     return (String[])this.tokens.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> getTokenList() {
/*  442 */     checkTokenized();
/*  443 */     List<String> list = new ArrayList<String>(this.tokens.length);
/*  444 */     for (String element : this.tokens) {
/*  445 */       list.add(element);
/*      */     }
/*  447 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer reset() {
/*  458 */     this.tokenPos = 0;
/*  459 */     this.tokens = null;
/*  460 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer reset(String input) {
/*  472 */     reset();
/*  473 */     if (input != null) {
/*  474 */       this.chars = input.toCharArray();
/*      */     } else {
/*  476 */       this.chars = null;
/*      */     } 
/*  478 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer reset(char[] input) {
/*  490 */     reset();
/*  491 */     this.chars = ArrayUtils.clone(input);
/*  492 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasNext() {
/*  503 */     checkTokenized();
/*  504 */     return (this.tokenPos < this.tokens.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String next() {
/*  514 */     if (hasNext()) {
/*  515 */       return this.tokens[this.tokenPos++];
/*      */     }
/*  517 */     throw new NoSuchElementException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  526 */   public int nextIndex() { return this.tokenPos; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasPrevious() {
/*  535 */     checkTokenized();
/*  536 */     return (this.tokenPos > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String previous() {
/*  545 */     if (hasPrevious()) {
/*  546 */       return this.tokens[--this.tokenPos];
/*      */     }
/*  548 */     throw new NoSuchElementException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  557 */   public int previousIndex() { return this.tokenPos - 1; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  566 */   public void remove() { throw new UnsupportedOperationException("remove() is unsupported"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  575 */   public void set(String obj) { throw new UnsupportedOperationException("set() is unsupported"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  584 */   public void add(String obj) { throw new UnsupportedOperationException("add() is unsupported"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkTokenized() {
/*  593 */     if (this.tokens == null) {
/*  594 */       if (this.chars == null) {
/*      */         
/*  596 */         List<String> split = tokenize(null, 0, 0);
/*  597 */         this.tokens = (String[])split.toArray(new String[split.size()]);
/*      */       } else {
/*  599 */         List<String> split = tokenize(this.chars, 0, this.chars.length);
/*  600 */         this.tokens = (String[])split.toArray(new String[split.size()]);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List<String> tokenize(char[] chars, int offset, int count) {
/*  626 */     if (chars == null || count == 0) {
/*  627 */       return Collections.emptyList();
/*      */     }
/*  629 */     StrBuilder buf = new StrBuilder();
/*  630 */     List<String> tokens = new ArrayList<String>();
/*  631 */     int pos = offset;
/*      */ 
/*      */     
/*  634 */     while (pos >= 0 && pos < count) {
/*      */       
/*  636 */       pos = readNextToken(chars, pos, count, buf, tokens);
/*      */ 
/*      */       
/*  639 */       if (pos >= count) {
/*  640 */         addToken(tokens, "");
/*      */       }
/*      */     } 
/*  643 */     return tokens;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addToken(List<String> list, String tok) {
/*  653 */     if (tok == null || tok.length() == 0) {
/*  654 */       if (isIgnoreEmptyTokens()) {
/*      */         return;
/*      */       }
/*  657 */       if (isEmptyTokenAsNull()) {
/*  658 */         tok = null;
/*      */       }
/*      */     } 
/*  661 */     list.add(tok);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readNextToken(char[] chars, int start, int len, StrBuilder workArea, List<String> tokens) {
/*  678 */     while (start < len) {
/*  679 */       int removeLen = Math.max(getIgnoredMatcher().isMatch(chars, start, start, len), getTrimmerMatcher().isMatch(chars, start, start, len));
/*      */ 
/*      */       
/*  682 */       if (removeLen == 0 || getDelimiterMatcher().isMatch(chars, start, start, len) > 0 || getQuoteMatcher().isMatch(chars, start, start, len) > 0) {
/*      */         break;
/*      */       }
/*      */ 
/*      */       
/*  687 */       start += removeLen;
/*      */     } 
/*      */ 
/*      */     
/*  691 */     if (start >= len) {
/*  692 */       addToken(tokens, "");
/*  693 */       return -1;
/*      */     } 
/*      */ 
/*      */     
/*  697 */     int delimLen = getDelimiterMatcher().isMatch(chars, start, start, len);
/*  698 */     if (delimLen > 0) {
/*  699 */       addToken(tokens, "");
/*  700 */       return start + delimLen;
/*      */     } 
/*      */ 
/*      */     
/*  704 */     int quoteLen = getQuoteMatcher().isMatch(chars, start, start, len);
/*  705 */     if (quoteLen > 0) {
/*  706 */       return readWithQuotes(chars, start + quoteLen, len, workArea, tokens, start, quoteLen);
/*      */     }
/*  708 */     return readWithQuotes(chars, start, len, workArea, tokens, 0, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readWithQuotes(char[] chars, int start, int len, StrBuilder workArea, List<String> tokens, int quoteStart, int quoteLen) {
/*  729 */     workArea.clear();
/*  730 */     int pos = start;
/*  731 */     boolean quoting = (quoteLen > 0);
/*  732 */     int trimStart = 0;
/*      */     
/*  734 */     while (pos < len) {
/*      */ 
/*      */ 
/*      */       
/*  738 */       if (quoting) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  745 */         if (isQuote(chars, pos, len, quoteStart, quoteLen)) {
/*  746 */           if (isQuote(chars, pos + quoteLen, len, quoteStart, quoteLen)) {
/*      */             
/*  748 */             workArea.append(chars, pos, quoteLen);
/*  749 */             pos += quoteLen * 2;
/*  750 */             trimStart = workArea.size();
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  755 */           quoting = false;
/*  756 */           pos += quoteLen;
/*      */           
/*      */           continue;
/*      */         } 
/*      */         
/*  761 */         workArea.append(chars[pos++]);
/*  762 */         trimStart = workArea.size();
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  768 */       int delimLen = getDelimiterMatcher().isMatch(chars, pos, start, len);
/*  769 */       if (delimLen > 0) {
/*      */         
/*  771 */         addToken(tokens, workArea.substring(0, trimStart));
/*  772 */         return pos + delimLen;
/*      */       } 
/*      */ 
/*      */       
/*  776 */       if (quoteLen > 0 && 
/*  777 */         isQuote(chars, pos, len, quoteStart, quoteLen)) {
/*  778 */         quoting = true;
/*  779 */         pos += quoteLen;
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  785 */       int ignoredLen = getIgnoredMatcher().isMatch(chars, pos, start, len);
/*  786 */       if (ignoredLen > 0) {
/*  787 */         pos += ignoredLen;
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */       
/*  794 */       int trimmedLen = getTrimmerMatcher().isMatch(chars, pos, start, len);
/*  795 */       if (trimmedLen > 0) {
/*  796 */         workArea.append(chars, pos, trimmedLen);
/*  797 */         pos += trimmedLen;
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  802 */       workArea.append(chars[pos++]);
/*  803 */       trimStart = workArea.size();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  808 */     addToken(tokens, workArea.substring(0, trimStart));
/*  809 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isQuote(char[] chars, int pos, int len, int quoteStart, int quoteLen) {
/*  824 */     for (int i = 0; i < quoteLen; i++) {
/*  825 */       if (pos + i >= len || chars[pos + i] != chars[quoteStart + i]) {
/*  826 */         return false;
/*      */       }
/*      */     } 
/*  829 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  840 */   public StrMatcher getDelimiterMatcher() { return this.delimMatcher; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer setDelimiterMatcher(StrMatcher delim) {
/*  852 */     if (delim == null) {
/*  853 */       this.delimMatcher = StrMatcher.noneMatcher();
/*      */     } else {
/*  855 */       this.delimMatcher = delim;
/*      */     } 
/*  857 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  867 */   public StrTokenizer setDelimiterChar(char delim) { return setDelimiterMatcher(StrMatcher.charMatcher(delim)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  877 */   public StrTokenizer setDelimiterString(String delim) { return setDelimiterMatcher(StrMatcher.stringMatcher(delim)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  892 */   public StrMatcher getQuoteMatcher() { return this.quoteMatcher; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer setQuoteMatcher(StrMatcher quote) {
/*  905 */     if (quote != null) {
/*  906 */       this.quoteMatcher = quote;
/*      */     }
/*  908 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  921 */   public StrTokenizer setQuoteChar(char quote) { return setQuoteMatcher(StrMatcher.charMatcher(quote)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  936 */   public StrMatcher getIgnoredMatcher() { return this.ignoredMatcher; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer setIgnoredMatcher(StrMatcher ignored) {
/*  949 */     if (ignored != null) {
/*  950 */       this.ignoredMatcher = ignored;
/*      */     }
/*  952 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  965 */   public StrTokenizer setIgnoredChar(char ignored) { return setIgnoredMatcher(StrMatcher.charMatcher(ignored)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  980 */   public StrMatcher getTrimmerMatcher() { return this.trimmerMatcher; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer setTrimmerMatcher(StrMatcher trimmer) {
/*  993 */     if (trimmer != null) {
/*  994 */       this.trimmerMatcher = trimmer;
/*      */     }
/*  996 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1007 */   public boolean isEmptyTokenAsNull() { return this.emptyAsNull; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer setEmptyTokenAsNull(boolean emptyAsNull) {
/* 1018 */     this.emptyAsNull = emptyAsNull;
/* 1019 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1030 */   public boolean isIgnoreEmptyTokens() { return this.ignoreEmptyTokens; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrTokenizer setIgnoreEmptyTokens(boolean ignoreEmptyTokens) {
/* 1041 */     this.ignoreEmptyTokens = ignoreEmptyTokens;
/* 1042 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getContent() {
/* 1052 */     if (this.chars == null) {
/* 1053 */       return null;
/*      */     }
/* 1055 */     return new String(this.chars);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object clone() {
/*      */     try {
/* 1069 */       return cloneReset();
/* 1070 */     } catch (CloneNotSupportedException ex) {
/* 1071 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object cloneReset() {
/* 1084 */     StrTokenizer cloned = (StrTokenizer)super.clone();
/* 1085 */     if (cloned.chars != null) {
/* 1086 */       cloned.chars = (char[])cloned.chars.clone();
/*      */     }
/* 1088 */     cloned.reset();
/* 1089 */     return cloned;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1100 */     if (this.tokens == null) {
/* 1101 */       return "StrTokenizer[not tokenized yet]";
/*      */     }
/* 1103 */     return "StrTokenizer" + getTokenList();
/*      */   }
/*      */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\text\StrTokenizer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */