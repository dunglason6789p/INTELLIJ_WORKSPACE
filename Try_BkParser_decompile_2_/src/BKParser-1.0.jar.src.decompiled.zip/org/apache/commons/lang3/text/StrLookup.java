/*     */ package org.apache.commons.lang3.text;
/*     */ 
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class StrLookup<V>
/*     */   extends Object
/*     */ {
/*  48 */   private static final StrLookup<String> NONE_LOOKUP = new MapStrLookup(null); static  {
/*  49 */     lookup = null;
/*     */     try {
/*  51 */       Map<?, ?> propMap = System.getProperties();
/*     */       
/*  53 */       Map<String, String> properties = propMap;
/*  54 */       lookup = new MapStrLookup(properties);
/*  55 */     } catch (SecurityException ex) {
/*  56 */       lookup = NONE_LOOKUP;
/*     */     } 
/*  58 */     SYSTEM_PROPERTIES_LOOKUP = lookup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final StrLookup<String> SYSTEM_PROPERTIES_LOOKUP;
/*     */ 
/*     */ 
/*     */   
/*  68 */   public static StrLookup<?> noneLookup() { return NONE_LOOKUP; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static StrLookup<String> systemPropertiesLookup() { return SYSTEM_PROPERTIES_LOOKUP; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public static <V> StrLookup<V> mapLookup(Map<String, V> map) { return new MapStrLookup(map); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String lookup(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class MapStrLookup<V>
/*     */     extends StrLookup<V>
/*     */   {
/*     */     private final Map<String, V> map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     MapStrLookup(Map<String, V> map) { this.map = map; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String lookup(String key) {
/* 162 */       if (this.map == null) {
/* 163 */         return null;
/*     */       }
/* 165 */       Object obj = this.map.get(key);
/* 166 */       if (obj == null) {
/* 167 */         return null;
/*     */       }
/* 169 */       return obj.toString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\text\StrLookup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */