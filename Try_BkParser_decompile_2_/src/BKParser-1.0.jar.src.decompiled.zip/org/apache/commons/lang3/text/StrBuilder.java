/*      */ package org.apache.commons.lang3.text;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.apache.commons.lang3.ArrayUtils;
/*      */ import org.apache.commons.lang3.SystemUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StrBuilder
/*      */   implements CharSequence, Appendable
/*      */ {
/*      */   static final int CAPACITY = 32;
/*      */   private static final long serialVersionUID = 7628716375283629643L;
/*      */   protected char[] buffer;
/*      */   protected int size;
/*      */   private String newLine;
/*      */   private String nullText;
/*      */   
/*  100 */   public StrBuilder() { this(32); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder(int initialCapacity) {
/*  110 */     if (initialCapacity <= 0) {
/*  111 */       initialCapacity = 32;
/*      */     }
/*  113 */     this.buffer = new char[initialCapacity];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder(String str) {
/*  124 */     if (str == null) {
/*  125 */       this.buffer = new char[32];
/*      */     } else {
/*  127 */       this.buffer = new char[str.length() + 32];
/*  128 */       append(str);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   public String getNewLineText() { return this.newLine; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder setNewLineText(String newLine) {
/*  149 */     this.newLine = newLine;
/*  150 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   public String getNullText() { return this.nullText; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder setNullText(String nullText) {
/*  170 */     if (nullText != null && nullText.length() == 0) {
/*  171 */       nullText = null;
/*      */     }
/*  173 */     this.nullText = nullText;
/*  174 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  184 */   public int length() { return this.size; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder setLength(int length) {
/*  196 */     if (length < 0) {
/*  197 */       throw new StringIndexOutOfBoundsException(length);
/*      */     }
/*  199 */     if (length < this.size) {
/*  200 */       this.size = length;
/*  201 */     } else if (length > this.size) {
/*  202 */       ensureCapacity(length);
/*  203 */       int oldEnd = this.size;
/*  204 */       int newEnd = length;
/*  205 */       this.size = length;
/*  206 */       for (int i = oldEnd; i < newEnd; i++) {
/*  207 */         this.buffer[i] = Character.MIN_VALUE;
/*      */       }
/*      */     } 
/*  210 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  220 */   public int capacity() { return this.buffer.length; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder ensureCapacity(int capacity) {
/*  230 */     if (capacity > this.buffer.length) {
/*  231 */       char[] old = this.buffer;
/*  232 */       this.buffer = new char[capacity * 2];
/*  233 */       System.arraycopy(old, 0, this.buffer, 0, this.size);
/*      */     } 
/*  235 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder minimizeCapacity() {
/*  244 */     if (this.buffer.length > length()) {
/*  245 */       char[] old = this.buffer;
/*  246 */       this.buffer = new char[length()];
/*  247 */       System.arraycopy(old, 0, this.buffer, 0, this.size);
/*      */     } 
/*  249 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  262 */   public int size() { return this.size; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  274 */   public boolean isEmpty() { return (this.size == 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder clear() {
/*  289 */     this.size = 0;
/*  290 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char charAt(int index) {
/*  304 */     if (index < 0 || index >= length()) {
/*  305 */       throw new StringIndexOutOfBoundsException(index);
/*      */     }
/*  307 */     return this.buffer[index];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder setCharAt(int index, char ch) {
/*  321 */     if (index < 0 || index >= length()) {
/*  322 */       throw new StringIndexOutOfBoundsException(index);
/*      */     }
/*  324 */     this.buffer[index] = ch;
/*  325 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder deleteCharAt(int index) {
/*  338 */     if (index < 0 || index >= this.size) {
/*  339 */       throw new StringIndexOutOfBoundsException(index);
/*      */     }
/*  341 */     deleteImpl(index, index + 1, 1);
/*  342 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] toCharArray() {
/*  352 */     if (this.size == 0) {
/*  353 */       return ArrayUtils.EMPTY_CHAR_ARRAY;
/*      */     }
/*  355 */     char[] chars = new char[this.size];
/*  356 */     System.arraycopy(this.buffer, 0, chars, 0, this.size);
/*  357 */     return chars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] toCharArray(int startIndex, int endIndex) {
/*  371 */     endIndex = validateRange(startIndex, endIndex);
/*  372 */     int len = endIndex - startIndex;
/*  373 */     if (len == 0) {
/*  374 */       return ArrayUtils.EMPTY_CHAR_ARRAY;
/*      */     }
/*  376 */     char[] chars = new char[len];
/*  377 */     System.arraycopy(this.buffer, startIndex, chars, 0, len);
/*  378 */     return chars;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public char[] getChars(char[] destination) {
/*  388 */     int len = length();
/*  389 */     if (destination == null || destination.length < len) {
/*  390 */       destination = new char[len];
/*      */     }
/*  392 */     System.arraycopy(this.buffer, 0, destination, 0, len);
/*  393 */     return destination;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getChars(int startIndex, int endIndex, char[] destination, int destinationIndex) {
/*  407 */     if (startIndex < 0) {
/*  408 */       throw new StringIndexOutOfBoundsException(startIndex);
/*      */     }
/*  410 */     if (endIndex < 0 || endIndex > length()) {
/*  411 */       throw new StringIndexOutOfBoundsException(endIndex);
/*      */     }
/*  413 */     if (startIndex > endIndex) {
/*  414 */       throw new StringIndexOutOfBoundsException("end < start");
/*      */     }
/*  416 */     System.arraycopy(this.buffer, startIndex, destination, destinationIndex, endIndex - startIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendNewLine() {
/*  430 */     if (this.newLine == null) {
/*  431 */       append(SystemUtils.LINE_SEPARATOR);
/*  432 */       return this;
/*      */     } 
/*  434 */     return append(this.newLine);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendNull() {
/*  443 */     if (this.nullText == null) {
/*  444 */       return this;
/*      */     }
/*  446 */     return append(this.nullText);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(Object obj) {
/*  457 */     if (obj == null) {
/*  458 */       return appendNull();
/*      */     }
/*  460 */     return append(obj.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(CharSequence seq) {
/*  472 */     if (seq == null) {
/*  473 */       return appendNull();
/*      */     }
/*  475 */     return append(seq.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(CharSequence seq, int startIndex, int length) {
/*  489 */     if (seq == null) {
/*  490 */       return appendNull();
/*      */     }
/*  492 */     return append(seq.toString(), startIndex, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(String str) {
/*  503 */     if (str == null) {
/*  504 */       return appendNull();
/*      */     }
/*  506 */     int strLen = str.length();
/*  507 */     if (strLen > 0) {
/*  508 */       int len = length();
/*  509 */       ensureCapacity(len + strLen);
/*  510 */       str.getChars(0, strLen, this.buffer, len);
/*  511 */       this.size += strLen;
/*      */     } 
/*  513 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(String str, int startIndex, int length) {
/*  526 */     if (str == null) {
/*  527 */       return appendNull();
/*      */     }
/*  529 */     if (startIndex < 0 || startIndex > str.length()) {
/*  530 */       throw new StringIndexOutOfBoundsException("startIndex must be valid");
/*      */     }
/*  532 */     if (length < 0 || startIndex + length > str.length()) {
/*  533 */       throw new StringIndexOutOfBoundsException("length must be valid");
/*      */     }
/*  535 */     if (length > 0) {
/*  536 */       int len = length();
/*  537 */       ensureCapacity(len + length);
/*  538 */       str.getChars(startIndex, startIndex + length, this.buffer, len);
/*  539 */       this.size += length;
/*      */     } 
/*  541 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(StringBuffer str) {
/*  552 */     if (str == null) {
/*  553 */       return appendNull();
/*      */     }
/*  555 */     int strLen = str.length();
/*  556 */     if (strLen > 0) {
/*  557 */       int len = length();
/*  558 */       ensureCapacity(len + strLen);
/*  559 */       str.getChars(0, strLen, this.buffer, len);
/*  560 */       this.size += strLen;
/*      */     } 
/*  562 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(StringBuffer str, int startIndex, int length) {
/*  575 */     if (str == null) {
/*  576 */       return appendNull();
/*      */     }
/*  578 */     if (startIndex < 0 || startIndex > str.length()) {
/*  579 */       throw new StringIndexOutOfBoundsException("startIndex must be valid");
/*      */     }
/*  581 */     if (length < 0 || startIndex + length > str.length()) {
/*  582 */       throw new StringIndexOutOfBoundsException("length must be valid");
/*      */     }
/*  584 */     if (length > 0) {
/*  585 */       int len = length();
/*  586 */       ensureCapacity(len + length);
/*  587 */       str.getChars(startIndex, startIndex + length, this.buffer, len);
/*  588 */       this.size += length;
/*      */     } 
/*  590 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(StrBuilder str) {
/*  601 */     if (str == null) {
/*  602 */       return appendNull();
/*      */     }
/*  604 */     int strLen = str.length();
/*  605 */     if (strLen > 0) {
/*  606 */       int len = length();
/*  607 */       ensureCapacity(len + strLen);
/*  608 */       System.arraycopy(str.buffer, 0, this.buffer, len, strLen);
/*  609 */       this.size += strLen;
/*      */     } 
/*  611 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(StrBuilder str, int startIndex, int length) {
/*  624 */     if (str == null) {
/*  625 */       return appendNull();
/*      */     }
/*  627 */     if (startIndex < 0 || startIndex > str.length()) {
/*  628 */       throw new StringIndexOutOfBoundsException("startIndex must be valid");
/*      */     }
/*  630 */     if (length < 0 || startIndex + length > str.length()) {
/*  631 */       throw new StringIndexOutOfBoundsException("length must be valid");
/*      */     }
/*  633 */     if (length > 0) {
/*  634 */       int len = length();
/*  635 */       ensureCapacity(len + length);
/*  636 */       str.getChars(startIndex, startIndex + length, this.buffer, len);
/*  637 */       this.size += length;
/*      */     } 
/*  639 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(char[] chars) {
/*  650 */     if (chars == null) {
/*  651 */       return appendNull();
/*      */     }
/*  653 */     int strLen = chars.length;
/*  654 */     if (strLen > 0) {
/*  655 */       int len = length();
/*  656 */       ensureCapacity(len + strLen);
/*  657 */       System.arraycopy(chars, 0, this.buffer, len, strLen);
/*  658 */       this.size += strLen;
/*      */     } 
/*  660 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(char[] chars, int startIndex, int length) {
/*  673 */     if (chars == null) {
/*  674 */       return appendNull();
/*      */     }
/*  676 */     if (startIndex < 0 || startIndex > chars.length) {
/*  677 */       throw new StringIndexOutOfBoundsException("Invalid startIndex: " + length);
/*      */     }
/*  679 */     if (length < 0 || startIndex + length > chars.length) {
/*  680 */       throw new StringIndexOutOfBoundsException("Invalid length: " + length);
/*      */     }
/*  682 */     if (length > 0) {
/*  683 */       int len = length();
/*  684 */       ensureCapacity(len + length);
/*  685 */       System.arraycopy(chars, startIndex, this.buffer, len, length);
/*  686 */       this.size += length;
/*      */     } 
/*  688 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(boolean value) {
/*  698 */     if (value) {
/*  699 */       ensureCapacity(this.size + 4);
/*  700 */       this.buffer[this.size++] = 't';
/*  701 */       this.buffer[this.size++] = 'r';
/*  702 */       this.buffer[this.size++] = 'u';
/*  703 */       this.buffer[this.size++] = 'e';
/*      */     } else {
/*  705 */       ensureCapacity(this.size + 5);
/*  706 */       this.buffer[this.size++] = 'f';
/*  707 */       this.buffer[this.size++] = 'a';
/*  708 */       this.buffer[this.size++] = 'l';
/*  709 */       this.buffer[this.size++] = 's';
/*  710 */       this.buffer[this.size++] = 'e';
/*      */     } 
/*  712 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder append(char ch) {
/*  723 */     int len = length();
/*  724 */     ensureCapacity(len + 1);
/*  725 */     this.buffer[this.size++] = ch;
/*  726 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  736 */   public StrBuilder append(int value) { return append(String.valueOf(value)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  746 */   public StrBuilder append(long value) { return append(String.valueOf(value)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  756 */   public StrBuilder append(float value) { return append(String.valueOf(value)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  766 */   public StrBuilder append(double value) { return append(String.valueOf(value)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  779 */   public StrBuilder appendln(Object obj) { return append(obj).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  791 */   public StrBuilder appendln(String str) { return append(str).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  805 */   public StrBuilder appendln(String str, int startIndex, int length) { return append(str, startIndex, length).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  817 */   public StrBuilder appendln(StringBuffer str) { return append(str).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  831 */   public StrBuilder appendln(StringBuffer str, int startIndex, int length) { return append(str, startIndex, length).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  843 */   public StrBuilder appendln(StrBuilder str) { return append(str).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  857 */   public StrBuilder appendln(StrBuilder str, int startIndex, int length) { return append(str, startIndex, length).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  869 */   public StrBuilder appendln(char[] chars) { return append(chars).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  883 */   public StrBuilder appendln(char[] chars, int startIndex, int length) { return append(chars, startIndex, length).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  894 */   public StrBuilder appendln(boolean value) { return append(value).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  905 */   public StrBuilder appendln(char ch) { return append(ch).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  916 */   public StrBuilder appendln(int value) { return append(value).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  927 */   public StrBuilder appendln(long value) { return append(value).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  938 */   public StrBuilder appendln(float value) { return append(value).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  949 */   public StrBuilder appendln(double value) { return append(value).appendNewLine(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendAll(Object[] array) {
/*  963 */     if (array != null && array.length > 0) {
/*  964 */       for (Object element : array) {
/*  965 */         append(element);
/*      */       }
/*      */     }
/*  968 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendAll(Iterable<?> iterable) {
/*  981 */     if (iterable != null) {
/*  982 */       Iterator<?> it = iterable.iterator();
/*  983 */       while (it.hasNext()) {
/*  984 */         append(it.next());
/*      */       }
/*      */     } 
/*  987 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendAll(Iterator<?> it) {
/* 1000 */     if (it != null) {
/* 1001 */       while (it.hasNext()) {
/* 1002 */         append(it.next());
/*      */       }
/*      */     }
/* 1005 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendWithSeparators(Object[] array, String separator) {
/* 1020 */     if (array != null && array.length > 0) {
/* 1021 */       separator = (separator == null) ? "" : separator;
/* 1022 */       append(array[0]);
/* 1023 */       for (int i = 1; i < array.length; i++) {
/* 1024 */         append(separator);
/* 1025 */         append(array[i]);
/*      */       } 
/*      */     } 
/* 1028 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendWithSeparators(Iterable<?> iterable, String separator) {
/* 1042 */     if (iterable != null) {
/* 1043 */       separator = (separator == null) ? "" : separator;
/* 1044 */       Iterator<?> it = iterable.iterator();
/* 1045 */       while (it.hasNext()) {
/* 1046 */         append(it.next());
/* 1047 */         if (it.hasNext()) {
/* 1048 */           append(separator);
/*      */         }
/*      */       } 
/*      */     } 
/* 1052 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendWithSeparators(Iterator<?> it, String separator) {
/* 1066 */     if (it != null) {
/* 1067 */       separator = (separator == null) ? "" : separator;
/* 1068 */       while (it.hasNext()) {
/* 1069 */         append(it.next());
/* 1070 */         if (it.hasNext()) {
/* 1071 */           append(separator);
/*      */         }
/*      */       } 
/*      */     } 
/* 1075 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1100 */   public StrBuilder appendSeparator(String separator) { return appendSeparator(separator, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendSeparator(String standard, String defaultIfEmpty) {
/* 1131 */     String str = isEmpty() ? defaultIfEmpty : standard;
/* 1132 */     if (str != null) {
/* 1133 */       append(str);
/*      */     }
/* 1135 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendSeparator(char separator) {
/* 1158 */     if (size() > 0) {
/* 1159 */       append(separator);
/*      */     }
/* 1161 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendSeparator(char standard, char defaultIfEmpty) {
/* 1176 */     if (size() > 0) {
/* 1177 */       append(standard);
/*      */     } else {
/* 1179 */       append(defaultIfEmpty);
/*      */     } 
/* 1181 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendSeparator(String separator, int loopIndex) {
/* 1205 */     if (separator != null && loopIndex > 0) {
/* 1206 */       append(separator);
/*      */     }
/* 1208 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendSeparator(char separator, int loopIndex) {
/* 1232 */     if (loopIndex > 0) {
/* 1233 */       append(separator);
/*      */     }
/* 1235 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendPadding(int length, char padChar) {
/* 1247 */     if (length >= 0) {
/* 1248 */       ensureCapacity(this.size + length);
/* 1249 */       for (int i = 0; i < length; i++) {
/* 1250 */         this.buffer[this.size++] = padChar;
/*      */       }
/*      */     } 
/* 1253 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendFixedWidthPadLeft(Object obj, int width, char padChar) {
/* 1269 */     if (width > 0) {
/* 1270 */       ensureCapacity(this.size + width);
/* 1271 */       String str = (obj == null) ? getNullText() : obj.toString();
/* 1272 */       if (str == null) {
/* 1273 */         str = "";
/*      */       }
/* 1275 */       int strLen = str.length();
/* 1276 */       if (strLen >= width) {
/* 1277 */         str.getChars(strLen - width, strLen, this.buffer, this.size);
/*      */       } else {
/* 1279 */         int padLen = width - strLen;
/* 1280 */         for (int i = 0; i < padLen; i++) {
/* 1281 */           this.buffer[this.size + i] = padChar;
/*      */         }
/* 1283 */         str.getChars(0, strLen, this.buffer, this.size + padLen);
/*      */       } 
/* 1285 */       this.size += width;
/*      */     } 
/* 1287 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1301 */   public StrBuilder appendFixedWidthPadLeft(int value, int width, char padChar) { return appendFixedWidthPadLeft(String.valueOf(value), width, padChar); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder appendFixedWidthPadRight(Object obj, int width, char padChar) {
/* 1316 */     if (width > 0) {
/* 1317 */       ensureCapacity(this.size + width);
/* 1318 */       String str = (obj == null) ? getNullText() : obj.toString();
/* 1319 */       if (str == null) {
/* 1320 */         str = "";
/*      */       }
/* 1322 */       int strLen = str.length();
/* 1323 */       if (strLen >= width) {
/* 1324 */         str.getChars(0, width, this.buffer, this.size);
/*      */       } else {
/* 1326 */         int padLen = width - strLen;
/* 1327 */         str.getChars(0, strLen, this.buffer, this.size);
/* 1328 */         for (int i = 0; i < padLen; i++) {
/* 1329 */           this.buffer[this.size + strLen + i] = padChar;
/*      */         }
/*      */       } 
/* 1332 */       this.size += width;
/*      */     } 
/* 1334 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1348 */   public StrBuilder appendFixedWidthPadRight(int value, int width, char padChar) { return appendFixedWidthPadRight(String.valueOf(value), width, padChar); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder insert(int index, Object obj) {
/* 1362 */     if (obj == null) {
/* 1363 */       return insert(index, this.nullText);
/*      */     }
/* 1365 */     return insert(index, obj.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder insert(int index, String str) {
/* 1379 */     validateIndex(index);
/* 1380 */     if (str == null) {
/* 1381 */       str = this.nullText;
/*      */     }
/* 1383 */     int strLen = (str == null) ? 0 : str.length();
/* 1384 */     if (strLen > 0) {
/* 1385 */       int newSize = this.size + strLen;
/* 1386 */       ensureCapacity(newSize);
/* 1387 */       System.arraycopy(this.buffer, index, this.buffer, index + strLen, this.size - index);
/* 1388 */       this.size = newSize;
/* 1389 */       str.getChars(0, strLen, this.buffer, index);
/*      */     } 
/* 1391 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder insert(int index, char[] chars) {
/* 1404 */     validateIndex(index);
/* 1405 */     if (chars == null) {
/* 1406 */       return insert(index, this.nullText);
/*      */     }
/* 1408 */     int len = chars.length;
/* 1409 */     if (len > 0) {
/* 1410 */       ensureCapacity(this.size + len);
/* 1411 */       System.arraycopy(this.buffer, index, this.buffer, index + len, this.size - index);
/* 1412 */       System.arraycopy(chars, 0, this.buffer, index, len);
/* 1413 */       this.size += len;
/*      */     } 
/* 1415 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder insert(int index, char[] chars, int offset, int length) {
/* 1430 */     validateIndex(index);
/* 1431 */     if (chars == null) {
/* 1432 */       return insert(index, this.nullText);
/*      */     }
/* 1434 */     if (offset < 0 || offset > chars.length) {
/* 1435 */       throw new StringIndexOutOfBoundsException("Invalid offset: " + offset);
/*      */     }
/* 1437 */     if (length < 0 || offset + length > chars.length) {
/* 1438 */       throw new StringIndexOutOfBoundsException("Invalid length: " + length);
/*      */     }
/* 1440 */     if (length > 0) {
/* 1441 */       ensureCapacity(this.size + length);
/* 1442 */       System.arraycopy(this.buffer, index, this.buffer, index + length, this.size - index);
/* 1443 */       System.arraycopy(chars, offset, this.buffer, index, length);
/* 1444 */       this.size += length;
/*      */     } 
/* 1446 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder insert(int index, boolean value) {
/* 1458 */     validateIndex(index);
/* 1459 */     if (value) {
/* 1460 */       ensureCapacity(this.size + 4);
/* 1461 */       System.arraycopy(this.buffer, index, this.buffer, index + 4, this.size - index);
/* 1462 */       this.buffer[index++] = 't';
/* 1463 */       this.buffer[index++] = 'r';
/* 1464 */       this.buffer[index++] = 'u';
/* 1465 */       this.buffer[index] = 'e';
/* 1466 */       this.size += 4;
/*      */     } else {
/* 1468 */       ensureCapacity(this.size + 5);
/* 1469 */       System.arraycopy(this.buffer, index, this.buffer, index + 5, this.size - index);
/* 1470 */       this.buffer[index++] = 'f';
/* 1471 */       this.buffer[index++] = 'a';
/* 1472 */       this.buffer[index++] = 'l';
/* 1473 */       this.buffer[index++] = 's';
/* 1474 */       this.buffer[index] = 'e';
/* 1475 */       this.size += 5;
/*      */     } 
/* 1477 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder insert(int index, char value) {
/* 1489 */     validateIndex(index);
/* 1490 */     ensureCapacity(this.size + 1);
/* 1491 */     System.arraycopy(this.buffer, index, this.buffer, index + 1, this.size - index);
/* 1492 */     this.buffer[index] = value;
/* 1493 */     this.size++;
/* 1494 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1506 */   public StrBuilder insert(int index, int value) { return insert(index, String.valueOf(value)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1518 */   public StrBuilder insert(int index, long value) { return insert(index, String.valueOf(value)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1530 */   public StrBuilder insert(int index, float value) { return insert(index, String.valueOf(value)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1542 */   public StrBuilder insert(int index, double value) { return insert(index, String.valueOf(value)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void deleteImpl(int startIndex, int endIndex, int len) {
/* 1555 */     System.arraycopy(this.buffer, endIndex, this.buffer, startIndex, this.size - endIndex);
/* 1556 */     this.size -= len;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder delete(int startIndex, int endIndex) {
/* 1569 */     endIndex = validateRange(startIndex, endIndex);
/* 1570 */     int len = endIndex - startIndex;
/* 1571 */     if (len > 0) {
/* 1572 */       deleteImpl(startIndex, endIndex, len);
/*      */     }
/* 1574 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder deleteAll(char ch) {
/* 1585 */     for (int i = 0; i < this.size; i++) {
/* 1586 */       if (this.buffer[i] == ch) {
/* 1587 */         int start = i; do {  }
/* 1588 */         while (++i < this.size && 
/* 1589 */           this.buffer[i] == ch);
/*      */ 
/*      */ 
/*      */         
/* 1593 */         int len = i - start;
/* 1594 */         deleteImpl(start, i, len);
/* 1595 */         i -= len;
/*      */       } 
/*      */     } 
/* 1598 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder deleteFirst(char ch) {
/* 1608 */     for (int i = 0; i < this.size; i++) {
/* 1609 */       if (this.buffer[i] == ch) {
/* 1610 */         deleteImpl(i, i + 1, 1);
/*      */         break;
/*      */       } 
/*      */     } 
/* 1614 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder deleteAll(String str) {
/* 1625 */     int len = (str == null) ? 0 : str.length();
/* 1626 */     if (len > 0) {
/* 1627 */       int index = indexOf(str, 0);
/* 1628 */       while (index >= 0) {
/* 1629 */         deleteImpl(index, index + len, len);
/* 1630 */         index = indexOf(str, index);
/*      */       } 
/*      */     } 
/* 1633 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder deleteFirst(String str) {
/* 1643 */     int len = (str == null) ? 0 : str.length();
/* 1644 */     if (len > 0) {
/* 1645 */       int index = indexOf(str, 0);
/* 1646 */       if (index >= 0) {
/* 1647 */         deleteImpl(index, index + len, len);
/*      */       }
/*      */     } 
/* 1650 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1665 */   public StrBuilder deleteAll(StrMatcher matcher) { return replace(matcher, null, 0, this.size, -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1679 */   public StrBuilder deleteFirst(StrMatcher matcher) { return replace(matcher, null, 0, this.size, 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void replaceImpl(int startIndex, int endIndex, int removeLen, String insertStr, int insertLen) {
/* 1694 */     int newSize = this.size - removeLen + insertLen;
/* 1695 */     if (insertLen != removeLen) {
/* 1696 */       ensureCapacity(newSize);
/* 1697 */       System.arraycopy(this.buffer, endIndex, this.buffer, startIndex + insertLen, this.size - endIndex);
/* 1698 */       this.size = newSize;
/*      */     } 
/* 1700 */     if (insertLen > 0) {
/* 1701 */       insertStr.getChars(0, insertLen, this.buffer, startIndex);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder replace(int startIndex, int endIndex, String replaceStr) {
/* 1717 */     endIndex = validateRange(startIndex, endIndex);
/* 1718 */     int insertLen = (replaceStr == null) ? 0 : replaceStr.length();
/* 1719 */     replaceImpl(startIndex, endIndex, endIndex - startIndex, replaceStr, insertLen);
/* 1720 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder replaceAll(char search, char replace) {
/* 1733 */     if (search != replace) {
/* 1734 */       for (int i = 0; i < this.size; i++) {
/* 1735 */         if (this.buffer[i] == search) {
/* 1736 */           this.buffer[i] = replace;
/*      */         }
/*      */       } 
/*      */     }
/* 1740 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder replaceFirst(char search, char replace) {
/* 1752 */     if (search != replace) {
/* 1753 */       for (int i = 0; i < this.size; i++) {
/* 1754 */         if (this.buffer[i] == search) {
/* 1755 */           this.buffer[i] = replace;
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     }
/* 1760 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder replaceAll(String searchStr, String replaceStr) {
/* 1772 */     int searchLen = (searchStr == null) ? 0 : searchStr.length();
/* 1773 */     if (searchLen > 0) {
/* 1774 */       int replaceLen = (replaceStr == null) ? 0 : replaceStr.length();
/* 1775 */       int index = indexOf(searchStr, 0);
/* 1776 */       while (index >= 0) {
/* 1777 */         replaceImpl(index, index + searchLen, searchLen, replaceStr, replaceLen);
/* 1778 */         index = indexOf(searchStr, index + replaceLen);
/*      */       } 
/*      */     } 
/* 1781 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder replaceFirst(String searchStr, String replaceStr) {
/* 1792 */     int searchLen = (searchStr == null) ? 0 : searchStr.length();
/* 1793 */     if (searchLen > 0) {
/* 1794 */       int index = indexOf(searchStr, 0);
/* 1795 */       if (index >= 0) {
/* 1796 */         int replaceLen = (replaceStr == null) ? 0 : replaceStr.length();
/* 1797 */         replaceImpl(index, index + searchLen, searchLen, replaceStr, replaceLen);
/*      */       } 
/*      */     } 
/* 1800 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1816 */   public StrBuilder replaceAll(StrMatcher matcher, String replaceStr) { return replace(matcher, replaceStr, 0, this.size, -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1831 */   public StrBuilder replaceFirst(StrMatcher matcher, String replaceStr) { return replace(matcher, replaceStr, 0, this.size, 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder replace(StrMatcher matcher, String replaceStr, int startIndex, int endIndex, int replaceCount) {
/* 1854 */     endIndex = validateRange(startIndex, endIndex);
/* 1855 */     return replaceImpl(matcher, replaceStr, startIndex, endIndex, replaceCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StrBuilder replaceImpl(StrMatcher matcher, String replaceStr, int from, int to, int replaceCount) {
/* 1876 */     if (matcher == null || this.size == 0) {
/* 1877 */       return this;
/*      */     }
/* 1879 */     int replaceLen = (replaceStr == null) ? 0 : replaceStr.length();
/* 1880 */     char[] buf = this.buffer;
/* 1881 */     for (int i = from; i < to && replaceCount != 0; i++) {
/* 1882 */       int removeLen = matcher.isMatch(buf, i, from, to);
/* 1883 */       if (removeLen > 0) {
/* 1884 */         replaceImpl(i, i + removeLen, removeLen, replaceStr, replaceLen);
/* 1885 */         to = to - removeLen + replaceLen;
/* 1886 */         i = i + replaceLen - 1;
/* 1887 */         if (replaceCount > 0) {
/* 1888 */           replaceCount--;
/*      */         }
/*      */       } 
/*      */     } 
/* 1892 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder reverse() {
/* 1902 */     if (this.size == 0) {
/* 1903 */       return this;
/*      */     }
/*      */     
/* 1906 */     int half = this.size / 2;
/* 1907 */     char[] buf = this.buffer;
/* 1908 */     for (int leftIdx = 0, rightIdx = this.size - 1; leftIdx < half; leftIdx++, rightIdx--) {
/* 1909 */       char swap = buf[leftIdx];
/* 1910 */       buf[leftIdx] = buf[rightIdx];
/* 1911 */       buf[rightIdx] = swap;
/*      */     } 
/* 1913 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StrBuilder trim() {
/* 1924 */     if (this.size == 0) {
/* 1925 */       return this;
/*      */     }
/* 1927 */     int len = this.size;
/* 1928 */     char[] buf = this.buffer;
/* 1929 */     int pos = 0;
/* 1930 */     while (pos < len && buf[pos] <= ' ') {
/* 1931 */       pos++;
/*      */     }
/* 1933 */     while (pos < len && buf[len - 1] <= ' ') {
/* 1934 */       len--;
/*      */     }
/* 1936 */     if (len < this.size) {
/* 1937 */       delete(len, this.size);
/*      */     }
/* 1939 */     if (pos > 0) {
/* 1940 */       delete(0, pos);
/*      */     }
/* 1942 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean startsWith(String str) {
/* 1955 */     if (str == null) {
/* 1956 */       return false;
/*      */     }
/* 1958 */     int len = str.length();
/* 1959 */     if (len == 0) {
/* 1960 */       return true;
/*      */     }
/* 1962 */     if (len > this.size) {
/* 1963 */       return false;
/*      */     }
/* 1965 */     for (int i = 0; i < len; i++) {
/* 1966 */       if (this.buffer[i] != str.charAt(i)) {
/* 1967 */         return false;
/*      */       }
/*      */     } 
/* 1970 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean endsWith(String str) {
/* 1982 */     if (str == null) {
/* 1983 */       return false;
/*      */     }
/* 1985 */     int len = str.length();
/* 1986 */     if (len == 0) {
/* 1987 */       return true;
/*      */     }
/* 1989 */     if (len > this.size) {
/* 1990 */       return false;
/*      */     }
/* 1992 */     int pos = this.size - len;
/* 1993 */     for (int i = 0; i < len; i++, pos++) {
/* 1994 */       if (this.buffer[pos] != str.charAt(i)) {
/* 1995 */         return false;
/*      */       }
/*      */     } 
/* 1998 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CharSequence subSequence(int startIndex, int endIndex) {
/* 2007 */     if (startIndex < 0) {
/* 2008 */       throw new StringIndexOutOfBoundsException(startIndex);
/*      */     }
/* 2010 */     if (endIndex > this.size) {
/* 2011 */       throw new StringIndexOutOfBoundsException(endIndex);
/*      */     }
/* 2013 */     if (startIndex > endIndex) {
/* 2014 */       throw new StringIndexOutOfBoundsException(endIndex - startIndex);
/*      */     }
/* 2016 */     return substring(startIndex, endIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2027 */   public String substring(int start) { return substring(start, this.size); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String substring(int startIndex, int endIndex) {
/* 2044 */     endIndex = validateRange(startIndex, endIndex);
/* 2045 */     return new String(this.buffer, startIndex, endIndex - startIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String leftString(int length) {
/* 2061 */     if (length <= 0)
/* 2062 */       return ""; 
/* 2063 */     if (length >= this.size) {
/* 2064 */       return new String(this.buffer, 0, this.size);
/*      */     }
/* 2066 */     return new String(this.buffer, 0, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String rightString(int length) {
/* 2083 */     if (length <= 0)
/* 2084 */       return ""; 
/* 2085 */     if (length >= this.size) {
/* 2086 */       return new String(this.buffer, 0, this.size);
/*      */     }
/* 2088 */     return new String(this.buffer, this.size - length, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String midString(int index, int length) {
/* 2109 */     if (index < 0) {
/* 2110 */       index = 0;
/*      */     }
/* 2112 */     if (length <= 0 || index >= this.size) {
/* 2113 */       return "";
/*      */     }
/* 2115 */     if (this.size <= index + length) {
/* 2116 */       return new String(this.buffer, index, this.size - index);
/*      */     }
/* 2118 */     return new String(this.buffer, index, length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(char ch) {
/* 2130 */     char[] thisBuf = this.buffer;
/* 2131 */     for (int i = 0; i < this.size; i++) {
/* 2132 */       if (thisBuf[i] == ch) {
/* 2133 */         return true;
/*      */       }
/*      */     } 
/* 2136 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2146 */   public boolean contains(String str) { return (indexOf(str, 0) >= 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2161 */   public boolean contains(StrMatcher matcher) { return (indexOf(matcher, 0) >= 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2172 */   public int indexOf(char ch) { return indexOf(ch, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(char ch, int startIndex) {
/* 2183 */     startIndex = (startIndex < 0) ? 0 : startIndex;
/* 2184 */     if (startIndex >= this.size) {
/* 2185 */       return -1;
/*      */     }
/* 2187 */     char[] thisBuf = this.buffer;
/* 2188 */     for (int i = startIndex; i < this.size; i++) {
/* 2189 */       if (thisBuf[i] == ch) {
/* 2190 */         return i;
/*      */       }
/*      */     } 
/* 2193 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2205 */   public int indexOf(String str) { return indexOf(str, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(String str, int startIndex) {
/* 2219 */     startIndex = (startIndex < 0) ? 0 : startIndex;
/* 2220 */     if (str == null || startIndex >= this.size) {
/* 2221 */       return -1;
/*      */     }
/* 2223 */     int strLen = str.length();
/* 2224 */     if (strLen == 1) {
/* 2225 */       return indexOf(str.charAt(0), startIndex);
/*      */     }
/* 2227 */     if (strLen == 0) {
/* 2228 */       return startIndex;
/*      */     }
/* 2230 */     if (strLen > this.size) {
/* 2231 */       return -1;
/*      */     }
/* 2233 */     char[] thisBuf = this.buffer;
/* 2234 */     int len = this.size - strLen + 1;
/*      */     
/* 2236 */     for (int i = startIndex; i < len; i++) {
/* 2237 */       int j = 0; while (true) { if (j < strLen) {
/* 2238 */           if (str.charAt(j) != thisBuf[i + j])
/*      */             break;  j++;
/*      */           continue;
/*      */         } 
/* 2242 */         return i; }
/*      */     
/* 2244 */     }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2258 */   public int indexOf(StrMatcher matcher) { return indexOf(matcher, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(StrMatcher matcher, int startIndex) {
/* 2274 */     startIndex = (startIndex < 0) ? 0 : startIndex;
/* 2275 */     if (matcher == null || startIndex >= this.size) {
/* 2276 */       return -1;
/*      */     }
/* 2278 */     int len = this.size;
/* 2279 */     char[] buf = this.buffer;
/* 2280 */     for (int i = startIndex; i < len; i++) {
/* 2281 */       if (matcher.isMatch(buf, i, startIndex, len) > 0) {
/* 2282 */         return i;
/*      */       }
/*      */     } 
/* 2285 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2296 */   public int lastIndexOf(char ch) { return lastIndexOf(ch, this.size - 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lastIndexOf(char ch, int startIndex) {
/* 2307 */     startIndex = (startIndex >= this.size) ? (this.size - 1) : startIndex;
/* 2308 */     if (startIndex < 0) {
/* 2309 */       return -1;
/*      */     }
/* 2311 */     for (int i = startIndex; i >= 0; i--) {
/* 2312 */       if (this.buffer[i] == ch) {
/* 2313 */         return i;
/*      */       }
/*      */     } 
/* 2316 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2328 */   public int lastIndexOf(String str) { return lastIndexOf(str, this.size - 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lastIndexOf(String str, int startIndex) {
/* 2342 */     startIndex = (startIndex >= this.size) ? (this.size - 1) : startIndex;
/* 2343 */     if (str == null || startIndex < 0) {
/* 2344 */       return -1;
/*      */     }
/* 2346 */     int strLen = str.length();
/* 2347 */     if (strLen > 0 && strLen <= this.size) {
/* 2348 */       if (strLen == 1) {
/* 2349 */         return lastIndexOf(str.charAt(0), startIndex);
/*      */       }
/*      */ 
/*      */       
/* 2353 */       for (int i = startIndex - strLen + 1; i >= 0; i--) {
/* 2354 */         int j = 0; while (true) { if (j < strLen) {
/* 2355 */             if (str.charAt(j) != this.buffer[i + j])
/*      */               break;  j++;
/*      */             continue;
/*      */           } 
/* 2359 */           return i; }
/*      */       
/*      */       } 
/* 2362 */     } else if (strLen == 0) {
/* 2363 */       return startIndex;
/*      */     } 
/* 2365 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2379 */   public int lastIndexOf(StrMatcher matcher) { return lastIndexOf(matcher, this.size); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lastIndexOf(StrMatcher matcher, int startIndex) {
/* 2395 */     startIndex = (startIndex >= this.size) ? (this.size - 1) : startIndex;
/* 2396 */     if (matcher == null || startIndex < 0) {
/* 2397 */       return -1;
/*      */     }
/* 2399 */     char[] buf = this.buffer;
/* 2400 */     int endIndex = startIndex + 1;
/* 2401 */     for (int i = startIndex; i >= 0; i--) {
/* 2402 */       if (matcher.isMatch(buf, i, 0, endIndex) > 0) {
/* 2403 */         return i;
/*      */       }
/*      */     } 
/* 2406 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2443 */   public StrTokenizer asTokenizer() { return new StrBuilderTokenizer(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2467 */   public Reader asReader() { return new StrBuilderReader(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2492 */   public Writer asWriter() { return new StrBuilderWriter(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equalsIgnoreCase(StrBuilder other) {
/* 2534 */     if (this == other) {
/* 2535 */       return true;
/*      */     }
/* 2537 */     if (this.size != other.size) {
/* 2538 */       return false;
/*      */     }
/* 2540 */     char[] thisBuf = this.buffer;
/* 2541 */     char[] otherBuf = other.buffer;
/* 2542 */     for (int i = this.size - 1; i >= 0; i--) {
/* 2543 */       char c1 = thisBuf[i];
/* 2544 */       char c2 = otherBuf[i];
/* 2545 */       if (c1 != c2 && Character.toUpperCase(c1) != Character.toUpperCase(c2)) {
/* 2546 */         return false;
/*      */       }
/*      */     } 
/* 2549 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(StrBuilder other) {
/* 2560 */     if (this == other) {
/* 2561 */       return true;
/*      */     }
/* 2563 */     if (this.size != other.size) {
/* 2564 */       return false;
/*      */     }
/* 2566 */     char[] thisBuf = this.buffer;
/* 2567 */     char[] otherBuf = other.buffer;
/* 2568 */     for (int i = this.size - 1; i >= 0; i--) {
/* 2569 */       if (thisBuf[i] != otherBuf[i]) {
/* 2570 */         return false;
/*      */       }
/*      */     } 
/* 2573 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 2585 */     if (obj instanceof StrBuilder) {
/* 2586 */       return equals((StrBuilder)obj);
/*      */     }
/* 2588 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 2598 */     char[] buf = this.buffer;
/* 2599 */     int hash = 0;
/* 2600 */     for (int i = this.size - 1; i >= 0; i--) {
/* 2601 */       hash = 31 * hash + buf[i];
/*      */     }
/* 2603 */     return hash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2618 */   public String toString() { return new String(this.buffer, 0, this.size); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2628 */   public StringBuffer toStringBuffer() { return (new StringBuffer(this.size)).append(this.buffer, 0, this.size); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int validateRange(int startIndex, int endIndex) {
/* 2642 */     if (startIndex < 0) {
/* 2643 */       throw new StringIndexOutOfBoundsException(startIndex);
/*      */     }
/* 2645 */     if (endIndex > this.size) {
/* 2646 */       endIndex = this.size;
/*      */     }
/* 2648 */     if (startIndex > endIndex) {
/* 2649 */       throw new StringIndexOutOfBoundsException("end < start");
/*      */     }
/* 2651 */     return endIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void validateIndex(int index) {
/* 2661 */     if (index < 0 || index > this.size) {
/* 2662 */       throw new StringIndexOutOfBoundsException(index);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class StrBuilderTokenizer
/*      */     extends StrTokenizer
/*      */   {
/*      */     protected List<String> tokenize(char[] chars, int offset, int count) {
/* 2682 */       if (chars == null) {
/* 2683 */         return super.tokenize(StrBuilder.this.buffer, 0, StrBuilder.this.size());
/*      */       }
/* 2685 */       return super.tokenize(chars, offset, count);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getContent() {
/* 2692 */       String str = super.getContent();
/* 2693 */       if (str == null) {
/* 2694 */         return StrBuilder.this.toString();
/*      */       }
/* 2696 */       return str;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class StrBuilderReader
/*      */     extends Reader
/*      */   {
/*      */     private int pos;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int mark;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int read() {
/* 2727 */       if (!ready()) {
/* 2728 */         return -1;
/*      */       }
/* 2730 */       return StrBuilder.this.charAt(this.pos++);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public int read(char[] b, int off, int len) {
/* 2736 */       if (off < 0 || len < 0 || off > b.length || off + len > b.length || off + len < 0)
/*      */       {
/* 2738 */         throw new IndexOutOfBoundsException();
/*      */       }
/* 2740 */       if (len == 0) {
/* 2741 */         return 0;
/*      */       }
/* 2743 */       if (this.pos >= StrBuilder.this.size()) {
/* 2744 */         return -1;
/*      */       }
/* 2746 */       if (this.pos + len > StrBuilder.this.size()) {
/* 2747 */         len = StrBuilder.this.size() - this.pos;
/*      */       }
/* 2749 */       StrBuilder.this.getChars(this.pos, this.pos + len, b, off);
/* 2750 */       this.pos += len;
/* 2751 */       return len;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public long skip(long n) {
/* 2757 */       if (this.pos + n > StrBuilder.this.size()) {
/* 2758 */         n = (StrBuilder.this.size() - this.pos);
/*      */       }
/* 2760 */       if (n < 0L) {
/* 2761 */         return 0L;
/*      */       }
/* 2763 */       this.pos = (int)(this.pos + n);
/* 2764 */       return n;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2770 */     public boolean ready() { return (this.pos < StrBuilder.this.size()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2776 */     public boolean markSupported() { return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2782 */     public void mark(int readAheadLimit) { this.mark = this.pos; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2788 */     public void reset() { this.pos = this.mark; }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class StrBuilderWriter
/*      */     extends Writer
/*      */   {
/*      */     public void close() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void flush() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2820 */     public void write(int c) { StrBuilder.this.append((char)c); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2826 */     public void write(char[] cbuf) { StrBuilder.this.append(cbuf); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2832 */     public void write(char[] cbuf, int off, int len) { StrBuilder.this.append(cbuf, off, len); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2838 */     public void write(String str) { StrBuilder.this.append(str); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2844 */     public void write(String str, int off, int len) { StrBuilder.this.append(str, off, len); }
/*      */   }
/*      */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\text\StrBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */