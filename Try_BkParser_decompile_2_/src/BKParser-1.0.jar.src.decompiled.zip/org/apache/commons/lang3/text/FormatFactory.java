package org.apache.commons.lang3.text;

import java.text.Format;
import java.util.Locale;

public interface FormatFactory {
  Format getFormat(String paramString1, String paramString2, Locale paramLocale);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\text\FormatFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */