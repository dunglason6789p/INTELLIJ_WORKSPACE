/*     */ package org.apache.commons.lang3.text.translate;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CharSequenceTranslator
/*     */ {
/*     */   public abstract int translate(CharSequence paramCharSequence, int paramInt, Writer paramWriter) throws IOException;
/*     */   
/*     */   public final String translate(CharSequence input) {
/*  54 */     if (input == null) {
/*  55 */       return null;
/*     */     }
/*     */     try {
/*  58 */       StringWriter writer = new StringWriter(input.length() * 2);
/*  59 */       translate(input, writer);
/*  60 */       return writer.toString();
/*  61 */     } catch (IOException ioe) {
/*     */       
/*  63 */       throw new RuntimeException(ioe);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void translate(CharSequence input, Writer out) throws IOException {
/*  76 */     if (out == null) {
/*  77 */       throw new IllegalArgumentException("The Writer must not be null");
/*     */     }
/*  79 */     if (input == null) {
/*     */       return;
/*     */     }
/*  82 */     int sz = Character.codePointCount(input, 0, input.length());
/*  83 */     for (int i = 0; i < sz; i++) {
/*     */ 
/*     */       
/*  86 */       int consumed = translate(input, i, out);
/*     */       
/*  88 */       if (consumed == 0) {
/*  89 */         out.write(Character.toChars(Character.codePointAt(input, i)));
/*     */       }
/*     */       else {
/*     */         
/*  93 */         for (int j = 0; j < consumed; j++) {
/*  94 */           if (i < sz - 2) {
/*  95 */             i += Character.charCount(Character.codePointAt(input, i));
/*     */           } else {
/*     */             
/*  98 */             i++;
/*     */           } 
/*     */         } 
/*     */         
/* 102 */         i--;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final CharSequenceTranslator with(CharSequenceTranslator... translators) {
/* 115 */     CharSequenceTranslator[] newArray = new CharSequenceTranslator[translators.length + 1];
/* 116 */     newArray[0] = this;
/* 117 */     System.arraycopy(translators, 0, newArray, 1, translators.length);
/* 118 */     return new AggregateTranslator(newArray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public static String hex(int codepoint) { return Integer.toHexString(codepoint).toUpperCase(Locale.ENGLISH); }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\text\translate\CharSequenceTranslator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */