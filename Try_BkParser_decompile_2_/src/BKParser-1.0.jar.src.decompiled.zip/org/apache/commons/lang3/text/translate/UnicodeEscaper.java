/*     */ package org.apache.commons.lang3.text.translate;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnicodeEscaper
/*     */   extends CodePointTranslator
/*     */ {
/*     */   private final int below;
/*     */   private final int above;
/*     */   private final boolean between;
/*     */   
/*  38 */   public UnicodeEscaper() { this(0, 2147483647, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UnicodeEscaper(int below, int above, boolean between) {
/*  52 */     this.below = below;
/*  53 */     this.above = above;
/*  54 */     this.between = between;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static UnicodeEscaper below(int codepoint) { return outsideOf(codepoint, 2147483647); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static UnicodeEscaper above(int codepoint) { return outsideOf(0, codepoint); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static UnicodeEscaper outsideOf(int codepointLow, int codepointHigh) { return new UnicodeEscaper(codepointLow, codepointHigh, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static UnicodeEscaper between(int codepointLow, int codepointHigh) { return new UnicodeEscaper(codepointLow, codepointHigh, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean translate(int codepoint, Writer out) throws IOException {
/* 104 */     if (this.between) {
/* 105 */       if (codepoint < this.below || codepoint > this.above) {
/* 106 */         return false;
/*     */       }
/*     */     }
/* 109 */     else if (codepoint >= this.below && codepoint <= this.above) {
/* 110 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 115 */     if (codepoint > 65535) {
/*     */ 
/*     */       
/* 118 */       out.write("\\u" + hex(codepoint));
/* 119 */     } else if (codepoint > 4095) {
/* 120 */       out.write("\\u" + hex(codepoint));
/* 121 */     } else if (codepoint > 255) {
/* 122 */       out.write("\\u0" + hex(codepoint));
/* 123 */     } else if (codepoint > 15) {
/* 124 */       out.write("\\u00" + hex(codepoint));
/*     */     } else {
/* 126 */       out.write("\\u000" + hex(codepoint));
/*     */     } 
/* 128 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\text\translate\UnicodeEscaper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */