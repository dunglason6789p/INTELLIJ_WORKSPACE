/*     */ package org.apache.commons.lang3.text.translate;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumericEntityEscaper
/*     */   extends CodePointTranslator
/*     */ {
/*     */   private final int below;
/*     */   private final int above;
/*     */   private final boolean between;
/*     */   
/*     */   private NumericEntityEscaper(int below, int above, boolean between) {
/*  45 */     this.below = below;
/*  46 */     this.above = above;
/*  47 */     this.between = between;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public NumericEntityEscaper() { this(0, 2147483647, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static NumericEntityEscaper below(int codepoint) { return outsideOf(codepoint, 2147483647); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public static NumericEntityEscaper above(int codepoint) { return outsideOf(0, codepoint); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public static NumericEntityEscaper between(int codepointLow, int codepointHigh) { return new NumericEntityEscaper(codepointLow, codepointHigh, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static NumericEntityEscaper outsideOf(int codepointLow, int codepointHigh) { return new NumericEntityEscaper(codepointLow, codepointHigh, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean translate(int codepoint, Writer out) throws IOException {
/* 104 */     if (this.between) {
/* 105 */       if (codepoint < this.below || codepoint > this.above) {
/* 106 */         return false;
/*     */       }
/*     */     }
/* 109 */     else if (codepoint >= this.below && codepoint <= this.above) {
/* 110 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 114 */     out.write("&#");
/* 115 */     out.write(Integer.toString(codepoint, 10));
/* 116 */     out.write(59);
/* 117 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\text\translate\NumericEntityEscaper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */