/*      */ package org.apache.commons.lang3;
/*      */ 
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ClassUtils
/*      */ {
/*      */   public static final char PACKAGE_SEPARATOR_CHAR = '.';
/*   53 */   public static final String PACKAGE_SEPARATOR = String.valueOf('.');
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char INNER_CLASS_SEPARATOR_CHAR = '$';
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   63 */   public static final String INNER_CLASS_SEPARATOR = String.valueOf('$');
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   68 */   private static final Map<Class<?>, Class<?>> primitiveWrapperMap = new HashMap();
/*      */   static  {
/*   70 */     primitiveWrapperMap.put(boolean.class, Boolean.class);
/*   71 */     primitiveWrapperMap.put(byte.class, Byte.class);
/*   72 */     primitiveWrapperMap.put(char.class, Character.class);
/*   73 */     primitiveWrapperMap.put(short.class, Short.class);
/*   74 */     primitiveWrapperMap.put(int.class, Integer.class);
/*   75 */     primitiveWrapperMap.put(long.class, Long.class);
/*   76 */     primitiveWrapperMap.put(double.class, Double.class);
/*   77 */     primitiveWrapperMap.put(float.class, Float.class);
/*   78 */     primitiveWrapperMap.put(void.class, void.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   84 */     wrapperPrimitiveMap = new HashMap();
/*      */     
/*   86 */     for (Class<?> primitiveClass : primitiveWrapperMap.keySet()) {
/*   87 */       Class<?> wrapperClass = (Class)primitiveWrapperMap.get(primitiveClass);
/*   88 */       if (!primitiveClass.equals(wrapperClass)) {
/*   89 */         wrapperPrimitiveMap.put(wrapperClass, primitiveClass);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   97 */     abbreviationMap = new HashMap();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  102 */     reverseAbbreviationMap = new HashMap();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  119 */     addAbbreviation("int", "I");
/*  120 */     addAbbreviation("boolean", "Z");
/*  121 */     addAbbreviation("float", "F");
/*  122 */     addAbbreviation("long", "J");
/*  123 */     addAbbreviation("short", "S");
/*  124 */     addAbbreviation("byte", "B");
/*  125 */     addAbbreviation("double", "D");
/*  126 */     addAbbreviation("char", "C");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Map<Class<?>, Class<?>> wrapperPrimitiveMap;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Map<String, String> abbreviationMap;
/*      */ 
/*      */   
/*      */   private static final Map<String, String> reverseAbbreviationMap;
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addAbbreviation(String primitive, String abbreviation) {
/*      */     abbreviationMap.put(primitive, abbreviation);
/*      */     reverseAbbreviationMap.put(abbreviation, primitive);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getShortClassName(Object object, String valueIfNull) {
/*  151 */     if (object == null) {
/*  152 */       return valueIfNull;
/*      */     }
/*  154 */     return getShortClassName(object.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getShortClassName(Class<?> cls) {
/*  168 */     if (cls == null) {
/*  169 */       return "";
/*      */     }
/*  171 */     return getShortClassName(cls.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getShortClassName(String className) {
/*  187 */     if (className == null) {
/*  188 */       return "";
/*      */     }
/*  190 */     if (className.length() == 0) {
/*  191 */       return "";
/*      */     }
/*      */     
/*  194 */     StringBuilder arrayPrefix = new StringBuilder();
/*      */ 
/*      */     
/*  197 */     if (className.startsWith("[")) {
/*  198 */       while (className.charAt(0) == '[') {
/*  199 */         className = className.substring(1);
/*  200 */         arrayPrefix.append("[]");
/*      */       } 
/*      */       
/*  203 */       if (className.charAt(0) == 'L' && className.charAt(className.length() - 1) == ';') {
/*  204 */         className = className.substring(1, className.length() - 1);
/*      */       }
/*      */     } 
/*      */     
/*  208 */     if (reverseAbbreviationMap.containsKey(className)) {
/*  209 */       className = (String)reverseAbbreviationMap.get(className);
/*      */     }
/*      */     
/*  212 */     int lastDotIdx = className.lastIndexOf('.');
/*  213 */     int innerIdx = className.indexOf('$', (lastDotIdx == -1) ? 0 : (lastDotIdx + 1));
/*      */     
/*  215 */     String out = className.substring(lastDotIdx + 1);
/*  216 */     if (innerIdx != -1) {
/*  217 */       out = out.replace('$', '.');
/*      */     }
/*  219 */     return out + arrayPrefix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSimpleName(Class<?> cls) {
/*  231 */     if (cls == null) {
/*  232 */       return "";
/*      */     }
/*  234 */     return cls.getSimpleName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getSimpleName(Object object, String valueIfNull) {
/*  247 */     if (object == null) {
/*  248 */       return valueIfNull;
/*      */     }
/*  250 */     return getSimpleName(object.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPackageName(Object object, String valueIfNull) {
/*  263 */     if (object == null) {
/*  264 */       return valueIfNull;
/*      */     }
/*  266 */     return getPackageName(object.getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPackageName(Class<?> cls) {
/*  276 */     if (cls == null) {
/*  277 */       return "";
/*      */     }
/*  279 */     return getPackageName(cls.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPackageName(String className) {
/*  292 */     if (className == null || className.length() == 0) {
/*  293 */       return "";
/*      */     }
/*      */ 
/*      */     
/*  297 */     while (className.charAt(0) == '[') {
/*  298 */       className = className.substring(1);
/*      */     }
/*      */     
/*  301 */     if (className.charAt(0) == 'L' && className.charAt(className.length() - 1) == ';') {
/*  302 */       className = className.substring(1);
/*      */     }
/*      */     
/*  305 */     int i = className.lastIndexOf('.');
/*  306 */     if (i == -1) {
/*  307 */       return "";
/*      */     }
/*  309 */     return className.substring(0, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Class<?>> getAllSuperclasses(Class<?> cls) {
/*  322 */     if (cls == null) {
/*  323 */       return null;
/*      */     }
/*  325 */     List<Class<?>> classes = new ArrayList<Class<?>>();
/*  326 */     Class<?> superclass = cls.getSuperclass();
/*  327 */     while (superclass != null) {
/*  328 */       classes.add(superclass);
/*  329 */       superclass = superclass.getSuperclass();
/*      */     } 
/*  331 */     return classes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Class<?>> getAllInterfaces(Class<?> cls) {
/*  348 */     if (cls == null) {
/*  349 */       return null;
/*      */     }
/*      */     
/*  352 */     LinkedHashSet<Class<?>> interfacesFound = new LinkedHashSet<Class<?>>();
/*  353 */     getAllInterfaces(cls, interfacesFound);
/*      */     
/*  355 */     return new ArrayList(interfacesFound);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void getAllInterfaces(Class<?> cls, HashSet<Class<?>> interfacesFound) {
/*  365 */     while (cls != null) {
/*  366 */       Class[] interfaces = cls.getInterfaces();
/*      */       
/*  368 */       for (Class<?> i : interfaces) {
/*  369 */         if (interfacesFound.add(i)) {
/*  370 */           getAllInterfaces(i, interfacesFound);
/*      */         }
/*      */       } 
/*      */       
/*  374 */       cls = cls.getSuperclass();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<Class<?>> convertClassNamesToClasses(List<String> classNames) {
/*  393 */     if (classNames == null) {
/*  394 */       return null;
/*      */     }
/*  396 */     List<Class<?>> classes = new ArrayList<Class<?>>(classNames.size());
/*  397 */     for (String className : classNames) {
/*      */       try {
/*  399 */         classes.add(Class.forName(className));
/*  400 */       } catch (Exception ex) {
/*  401 */         classes.add(null);
/*      */       } 
/*      */     } 
/*  404 */     return classes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> convertClassesToClassNames(List<Class<?>> classes) {
/*  420 */     if (classes == null) {
/*  421 */       return null;
/*      */     }
/*  423 */     List<String> classNames = new ArrayList<String>(classes.size());
/*  424 */     for (Class<?> cls : classes) {
/*  425 */       if (cls == null) {
/*  426 */         classNames.add(null); continue;
/*      */       } 
/*  428 */       classNames.add(cls.getName());
/*      */     } 
/*      */     
/*  431 */     return classNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  473 */   public static boolean isAssignable(Class[] classArray, Class... toClassArray) { return isAssignable(classArray, toClassArray, SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_1_5)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAssignable(Class[] classArray, Class[] toClassArray, boolean autoboxing) {
/*  509 */     if (!ArrayUtils.isSameLength(classArray, toClassArray)) {
/*  510 */       return false;
/*      */     }
/*  512 */     if (classArray == null) {
/*  513 */       classArray = ArrayUtils.EMPTY_CLASS_ARRAY;
/*      */     }
/*  515 */     if (toClassArray == null) {
/*  516 */       toClassArray = ArrayUtils.EMPTY_CLASS_ARRAY;
/*      */     }
/*  518 */     for (int i = 0; i < classArray.length; i++) {
/*  519 */       if (!isAssignable(classArray[i], toClassArray[i], autoboxing)) {
/*  520 */         return false;
/*      */       }
/*      */     } 
/*  523 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  558 */   public static boolean isAssignable(Class<?> cls, Class<?> toClass) { return isAssignable(cls, toClass, SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_1_5)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isAssignable(Class<?> cls, Class<?> toClass, boolean autoboxing) {
/*  589 */     if (toClass == null) {
/*  590 */       return false;
/*      */     }
/*      */     
/*  593 */     if (cls == null) {
/*  594 */       return !toClass.isPrimitive();
/*      */     }
/*      */     
/*  597 */     if (autoboxing) {
/*  598 */       if (cls.isPrimitive() && !toClass.isPrimitive()) {
/*  599 */         cls = primitiveToWrapper(cls);
/*  600 */         if (cls == null) {
/*  601 */           return false;
/*      */         }
/*      */       } 
/*  604 */       if (toClass.isPrimitive() && !cls.isPrimitive()) {
/*  605 */         cls = wrapperToPrimitive(cls);
/*  606 */         if (cls == null) {
/*  607 */           return false;
/*      */         }
/*      */       } 
/*      */     } 
/*  611 */     if (cls.equals(toClass)) {
/*  612 */       return true;
/*      */     }
/*  614 */     if (cls.isPrimitive()) {
/*  615 */       if (!toClass.isPrimitive()) {
/*  616 */         return false;
/*      */       }
/*  618 */       if (int.class.equals(cls)) {
/*  619 */         return (long.class.equals(toClass) || float.class.equals(toClass) || double.class.equals(toClass));
/*      */       }
/*      */ 
/*      */       
/*  623 */       if (long.class.equals(cls)) {
/*  624 */         return (float.class.equals(toClass) || double.class.equals(toClass));
/*      */       }
/*      */       
/*  627 */       if (boolean.class.equals(cls)) {
/*  628 */         return false;
/*      */       }
/*  630 */       if (double.class.equals(cls)) {
/*  631 */         return false;
/*      */       }
/*  633 */       if (float.class.equals(cls)) {
/*  634 */         return double.class.equals(toClass);
/*      */       }
/*  636 */       if (char.class.equals(cls)) {
/*  637 */         return (int.class.equals(toClass) || long.class.equals(toClass) || float.class.equals(toClass) || double.class.equals(toClass));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  642 */       if (short.class.equals(cls)) {
/*  643 */         return (int.class.equals(toClass) || long.class.equals(toClass) || float.class.equals(toClass) || double.class.equals(toClass));
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  648 */       if (byte.class.equals(cls)) {
/*  649 */         return (short.class.equals(toClass) || int.class.equals(toClass) || long.class.equals(toClass) || float.class.equals(toClass) || double.class.equals(toClass));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  656 */       return false;
/*      */     } 
/*  658 */     return toClass.isAssignableFrom(cls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> primitiveToWrapper(Class<?> cls) {
/*  674 */     Class<?> convertedClass = cls;
/*  675 */     if (cls != null && cls.isPrimitive()) {
/*  676 */       convertedClass = (Class)primitiveWrapperMap.get(cls);
/*      */     }
/*  678 */     return convertedClass;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?>[] primitivesToWrappers(Class... classes) {
/*  692 */     if (classes == null) {
/*  693 */       return null;
/*      */     }
/*      */     
/*  696 */     if (classes.length == 0) {
/*  697 */       return classes;
/*      */     }
/*      */     
/*  700 */     Class[] convertedClasses = new Class[classes.length];
/*  701 */     for (int i = 0; i < classes.length; i++) {
/*  702 */       convertedClasses[i] = primitiveToWrapper(classes[i]);
/*      */     }
/*  704 */     return convertedClasses;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  724 */   public static Class<?> wrapperToPrimitive(Class<?> cls) { return (Class)wrapperPrimitiveMap.get(cls); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?>[] wrappersToPrimitives(Class... classes) {
/*  742 */     if (classes == null) {
/*  743 */       return null;
/*      */     }
/*      */     
/*  746 */     if (classes.length == 0) {
/*  747 */       return classes;
/*      */     }
/*      */     
/*  750 */     Class[] convertedClasses = new Class[classes.length];
/*  751 */     for (int i = 0; i < classes.length; i++) {
/*  752 */       convertedClasses[i] = wrapperToPrimitive(classes[i]);
/*      */     }
/*  754 */     return convertedClasses;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  767 */   public static boolean isInnerClass(Class<?> cls) { return (cls != null && cls.getEnclosingClass() != null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getClass(ClassLoader classLoader, String className, boolean initialize) throws ClassNotFoundException {
/*      */     try {
/*      */       Class<?> clazz;
/*  788 */       if (abbreviationMap.containsKey(className)) {
/*  789 */         String clsName = "[" + (String)abbreviationMap.get(className);
/*  790 */         clazz = Class.forName(clsName, initialize, classLoader).getComponentType();
/*      */       } else {
/*  792 */         clazz = Class.forName(toCanonicalName(className), initialize, classLoader);
/*      */       } 
/*  794 */       return clazz;
/*  795 */     } catch (ClassNotFoundException ex) {
/*      */       
/*  797 */       int lastDotIndex = className.lastIndexOf('.');
/*      */       
/*  799 */       if (lastDotIndex != -1) {
/*      */         try {
/*  801 */           return getClass(classLoader, className.substring(0, lastDotIndex) + '$' + className.substring(lastDotIndex + 1), initialize);
/*      */         
/*      */         }
/*  804 */         catch (ClassNotFoundException ex2) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  809 */       throw ex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  826 */   public static Class<?> getClass(ClassLoader classLoader, String className) throws ClassNotFoundException { return getClass(classLoader, className, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  841 */   public static Class<?> getClass(String className) throws ClassNotFoundException { return getClass(className, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?> getClass(String className, boolean initialize) throws ClassNotFoundException {
/*  856 */     ClassLoader contextCL = Thread.currentThread().getContextClassLoader();
/*  857 */     ClassLoader loader = (contextCL == null) ? ClassUtils.class.getClassLoader() : contextCL;
/*  858 */     return getClass(loader, className, initialize);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Method getPublicMethod(Class<?> cls, String methodName, Class... parameterTypes) throws SecurityException, NoSuchMethodException {
/*  887 */     Method declaredMethod = cls.getMethod(methodName, parameterTypes);
/*  888 */     if (Modifier.isPublic(declaredMethod.getDeclaringClass().getModifiers())) {
/*  889 */       return declaredMethod;
/*      */     }
/*      */     
/*  892 */     List<Class<?>> candidateClasses = new ArrayList<Class<?>>();
/*  893 */     candidateClasses.addAll(getAllInterfaces(cls));
/*  894 */     candidateClasses.addAll(getAllSuperclasses(cls));
/*      */     
/*  896 */     for (Class<?> candidateClass : candidateClasses) {
/*  897 */       Method candidateMethod; if (!Modifier.isPublic(candidateClass.getModifiers())) {
/*      */         continue;
/*      */       }
/*      */       
/*      */       try {
/*  902 */         candidateMethod = candidateClass.getMethod(methodName, parameterTypes);
/*  903 */       } catch (NoSuchMethodException ex) {
/*      */         continue;
/*      */       } 
/*  906 */       if (Modifier.isPublic(candidateMethod.getDeclaringClass().getModifiers())) {
/*  907 */         return candidateMethod;
/*      */       }
/*      */     } 
/*      */     
/*  911 */     throw new NoSuchMethodException("Can't find a public method for " + methodName + " " + ArrayUtils.toString(parameterTypes));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String toCanonicalName(String className) {
/*  923 */     className = StringUtils.deleteWhitespace(className);
/*  924 */     if (className == null)
/*  925 */       throw new NullPointerException("className must not be null."); 
/*  926 */     if (className.endsWith("[]")) {
/*  927 */       StringBuilder classNameBuffer = new StringBuilder();
/*  928 */       while (className.endsWith("[]")) {
/*  929 */         className = className.substring(0, className.length() - 2);
/*  930 */         classNameBuffer.append("[");
/*      */       } 
/*  932 */       String abbreviation = (String)abbreviationMap.get(className);
/*  933 */       if (abbreviation != null) {
/*  934 */         classNameBuffer.append(abbreviation);
/*      */       } else {
/*  936 */         classNameBuffer.append("L").append(className).append(";");
/*      */       } 
/*  938 */       className = classNameBuffer.toString();
/*      */     } 
/*  940 */     return className;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class<?>[] toClass(Object... array) {
/*  954 */     if (array == null)
/*  955 */       return null; 
/*  956 */     if (array.length == 0) {
/*  957 */       return ArrayUtils.EMPTY_CLASS_ARRAY;
/*      */     }
/*  959 */     Class[] classes = new Class[array.length];
/*  960 */     for (int i = 0; i < array.length; i++) {
/*  961 */       classes[i] = (array[i] == null) ? null : array[i].getClass();
/*      */     }
/*  963 */     return classes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getShortCanonicalName(Object object, String valueIfNull) {
/*  977 */     if (object == null) {
/*  978 */       return valueIfNull;
/*      */     }
/*  980 */     return getShortCanonicalName(object.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getShortCanonicalName(Class<?> cls) {
/*  991 */     if (cls == null) {
/*  992 */       return "";
/*      */     }
/*  994 */     return getShortCanonicalName(cls.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1007 */   public static String getShortCanonicalName(String canonicalName) { return getShortClassName(getCanonicalName(canonicalName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPackageCanonicalName(Object object, String valueIfNull) {
/* 1021 */     if (object == null) {
/* 1022 */       return valueIfNull;
/*      */     }
/* 1024 */     return getPackageCanonicalName(object.getClass().getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getPackageCanonicalName(Class<?> cls) {
/* 1035 */     if (cls == null) {
/* 1036 */       return "";
/*      */     }
/* 1038 */     return getPackageCanonicalName(cls.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1052 */   public static String getPackageCanonicalName(String canonicalName) { return getPackageName(getCanonicalName(canonicalName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getCanonicalName(String className) {
/* 1072 */     className = StringUtils.deleteWhitespace(className);
/* 1073 */     if (className == null) {
/* 1074 */       return null;
/*      */     }
/* 1076 */     int dim = 0;
/* 1077 */     while (className.startsWith("[")) {
/* 1078 */       dim++;
/* 1079 */       className = className.substring(1);
/*      */     } 
/* 1081 */     if (dim < 1) {
/* 1082 */       return className;
/*      */     }
/* 1084 */     if (className.startsWith("L")) {
/* 1085 */       className = className.substring(1, className.endsWith(";") ? (className.length() - 1) : className.length());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1091 */     else if (className.length() > 0) {
/* 1092 */       className = (String)reverseAbbreviationMap.get(className.substring(0, 1));
/*      */     } 
/*      */     
/* 1095 */     StringBuilder canonicalClassNameBuffer = new StringBuilder(className);
/* 1096 */     for (int i = 0; i < dim; i++) {
/* 1097 */       canonicalClassNameBuffer.append("[]");
/*      */     }
/* 1099 */     return canonicalClassNameBuffer.toString();
/*      */   }
/*      */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\ClassUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */