package org.apache.commons.lang3.mutable;

public interface Mutable<T> {
  T getValue();
  
  void setValue(T paramT);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\mutable\Mutable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */