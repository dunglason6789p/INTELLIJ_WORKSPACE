/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Range<T>
/*     */   extends Object
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final Comparator<T> comparator;
/*     */   private final T minimum;
/*     */   private final T maximum;
/*     */   private int hashCode;
/*     */   private String toString;
/*     */   
/*  76 */   public static <T extends Comparable<T>> Range<T> is(T element) { return between(element, element, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public static <T> Range<T> is(T element, Comparator<T> comparator) { return between(element, element, comparator); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public static <T extends Comparable<T>> Range<T> between(T fromInclusive, T toInclusive) { return between(fromInclusive, toInclusive, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public static <T> Range<T> between(T fromInclusive, T toInclusive, Comparator<T> comparator) { return new Range(fromInclusive, toInclusive, comparator); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Range(T element1, T element2, Comparator<T> comparator) {
/* 147 */     if (element1 == null || element2 == null) {
/* 148 */       throw new IllegalArgumentException("Elements in a range must not be null: element1=" + element1 + ", element2=" + element2);
/*     */     }
/*     */     
/* 151 */     if (comparator == null) {
/* 152 */       comparator = ComparableComparator.INSTANCE;
/*     */     }
/* 154 */     if (comparator.compare(element1, element2) < 1) {
/* 155 */       this.minimum = element1;
/* 156 */       this.maximum = element2;
/*     */     } else {
/* 158 */       this.minimum = element2;
/* 159 */       this.maximum = element1;
/*     */     } 
/* 161 */     this.comparator = comparator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public T getMinimum() { return (T)this.minimum; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public T getMaximum() { return (T)this.maximum; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public Comparator<T> getComparator() { return this.comparator; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public boolean isNaturalOrdering() { return (this.comparator == ComparableComparator.INSTANCE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(T element) {
/* 219 */     if (element == null) {
/* 220 */       return false;
/*     */     }
/* 222 */     return (this.comparator.compare(element, this.minimum) > -1 && this.comparator.compare(element, this.maximum) < 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAfter(T element) {
/* 232 */     if (element == null) {
/* 233 */       return false;
/*     */     }
/* 235 */     return (this.comparator.compare(element, this.minimum) < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isStartedBy(T element) {
/* 245 */     if (element == null) {
/* 246 */       return false;
/*     */     }
/* 248 */     return (this.comparator.compare(element, this.minimum) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEndedBy(T element) {
/* 258 */     if (element == null) {
/* 259 */       return false;
/*     */     }
/* 261 */     return (this.comparator.compare(element, this.maximum) == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBefore(T element) {
/* 271 */     if (element == null) {
/* 272 */       return false;
/*     */     }
/* 274 */     return (this.comparator.compare(element, this.maximum) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int elementCompareTo(T element) {
/* 288 */     if (element == null)
/*     */     {
/* 290 */       throw new NullPointerException("Element is null");
/*     */     }
/* 292 */     if (isAfter(element))
/* 293 */       return -1; 
/* 294 */     if (isBefore(element)) {
/* 295 */       return 1;
/*     */     }
/* 297 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsRange(Range<T> otherRange) {
/* 314 */     if (otherRange == null) {
/* 315 */       return false;
/*     */     }
/* 317 */     return (contains(otherRange.minimum) && contains(otherRange.maximum));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAfterRange(Range<T> otherRange) {
/* 331 */     if (otherRange == null) {
/* 332 */       return false;
/*     */     }
/* 334 */     return isAfter(otherRange.maximum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isOverlappedBy(Range<T> otherRange) {
/* 350 */     if (otherRange == null) {
/* 351 */       return false;
/*     */     }
/* 353 */     return (otherRange.contains(this.minimum) || otherRange.contains(this.maximum) || contains(otherRange.minimum));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBeforeRange(Range<T> otherRange) {
/* 368 */     if (otherRange == null) {
/* 369 */       return false;
/*     */     }
/* 371 */     return isBefore(otherRange.minimum);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 388 */     if (obj == this)
/* 389 */       return true; 
/* 390 */     if (obj == null || obj.getClass() != getClass()) {
/* 391 */       return false;
/*     */     }
/*     */     
/* 394 */     Range<T> range = (Range)obj;
/* 395 */     return (this.minimum.equals(range.minimum) && this.maximum.equals(range.maximum));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 407 */     int result = this.hashCode;
/* 408 */     if (this.hashCode == 0) {
/* 409 */       result = 17;
/* 410 */       result = 37 * result + getClass().hashCode();
/* 411 */       result = 37 * result + this.minimum.hashCode();
/* 412 */       result = 37 * result + this.maximum.hashCode();
/* 413 */       this.hashCode = result;
/*     */     } 
/* 415 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 427 */     String result = this.toString;
/* 428 */     if (result == null) {
/* 429 */       StringBuilder buf = new StringBuilder(32);
/* 430 */       buf.append('[');
/* 431 */       buf.append(this.minimum);
/* 432 */       buf.append("..");
/* 433 */       buf.append(this.maximum);
/* 434 */       buf.append(']');
/* 435 */       result = buf.toString();
/* 436 */       this.toString = result;
/*     */     } 
/* 438 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 454 */   public String toString(String format) { return String.format(format, new Object[] { this.minimum, this.maximum, this.comparator }); }
/*     */ 
/*     */   
/*     */   private enum ComparableComparator
/*     */     implements Comparator
/*     */   {
/* 460 */     INSTANCE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     public int compare(Object obj1, Object obj2) { return ((Comparable)obj1).compareTo(obj2); }
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\Range.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */