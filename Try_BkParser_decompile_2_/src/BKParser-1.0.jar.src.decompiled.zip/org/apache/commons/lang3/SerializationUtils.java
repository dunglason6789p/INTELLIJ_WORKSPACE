/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerializationUtils
/*     */ {
/*  82 */   public static <T extends Serializable> T clone(T object) { return (T)(Serializable)deserialize(serialize(object)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void serialize(Serializable obj, OutputStream outputStream) {
/* 104 */     if (outputStream == null) {
/* 105 */       throw new IllegalArgumentException("The OutputStream must not be null");
/*     */     }
/* 107 */     out = null;
/*     */     
/*     */     try {
/* 110 */       out = new ObjectOutputStream(outputStream);
/* 111 */       out.writeObject(obj);
/*     */     }
/* 113 */     catch (IOException ex) {
/* 114 */       throw new SerializationException(ex);
/*     */     } finally {
/*     */       try {
/* 117 */         if (out != null) {
/* 118 */           out.close();
/*     */         }
/* 120 */       } catch (IOException ex) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] serialize(Serializable obj) {
/* 135 */     ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
/* 136 */     serialize(obj, baos);
/* 137 */     return baos.toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object deserialize(InputStream inputStream) {
/* 158 */     if (inputStream == null) {
/* 159 */       throw new IllegalArgumentException("The InputStream must not be null");
/*     */     }
/* 161 */     in = null;
/*     */     
/*     */     try {
/* 164 */       in = new ObjectInputStream(inputStream);
/* 165 */       return in.readObject();
/*     */     }
/* 167 */     catch (ClassNotFoundException ex) {
/* 168 */       throw new SerializationException(ex);
/* 169 */     } catch (IOException ex) {
/* 170 */       throw new SerializationException(ex);
/*     */     } finally {
/*     */       try {
/* 173 */         if (in != null) {
/* 174 */           in.close();
/*     */         }
/* 176 */       } catch (IOException ex) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object deserialize(byte[] objectData) {
/* 191 */     if (objectData == null) {
/* 192 */       throw new IllegalArgumentException("The byte[] must not be null");
/*     */     }
/* 194 */     ByteArrayInputStream bais = new ByteArrayInputStream(objectData);
/* 195 */     return deserialize(bais);
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\SerializationUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */