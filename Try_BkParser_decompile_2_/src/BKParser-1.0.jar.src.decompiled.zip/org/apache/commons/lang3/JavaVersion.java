/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public static enum JavaVersion
/*     */ {
/*  31 */   JAVA_0_9(1.5F, "0.9"),
/*  32 */   JAVA_1_1(1.1F, "1.1"),
/*  33 */   JAVA_1_2(1.2F, "1.2"),
/*  34 */   JAVA_1_3(1.3F, "1.3"),
/*  35 */   JAVA_1_4(1.4F, "1.4"),
/*  36 */   JAVA_1_5(1.5F, "1.5"),
/*  37 */   JAVA_1_6(1.6F, "1.6"),
/*  38 */   JAVA_1_7(1.7F, "1.7"),
/*  39 */   JAVA_1_8(1.8F, "1.8");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JavaVersion(float value, String name) {
/*  57 */     this.value = value;
/*  58 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public boolean atLeast(JavaVersion requiredVersion) { return (this.value >= requiredVersion.value); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   static JavaVersion getJavaVersion(String nom) { return get(nom); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static JavaVersion get(String nom) {
/*  99 */     if ("0.9".equals(nom))
/* 100 */       return JAVA_0_9; 
/* 101 */     if ("1.1".equals(nom))
/* 102 */       return JAVA_1_1; 
/* 103 */     if ("1.2".equals(nom))
/* 104 */       return JAVA_1_2; 
/* 105 */     if ("1.3".equals(nom))
/* 106 */       return JAVA_1_3; 
/* 107 */     if ("1.4".equals(nom))
/* 108 */       return JAVA_1_4; 
/* 109 */     if ("1.5".equals(nom))
/* 110 */       return JAVA_1_5; 
/* 111 */     if ("1.6".equals(nom))
/* 112 */       return JAVA_1_6; 
/* 113 */     if ("1.7".equals(nom))
/* 114 */       return JAVA_1_7; 
/* 115 */     if ("1.8".equals(nom)) {
/* 116 */       return JAVA_1_8;
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   public String toString() { return this.name; }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\JavaVersion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */