/*     */ package org.apache.commons.lang3.reflect;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Modifier;
/*     */ import org.apache.commons.lang3.ArrayUtils;
/*     */ import org.apache.commons.lang3.ClassUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConstructorUtils
/*     */ {
/*     */   public static <T> T invokeConstructor(Class<T> cls, Object... args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
/*  81 */     if (args == null) {
/*  82 */       args = ArrayUtils.EMPTY_OBJECT_ARRAY;
/*     */     }
/*  84 */     Class[] parameterTypes = new Class[args.length];
/*  85 */     for (int i = 0; i < args.length; i++) {
/*  86 */       parameterTypes[i] = args[i].getClass();
/*     */     }
/*  88 */     return (T)invokeConstructor(cls, args, parameterTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T invokeConstructor(Class<T> cls, Object[] args, Class[] parameterTypes) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
/* 113 */     if (parameterTypes == null) {
/* 114 */       parameterTypes = ArrayUtils.EMPTY_CLASS_ARRAY;
/*     */     }
/* 116 */     if (args == null) {
/* 117 */       args = ArrayUtils.EMPTY_OBJECT_ARRAY;
/*     */     }
/* 119 */     Constructor<T> ctor = getMatchingAccessibleConstructor(cls, parameterTypes);
/* 120 */     if (ctor == null) {
/* 121 */       throw new NoSuchMethodException("No such accessible constructor on object: " + cls.getName());
/*     */     }
/*     */     
/* 124 */     return (T)ctor.newInstance(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T invokeExactConstructor(Class<T> cls, Object... args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
/* 148 */     if (args == null) {
/* 149 */       args = ArrayUtils.EMPTY_OBJECT_ARRAY;
/*     */     }
/* 151 */     int arguments = args.length;
/* 152 */     Class[] parameterTypes = new Class[arguments];
/* 153 */     for (int i = 0; i < arguments; i++) {
/* 154 */       parameterTypes[i] = args[i].getClass();
/*     */     }
/* 156 */     return (T)invokeExactConstructor(cls, args, parameterTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T invokeExactConstructor(Class<T> cls, Object[] args, Class[] parameterTypes) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
/* 181 */     if (args == null) {
/* 182 */       args = ArrayUtils.EMPTY_OBJECT_ARRAY;
/*     */     }
/* 184 */     if (parameterTypes == null) {
/* 185 */       parameterTypes = ArrayUtils.EMPTY_CLASS_ARRAY;
/*     */     }
/* 187 */     Constructor<T> ctor = getAccessibleConstructor(cls, parameterTypes);
/* 188 */     if (ctor == null) {
/* 189 */       throw new NoSuchMethodException("No such accessible constructor on object: " + cls.getName());
/*     */     }
/*     */     
/* 192 */     return (T)ctor.newInstance(args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Constructor<T> getAccessibleConstructor(Class<T> cls, Class... parameterTypes) {
/*     */     try {
/* 212 */       return getAccessibleConstructor(cls.getConstructor(parameterTypes));
/* 213 */     } catch (NoSuchMethodException e) {
/* 214 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 229 */   public static <T> Constructor<T> getAccessibleConstructor(Constructor<T> ctor) { return (MemberUtils.isAccessible(ctor) && Modifier.isPublic(ctor.getDeclaringClass().getModifiers())) ? ctor : null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Constructor<T> getMatchingAccessibleConstructor(Class<T> cls, Class... parameterTypes) {
/*     */     try {
/* 255 */       Constructor<T> ctor = cls.getConstructor(parameterTypes);
/* 256 */       MemberUtils.setAccessibleWorkaround(ctor);
/* 257 */       return ctor;
/* 258 */     } catch (NoSuchMethodException e) {
/*     */       
/* 260 */       Constructor<T> result = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 265 */       Constructor[] ctors = cls.getConstructors();
/*     */ 
/*     */       
/* 268 */       for (Constructor<?> ctor : ctors) {
/*     */         
/* 270 */         if (ClassUtils.isAssignable(parameterTypes, ctor.getParameterTypes(), true)) {
/*     */           
/* 272 */           ctor = getAccessibleConstructor(ctor);
/* 273 */           if (ctor != null) {
/* 274 */             MemberUtils.setAccessibleWorkaround(ctor);
/* 275 */             if (result == null || MemberUtils.compareParameterTypes(ctor.getParameterTypes(), result.getParameterTypes(), parameterTypes) < 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 280 */               Constructor<T> constructor = ctor;
/* 281 */               result = constructor;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 286 */       return result;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\reflect\ConstructorUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */