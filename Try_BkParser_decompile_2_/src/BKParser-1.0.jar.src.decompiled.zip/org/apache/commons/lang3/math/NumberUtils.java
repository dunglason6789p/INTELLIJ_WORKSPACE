/*      */ package org.apache.commons.lang3.math;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import org.apache.commons.lang3.StringUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class NumberUtils
/*      */ {
/*   33 */   public static final Long LONG_ZERO = new Long(0L);
/*      */   
/*   35 */   public static final Long LONG_ONE = new Long(1L);
/*      */   
/*   37 */   public static final Long LONG_MINUS_ONE = new Long(-1L);
/*      */   
/*   39 */   public static final Integer INTEGER_ZERO = new Integer(0);
/*      */   
/*   41 */   public static final Integer INTEGER_ONE = new Integer(1);
/*      */   
/*   43 */   public static final Integer INTEGER_MINUS_ONE = new Integer(-1);
/*      */   
/*   45 */   public static final Short SHORT_ZERO = new Short((short)0);
/*      */   
/*   47 */   public static final Short SHORT_ONE = new Short((short)1);
/*      */   
/*   49 */   public static final Short SHORT_MINUS_ONE = new Short((short)-1);
/*      */   
/*   51 */   public static final Byte BYTE_ZERO = Byte.valueOf((byte)0);
/*      */   
/*   53 */   public static final Byte BYTE_ONE = Byte.valueOf((byte)1);
/*      */   
/*   55 */   public static final Byte BYTE_MINUS_ONE = Byte.valueOf((byte)-1);
/*      */   
/*   57 */   public static final Double DOUBLE_ZERO = new Double(0.0D);
/*      */   
/*   59 */   public static final Double DOUBLE_ONE = new Double(1.0D);
/*      */   
/*   61 */   public static final Double DOUBLE_MINUS_ONE = new Double(-1.0D);
/*      */   
/*   63 */   public static final Float FLOAT_ZERO = new Float(0.0F);
/*      */   
/*   65 */   public static final Float FLOAT_ONE = new Float(1.0F);
/*      */   
/*   67 */   public static final Float FLOAT_MINUS_ONE = new Float(-1.0F);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   99 */   public static int toInt(String str) { return toInt(str, 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int toInt(String str, int defaultValue) {
/*  120 */     if (str == null) {
/*  121 */       return defaultValue;
/*      */     }
/*      */     try {
/*  124 */       return Integer.parseInt(str);
/*  125 */     } catch (NumberFormatException nfe) {
/*  126 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  148 */   public static long toLong(String str) { return toLong(str, 0L); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long toLong(String str, long defaultValue) {
/*  169 */     if (str == null) {
/*  170 */       return defaultValue;
/*      */     }
/*      */     try {
/*  173 */       return Long.parseLong(str);
/*  174 */     } catch (NumberFormatException nfe) {
/*  175 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  198 */   public static float toFloat(String str) { return toFloat(str, 0.0F); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float toFloat(String str, float defaultValue) {
/*  221 */     if (str == null) {
/*  222 */       return defaultValue;
/*      */     }
/*      */     try {
/*  225 */       return Float.parseFloat(str);
/*  226 */     } catch (NumberFormatException nfe) {
/*  227 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  250 */   public static double toDouble(String str) { return toDouble(str, 0.0D); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double toDouble(String str, double defaultValue) {
/*  273 */     if (str == null) {
/*  274 */       return defaultValue;
/*      */     }
/*      */     try {
/*  277 */       return Double.parseDouble(str);
/*  278 */     } catch (NumberFormatException nfe) {
/*  279 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  302 */   public static byte toByte(String str) { return toByte(str, (byte)0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte toByte(String str, byte defaultValue) {
/*  323 */     if (str == null) {
/*  324 */       return defaultValue;
/*      */     }
/*      */     try {
/*  327 */       return Byte.parseByte(str);
/*  328 */     } catch (NumberFormatException nfe) {
/*  329 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  351 */   public static short toShort(String str) { return toShort(str, (short)0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short toShort(String str, short defaultValue) {
/*  372 */     if (str == null) {
/*  373 */       return defaultValue;
/*      */     }
/*      */     try {
/*  376 */       return Short.parseShort(str);
/*  377 */     } catch (NumberFormatException nfe) {
/*  378 */       return defaultValue;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Number createNumber(String str) throws NumberFormatException {
/*      */     String exp, dec, mant;
/*  445 */     if (str == null) {
/*  446 */       return null;
/*      */     }
/*  448 */     if (StringUtils.isBlank(str)) {
/*  449 */       throw new NumberFormatException("A blank string is not a valid number");
/*      */     }
/*  451 */     if (str.startsWith("--"))
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  456 */       return null;
/*      */     }
/*  458 */     if (str.startsWith("0x") || str.startsWith("-0x")) {
/*  459 */       return createInteger(str);
/*      */     }
/*  461 */     char lastChar = str.charAt(str.length() - 1);
/*      */ 
/*      */ 
/*      */     
/*  465 */     int decPos = str.indexOf('.');
/*  466 */     int expPos = str.indexOf('e') + str.indexOf('E') + 1;
/*      */     
/*  468 */     if (decPos > -1) {
/*      */       
/*  470 */       if (expPos > -1) {
/*  471 */         if (expPos < decPos || expPos > str.length()) {
/*  472 */           throw new NumberFormatException(str + " is not a valid number.");
/*      */         }
/*  474 */         dec = str.substring(decPos + 1, expPos);
/*      */       } else {
/*  476 */         dec = str.substring(decPos + 1);
/*      */       } 
/*  478 */       mant = str.substring(0, decPos);
/*      */     } else {
/*  480 */       if (expPos > -1) {
/*  481 */         if (expPos > str.length()) {
/*  482 */           throw new NumberFormatException(str + " is not a valid number.");
/*      */         }
/*  484 */         mant = str.substring(0, expPos);
/*      */       } else {
/*  486 */         mant = str;
/*      */       } 
/*  488 */       dec = null;
/*      */     } 
/*  490 */     if (!Character.isDigit(lastChar) && lastChar != '.') {
/*  491 */       if (expPos > -1 && expPos < str.length() - 1) {
/*  492 */         exp = str.substring(expPos + 1, str.length() - 1);
/*      */       } else {
/*  494 */         exp = null;
/*      */       } 
/*      */       
/*  497 */       String numeric = str.substring(0, str.length() - 1);
/*  498 */       boolean allZeros = (isAllZeros(mant) && isAllZeros(exp));
/*  499 */       switch (lastChar) {
/*      */         case 'L':
/*      */         case 'l':
/*  502 */           if (dec == null && exp == null && ((numeric.charAt(0) == '-' && isDigits(numeric.substring(1))) || isDigits(numeric))) {
/*      */             
/*      */             try {
/*      */               
/*  506 */               return createLong(numeric);
/*  507 */             } catch (NumberFormatException nfe) {
/*      */ 
/*      */               
/*  510 */               return createBigInteger(numeric);
/*      */             } 
/*      */           }
/*  513 */           throw new NumberFormatException(str + " is not a valid number.");
/*      */         case 'F':
/*      */         case 'f':
/*      */           try {
/*  517 */             Float f = createFloat(numeric);
/*  518 */             if (!f.isInfinite() && (f.floatValue() != 0.0F || allZeros))
/*      */             {
/*      */               
/*  521 */               return f;
/*      */             }
/*      */           }
/*  524 */           catch (NumberFormatException nfe) {}
/*      */ 
/*      */ 
/*      */         
/*      */         case 'D':
/*      */         case 'd':
/*      */           try {
/*  531 */             Double d = createDouble(numeric);
/*  532 */             if (!d.isInfinite() && (d.floatValue() != 0.0D || allZeros)) {
/*  533 */               return d;
/*      */             }
/*  535 */           } catch (NumberFormatException nfe) {}
/*      */ 
/*      */           
/*      */           try {
/*  539 */             return createBigDecimal(numeric);
/*  540 */           } catch (NumberFormatException e) {
/*      */             break;
/*      */           } 
/*      */       } 
/*      */       
/*  545 */       throw new NumberFormatException(str + " is not a valid number.");
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  551 */     if (expPos > -1 && expPos < str.length() - 1) {
/*  552 */       exp = str.substring(expPos + 1, str.length());
/*      */     } else {
/*  554 */       exp = null;
/*      */     } 
/*  556 */     if (dec == null && exp == null) {
/*      */       
/*      */       try {
/*  559 */         return createInteger(str);
/*  560 */       } catch (NumberFormatException nfe) {
/*      */ 
/*      */         
/*      */         try {
/*  564 */           return createLong(str);
/*  565 */         } catch (NumberFormatException nfe) {
/*      */           NumberFormatException nfe;
/*      */           
/*  568 */           return createBigInteger(str);
/*      */         } 
/*      */       } 
/*      */     }
/*  572 */     boolean allZeros = (isAllZeros(mant) && isAllZeros(exp));
/*      */     try {
/*  574 */       Float f = createFloat(str);
/*  575 */       if (!f.isInfinite() && (f.floatValue() != 0.0F || allZeros)) {
/*  576 */         return f;
/*      */       }
/*  578 */     } catch (NumberFormatException nfe) {}
/*      */ 
/*      */     
/*      */     try {
/*  582 */       Double d = createDouble(str);
/*  583 */       if (!d.isInfinite() && (d.doubleValue() != 0.0D || allZeros)) {
/*  584 */         return d;
/*      */       }
/*  586 */     } catch (NumberFormatException nfe) {}
/*      */ 
/*      */ 
/*      */     
/*  590 */     return createBigDecimal(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isAllZeros(String str) {
/*  605 */     if (str == null) {
/*  606 */       return true;
/*      */     }
/*  608 */     for (int i = str.length() - 1; i >= 0; i--) {
/*  609 */       if (str.charAt(i) != '0') {
/*  610 */         return false;
/*      */       }
/*      */     } 
/*  613 */     return (str.length() > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Float createFloat(String str) {
/*  627 */     if (str == null) {
/*  628 */       return null;
/*      */     }
/*  630 */     return Float.valueOf(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Double createDouble(String str) {
/*  643 */     if (str == null) {
/*  644 */       return null;
/*      */     }
/*  646 */     return Double.valueOf(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Integer createInteger(String str) {
/*  660 */     if (str == null) {
/*  661 */       return null;
/*      */     }
/*      */     
/*  664 */     return Integer.decode(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Long createLong(String str) {
/*  677 */     if (str == null) {
/*  678 */       return null;
/*      */     }
/*  680 */     return Long.valueOf(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigInteger createBigInteger(String str) {
/*  693 */     if (str == null) {
/*  694 */       return null;
/*      */     }
/*  696 */     return new BigInteger(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BigDecimal createBigDecimal(String str) {
/*  709 */     if (str == null) {
/*  710 */       return null;
/*      */     }
/*      */     
/*  713 */     if (StringUtils.isBlank(str)) {
/*  714 */       throw new NumberFormatException("A blank string is not a valid number");
/*      */     }
/*  716 */     return new BigDecimal(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long min(long[] array) {
/*  731 */     if (array == null)
/*  732 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  733 */     if (array.length == 0) {
/*  734 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  738 */     long min = array[0];
/*  739 */     for (int i = 1; i < array.length; i++) {
/*  740 */       if (array[i] < min) {
/*  741 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  745 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int min(int[] array) {
/*  758 */     if (array == null)
/*  759 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  760 */     if (array.length == 0) {
/*  761 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  765 */     int min = array[0];
/*  766 */     for (int j = 1; j < array.length; j++) {
/*  767 */       if (array[j] < min) {
/*  768 */         min = array[j];
/*      */       }
/*      */     } 
/*      */     
/*  772 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short min(short[] array) {
/*  785 */     if (array == null)
/*  786 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  787 */     if (array.length == 0) {
/*  788 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  792 */     short min = array[0];
/*  793 */     for (int i = 1; i < array.length; i++) {
/*  794 */       if (array[i] < min) {
/*  795 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  799 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte min(byte[] array) {
/*  812 */     if (array == null)
/*  813 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  814 */     if (array.length == 0) {
/*  815 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  819 */     byte min = array[0];
/*  820 */     for (int i = 1; i < array.length; i++) {
/*  821 */       if (array[i] < min) {
/*  822 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  826 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double min(double[] array) {
/*  840 */     if (array == null)
/*  841 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  842 */     if (array.length == 0) {
/*  843 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  847 */     double min = array[0];
/*  848 */     for (int i = 1; i < array.length; i++) {
/*  849 */       if (Double.isNaN(array[i])) {
/*  850 */         return NaND;
/*      */       }
/*  852 */       if (array[i] < min) {
/*  853 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  857 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float min(float[] array) {
/*  871 */     if (array == null)
/*  872 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  873 */     if (array.length == 0) {
/*  874 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  878 */     float min = array[0];
/*  879 */     for (int i = 1; i < array.length; i++) {
/*  880 */       if (Float.isNaN(array[i])) {
/*  881 */         return NaNF;
/*      */       }
/*  883 */       if (array[i] < min) {
/*  884 */         min = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  888 */     return min;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long max(long[] array) {
/*  903 */     if (array == null)
/*  904 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  905 */     if (array.length == 0) {
/*  906 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  910 */     long max = array[0];
/*  911 */     for (int j = 1; j < array.length; j++) {
/*  912 */       if (array[j] > max) {
/*  913 */         max = array[j];
/*      */       }
/*      */     } 
/*      */     
/*  917 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int max(int[] array) {
/*  930 */     if (array == null)
/*  931 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  932 */     if (array.length == 0) {
/*  933 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  937 */     int max = array[0];
/*  938 */     for (int j = 1; j < array.length; j++) {
/*  939 */       if (array[j] > max) {
/*  940 */         max = array[j];
/*      */       }
/*      */     } 
/*      */     
/*  944 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short max(short[] array) {
/*  957 */     if (array == null)
/*  958 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  959 */     if (array.length == 0) {
/*  960 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  964 */     short max = array[0];
/*  965 */     for (int i = 1; i < array.length; i++) {
/*  966 */       if (array[i] > max) {
/*  967 */         max = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  971 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte max(byte[] array) {
/*  984 */     if (array == null)
/*  985 */       throw new IllegalArgumentException("The Array must not be null"); 
/*  986 */     if (array.length == 0) {
/*  987 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/*  991 */     byte max = array[0];
/*  992 */     for (int i = 1; i < array.length; i++) {
/*  993 */       if (array[i] > max) {
/*  994 */         max = array[i];
/*      */       }
/*      */     } 
/*      */     
/*  998 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static double max(double[] array) {
/* 1012 */     if (array == null)
/* 1013 */       throw new IllegalArgumentException("The Array must not be null"); 
/* 1014 */     if (array.length == 0) {
/* 1015 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/* 1019 */     double max = array[0];
/* 1020 */     for (int j = 1; j < array.length; j++) {
/* 1021 */       if (Double.isNaN(array[j])) {
/* 1022 */         return NaND;
/*      */       }
/* 1024 */       if (array[j] > max) {
/* 1025 */         max = array[j];
/*      */       }
/*      */     } 
/*      */     
/* 1029 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static float max(float[] array) {
/* 1043 */     if (array == null)
/* 1044 */       throw new IllegalArgumentException("The Array must not be null"); 
/* 1045 */     if (array.length == 0) {
/* 1046 */       throw new IllegalArgumentException("Array cannot be empty.");
/*      */     }
/*      */ 
/*      */     
/* 1050 */     float max = array[0];
/* 1051 */     for (int j = 1; j < array.length; j++) {
/* 1052 */       if (Float.isNaN(array[j])) {
/* 1053 */         return NaNF;
/*      */       }
/* 1055 */       if (array[j] > max) {
/* 1056 */         max = array[j];
/*      */       }
/*      */     } 
/*      */     
/* 1060 */     return max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long min(long a, long b, long c) {
/* 1074 */     if (b < a) {
/* 1075 */       a = b;
/*      */     }
/* 1077 */     if (c < a) {
/* 1078 */       a = c;
/*      */     }
/* 1080 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int min(int a, int b, int c) {
/* 1092 */     if (b < a) {
/* 1093 */       a = b;
/*      */     }
/* 1095 */     if (c < a) {
/* 1096 */       a = c;
/*      */     }
/* 1098 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short min(short a, short b, short c) {
/* 1110 */     if (b < a) {
/* 1111 */       a = b;
/*      */     }
/* 1113 */     if (c < a) {
/* 1114 */       a = c;
/*      */     }
/* 1116 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte min(byte a, byte b, byte c) {
/* 1128 */     if (b < a) {
/* 1129 */       a = b;
/*      */     }
/* 1131 */     if (c < a) {
/* 1132 */       a = c;
/*      */     }
/* 1134 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1150 */   public static double min(double a, double b, double c) { return Math.min(Math.min(a, b), c); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1166 */   public static float min(float a, float b, float c) { return Math.min(Math.min(a, b), c); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long max(long a, long b, long c) {
/* 1180 */     if (b > a) {
/* 1181 */       a = b;
/*      */     }
/* 1183 */     if (c > a) {
/* 1184 */       a = c;
/*      */     }
/* 1186 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int max(int a, int b, int c) {
/* 1198 */     if (b > a) {
/* 1199 */       a = b;
/*      */     }
/* 1201 */     if (c > a) {
/* 1202 */       a = c;
/*      */     }
/* 1204 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short max(short a, short b, short c) {
/* 1216 */     if (b > a) {
/* 1217 */       a = b;
/*      */     }
/* 1219 */     if (c > a) {
/* 1220 */       a = c;
/*      */     }
/* 1222 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte max(byte a, byte b, byte c) {
/* 1234 */     if (b > a) {
/* 1235 */       a = b;
/*      */     }
/* 1237 */     if (c > a) {
/* 1238 */       a = c;
/*      */     }
/* 1240 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1256 */   public static double max(double a, double b, double c) { return Math.max(Math.max(a, b), c); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1272 */   public static float max(float a, float b, float c) { return Math.max(Math.max(a, b), c); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isDigits(String str) {
/* 1287 */     if (StringUtils.isEmpty(str)) {
/* 1288 */       return false;
/*      */     }
/* 1290 */     for (int i = 0; i < str.length(); i++) {
/* 1291 */       if (!Character.isDigit(str.charAt(i))) {
/* 1292 */         return false;
/*      */       }
/*      */     } 
/* 1295 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumber(String str) {
/* 1312 */     if (StringUtils.isEmpty(str)) {
/* 1313 */       return false;
/*      */     }
/* 1315 */     char[] chars = str.toCharArray();
/* 1316 */     int sz = chars.length;
/* 1317 */     boolean hasExp = false;
/* 1318 */     boolean hasDecPoint = false;
/* 1319 */     boolean allowSigns = false;
/* 1320 */     boolean foundDigit = false;
/*      */     
/* 1322 */     int start = (chars[0] == '-') ? 1 : 0;
/* 1323 */     if (sz > start + 1 && 
/* 1324 */       chars[start] == '0' && chars[start + 1] == 'x') {
/* 1325 */       int i = start + 2;
/* 1326 */       if (i == sz) {
/* 1327 */         return false;
/*      */       }
/*      */       
/* 1330 */       for (; i < chars.length; i++) {
/* 1331 */         if ((chars[i] < '0' || chars[i] > '9') && (chars[i] < 'a' || chars[i] > 'f') && (chars[i] < 'A' || chars[i] > 'F'))
/*      */         {
/*      */           
/* 1334 */           return false;
/*      */         }
/*      */       } 
/* 1337 */       return true;
/*      */     } 
/*      */     
/* 1340 */     sz--;
/*      */     
/* 1342 */     int i = start;
/*      */ 
/*      */     
/* 1345 */     while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
/* 1346 */       if (chars[i] >= '0' && chars[i] <= '9') {
/* 1347 */         foundDigit = true;
/* 1348 */         allowSigns = false;
/*      */       }
/* 1350 */       else if (chars[i] == '.') {
/* 1351 */         if (hasDecPoint || hasExp)
/*      */         {
/* 1353 */           return false;
/*      */         }
/* 1355 */         hasDecPoint = true;
/* 1356 */       } else if (chars[i] == 'e' || chars[i] == 'E') {
/*      */         
/* 1358 */         if (hasExp)
/*      */         {
/* 1360 */           return false;
/*      */         }
/* 1362 */         if (!foundDigit) {
/* 1363 */           return false;
/*      */         }
/* 1365 */         hasExp = true;
/* 1366 */         allowSigns = true;
/* 1367 */       } else if (chars[i] == '+' || chars[i] == '-') {
/* 1368 */         if (!allowSigns) {
/* 1369 */           return false;
/*      */         }
/* 1371 */         allowSigns = false;
/* 1372 */         foundDigit = false;
/*      */       } else {
/* 1374 */         return false;
/*      */       } 
/* 1376 */       i++;
/*      */     } 
/* 1378 */     if (i < chars.length) {
/* 1379 */       if (chars[i] >= '0' && chars[i] <= '9')
/*      */       {
/* 1381 */         return true;
/*      */       }
/* 1383 */       if (chars[i] == 'e' || chars[i] == 'E')
/*      */       {
/* 1385 */         return false;
/*      */       }
/* 1387 */       if (chars[i] == '.') {
/* 1388 */         if (hasDecPoint || hasExp)
/*      */         {
/* 1390 */           return false;
/*      */         }
/*      */         
/* 1393 */         return foundDigit;
/*      */       } 
/* 1395 */       if (!allowSigns && (chars[i] == 'd' || chars[i] == 'D' || chars[i] == 'f' || chars[i] == 'F'))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1400 */         return foundDigit;
/*      */       }
/* 1402 */       if (chars[i] == 'l' || chars[i] == 'L')
/*      */       {
/*      */         
/* 1405 */         return (foundDigit && !hasExp && !hasDecPoint);
/*      */       }
/*      */       
/* 1408 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1412 */     return (!allowSigns && foundDigit);
/*      */   }
/*      */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\math\NumberUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */