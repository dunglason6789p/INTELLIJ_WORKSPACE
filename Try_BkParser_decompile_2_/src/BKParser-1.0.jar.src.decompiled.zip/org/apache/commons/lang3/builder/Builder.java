package org.apache.commons.lang3.builder;

public interface Builder<T> {
  T build();
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\builder\Builder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */