/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RandomStringUtils
/*     */ {
/*  43 */   private static final Random RANDOM = new Random();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static String random(int count) { return random(count, false, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static String randomAscii(int count) { return random(count, 32, 127, false, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public static String randomAlphabetic(int count) { return random(count, true, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public static String randomAlphanumeric(int count) { return random(count, true, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public static String randomNumeric(int count) { return random(count, false, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public static String random(int count, boolean letters, boolean numbers) { return random(count, 0, 0, letters, numbers); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public static String random(int count, int start, int end, boolean letters, boolean numbers) { return random(count, start, end, letters, numbers, null, RANDOM); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public static String random(int count, int start, int end, boolean letters, boolean numbers, char... chars) { return random(count, start, end, letters, numbers, chars, RANDOM); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, int start, int end, boolean letters, boolean numbers, char[] chars, Random random) {
/* 225 */     if (count == 0)
/* 226 */       return ""; 
/* 227 */     if (count < 0) {
/* 228 */       throw new IllegalArgumentException("Requested random string length " + count + " is less than 0.");
/*     */     }
/* 230 */     if (start == 0 && end == 0) {
/* 231 */       end = 123;
/* 232 */       start = 32;
/* 233 */       if (!letters && !numbers) {
/* 234 */         start = 0;
/* 235 */         end = Integer.MAX_VALUE;
/*     */       } 
/*     */     } 
/*     */     
/* 239 */     char[] buffer = new char[count];
/* 240 */     int gap = end - start;
/*     */     
/* 242 */     while (count-- != 0) {
/*     */       char ch;
/* 244 */       if (chars == null) {
/* 245 */         ch = (char)(random.nextInt(gap) + start);
/*     */       } else {
/* 247 */         ch = chars[random.nextInt(gap) + start];
/*     */       } 
/* 249 */       if ((letters && Character.isLetter(ch)) || (numbers && Character.isDigit(ch)) || (!letters && !numbers)) {
/*     */ 
/*     */         
/* 252 */         if (ch >= '?' && ch <= '?') {
/* 253 */           if (count == 0) {
/* 254 */             count++;
/*     */             continue;
/*     */           } 
/* 257 */           buffer[count] = ch;
/* 258 */           count--;
/* 259 */           buffer[count] = (char)(55296 + random.nextInt(128)); continue;
/*     */         } 
/* 261 */         if (ch >= '?' && ch <= '?') {
/* 262 */           if (count == 0) {
/* 263 */             count++;
/*     */             continue;
/*     */           } 
/* 266 */           buffer[count] = (char)(56320 + random.nextInt(128));
/* 267 */           count--;
/* 268 */           buffer[count] = ch; continue;
/*     */         } 
/* 270 */         if (ch >= '?' && ch <= '?') {
/*     */           
/* 272 */           count++; continue;
/*     */         } 
/* 274 */         buffer[count] = ch;
/*     */         continue;
/*     */       } 
/* 277 */       count++;
/*     */     } 
/*     */     
/* 280 */     return new String(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, String chars) {
/* 297 */     if (chars == null) {
/* 298 */       return random(count, 0, 0, false, false, null, RANDOM);
/*     */     }
/* 300 */     return random(count, chars.toCharArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String random(int count, char... chars) {
/* 316 */     if (chars == null) {
/* 317 */       return random(count, 0, 0, false, false, null, RANDOM);
/*     */     }
/* 319 */     return random(count, 0, chars.length, false, false, chars, RANDOM);
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\RandomStringUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */