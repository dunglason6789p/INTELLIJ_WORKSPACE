/*     */ package org.apache.commons.lang3;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class CharRange
/*     */   extends Object
/*     */   implements Iterable<Character>, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 8270183163158333422L;
/*     */   private final char start;
/*     */   private final char end;
/*     */   private final boolean negated;
/*     */   private String iToString;
/*     */   
/*     */   private CharRange(char start, char end, boolean negated) {
/*  69 */     if (start > end) {
/*  70 */       char temp = start;
/*  71 */       start = end;
/*  72 */       end = temp;
/*     */     } 
/*     */     
/*  75 */     this.start = start;
/*  76 */     this.end = end;
/*  77 */     this.negated = negated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public static CharRange is(char ch) { return new CharRange(ch, ch, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public static CharRange isNot(char ch) { return new CharRange(ch, ch, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   public static CharRange isIn(char start, char end) { return new CharRange(start, end, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   public static CharRange isNotIn(char start, char end) { return new CharRange(start, end, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public char getStart() { return this.start; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public char getEnd() { return this.end; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 159 */   public boolean isNegated() { return this.negated; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   public boolean contains(char ch) { return (((ch >= this.start && ch <= this.end)) != this.negated); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(CharRange range) {
/* 183 */     if (range == null) {
/* 184 */       throw new IllegalArgumentException("The Range must not be null");
/*     */     }
/* 186 */     if (this.negated) {
/* 187 */       if (range.negated) {
/* 188 */         return (this.start >= range.start && this.end <= range.end);
/*     */       }
/* 190 */       return (range.end < this.start || range.start > this.end);
/*     */     } 
/* 192 */     if (range.negated) {
/* 193 */       return (this.start == '\000' && this.end == Character.MAX_VALUE);
/*     */     }
/* 195 */     return (this.start <= range.start && this.end >= range.end);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 209 */     if (obj == this) {
/* 210 */       return true;
/*     */     }
/* 212 */     if (!(obj instanceof CharRange)) {
/* 213 */       return false;
/*     */     }
/* 215 */     CharRange other = (CharRange)obj;
/* 216 */     return (this.start == other.start && this.end == other.end && this.negated == other.negated);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public int hashCode() { return 'S' + this.start + '\007' * this.end + (this.negated ? '\001' : Character.MIN_VALUE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 236 */     if (this.iToString == null) {
/* 237 */       StringBuilder buf = new StringBuilder(4);
/* 238 */       if (isNegated()) {
/* 239 */         buf.append('^');
/*     */       }
/* 241 */       buf.append(this.start);
/* 242 */       if (this.start != this.end) {
/* 243 */         buf.append('-');
/* 244 */         buf.append(this.end);
/*     */       } 
/* 246 */       this.iToString = buf.toString();
/*     */     } 
/* 248 */     return this.iToString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 261 */   public Iterator<Character> iterator() { return new CharacterIterator(this, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class CharacterIterator
/*     */     extends Object
/*     */     implements Iterator<Character>
/*     */   {
/*     */     private char current;
/*     */ 
/*     */     
/*     */     private final CharRange range;
/*     */ 
/*     */     
/*     */     private boolean hasNext;
/*     */ 
/*     */ 
/*     */     
/*     */     private CharacterIterator(CharRange r) {
/* 281 */       this.range = r;
/* 282 */       this.hasNext = true;
/*     */       
/* 284 */       if (this.range.negated) {
/* 285 */         if (this.range.start == '\000') {
/* 286 */           if (this.range.end == Character.MAX_VALUE) {
/*     */             
/* 288 */             this.hasNext = false;
/*     */           } else {
/* 290 */             this.current = (char)(this.range.end + '\001');
/*     */           } 
/*     */         } else {
/* 293 */           this.current = Character.MIN_VALUE;
/*     */         } 
/*     */       } else {
/* 296 */         this.current = this.range.start;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void prepareNext() {
/* 304 */       if (this.range.negated) {
/* 305 */         if (this.current == Character.MAX_VALUE) {
/* 306 */           this.hasNext = false;
/* 307 */         } else if (this.current + '\001' == this.range.start) {
/* 308 */           if (this.range.end == Character.MAX_VALUE) {
/* 309 */             this.hasNext = false;
/*     */           } else {
/* 311 */             this.current = (char)(this.range.end + '\001');
/*     */           } 
/*     */         } else {
/* 314 */           this.current = (char)(this.current + '\001');
/*     */         } 
/* 316 */       } else if (this.current < this.range.end) {
/* 317 */         this.current = (char)(this.current + '\001');
/*     */       } else {
/* 319 */         this.hasNext = false;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     public boolean hasNext() { return this.hasNext; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Character next() {
/* 338 */       if (!this.hasNext) {
/* 339 */         throw new NoSuchElementException();
/*     */       }
/* 341 */       char cur = this.current;
/* 342 */       prepareNext();
/* 343 */       return Character.valueOf(cur);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 353 */     public void remove() { throw new UnsupportedOperationException(); }
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\commons\lang3\CharRange.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.0.7
 */