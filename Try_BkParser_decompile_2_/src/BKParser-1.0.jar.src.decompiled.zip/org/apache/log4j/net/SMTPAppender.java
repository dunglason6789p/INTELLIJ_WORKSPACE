/*     */ package org.apache.log4j.net;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ import javax.mail.Authenticator;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.PasswordAuthentication;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.AddressException;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.InternetHeaders;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.MimeMultipart;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import org.apache.log4j.AppenderSkeleton;
/*     */ import org.apache.log4j.Layout;
/*     */ import org.apache.log4j.helpers.CyclicBuffer;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.helpers.OptionConverter;
/*     */ import org.apache.log4j.spi.LoggingEvent;
/*     */ import org.apache.log4j.spi.OptionHandler;
/*     */ import org.apache.log4j.spi.TriggeringEventEvaluator;
/*     */ import org.apache.log4j.xml.DOMConfigurator;
/*     */ import org.apache.log4j.xml.UnrecognizedElementHandler;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SMTPAppender
/*     */   extends AppenderSkeleton
/*     */   implements UnrecognizedElementHandler
/*     */ {
/*     */   private String to;
/*     */   private String cc;
/*     */   private String bcc;
/*     */   private String from;
/*     */   private String replyTo;
/*     */   private String subject;
/*     */   private String smtpHost;
/*     */   private String smtpUsername;
/*     */   private String smtpPassword;
/*     */   private String smtpProtocol;
/*     */   private int smtpPort;
/*     */   private boolean smtpDebug;
/*     */   private int bufferSize;
/*     */   private boolean locationInfo;
/*     */   private boolean sendOnClose;
/*     */   protected CyclicBuffer cb;
/*     */   protected Message msg;
/*     */   protected TriggeringEventEvaluator evaluator;
/*     */   
/* 119 */   public SMTPAppender() { this(new DefaultEvaluator()); }
/*     */   
/*     */   public SMTPAppender(TriggeringEventEvaluator evaluator) {
/*     */     this.smtpPort = -1;
/*     */     this.smtpDebug = false;
/*     */     this.bufferSize = 512;
/*     */     this.locationInfo = false;
/*     */     this.sendOnClose = false;
/*     */     this.cb = new CyclicBuffer(this.bufferSize);
/* 128 */     this.evaluator = evaluator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void activateOptions() {
/* 137 */     Session session = createSession();
/* 138 */     this.msg = new MimeMessage(session);
/*     */     
/*     */     try {
/* 141 */       addressMessage(this.msg);
/* 142 */       if (this.subject != null) {
/*     */         try {
/* 144 */           this.msg.setSubject(MimeUtility.encodeText(this.subject, "UTF-8", null));
/* 145 */         } catch (UnsupportedEncodingException ex) {
/* 146 */           LogLog.error("Unable to encode SMTP subject", ex);
/*     */         } 
/*     */       }
/* 149 */     } catch (MessagingException e) {
/* 150 */       LogLog.error("Could not activate SMTPAppender options.", e);
/*     */     } 
/*     */     
/* 153 */     if (this.evaluator instanceof OptionHandler) {
/* 154 */       ((OptionHandler)this.evaluator).activateOptions();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addressMessage(Message msg) throws MessagingException {
/* 165 */     if (this.from != null) {
/* 166 */       msg.setFrom(getAddress(this.from));
/*     */     } else {
/* 168 */       msg.setFrom();
/*     */     } 
/*     */ 
/*     */     
/* 172 */     if (this.replyTo != null && this.replyTo.length() > 0) {
/* 173 */       msg.setReplyTo(parseAddress(this.replyTo));
/*     */     }
/*     */     
/* 176 */     if (this.to != null && this.to.length() > 0) {
/* 177 */       msg.setRecipients(Message.RecipientType.TO, parseAddress(this.to));
/*     */     }
/*     */ 
/*     */     
/* 181 */     if (this.cc != null && this.cc.length() > 0) {
/* 182 */       msg.setRecipients(Message.RecipientType.CC, parseAddress(this.cc));
/*     */     }
/*     */ 
/*     */     
/* 186 */     if (this.bcc != null && this.bcc.length() > 0) {
/* 187 */       msg.setRecipients(Message.RecipientType.BCC, parseAddress(this.bcc));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Session createSession() {
/* 197 */     Properties props = null;
/*     */     try {
/* 199 */       props = new Properties(System.getProperties());
/* 200 */     } catch (SecurityException ex) {
/* 201 */       props = new Properties();
/*     */     } 
/*     */     
/* 204 */     String prefix = "mail.smtp";
/* 205 */     if (this.smtpProtocol != null) {
/* 206 */       props.put("mail.transport.protocol", this.smtpProtocol);
/* 207 */       prefix = "mail." + this.smtpProtocol;
/*     */     } 
/* 209 */     if (this.smtpHost != null) {
/* 210 */       props.put(prefix + ".host", this.smtpHost);
/*     */     }
/* 212 */     if (this.smtpPort > 0) {
/* 213 */       props.put(prefix + ".port", String.valueOf(this.smtpPort));
/*     */     }
/*     */     
/* 216 */     Authenticator auth = null;
/* 217 */     if (this.smtpPassword != null && this.smtpUsername != null) {
/* 218 */       props.put(prefix + ".auth", "true");
/* 219 */       auth = new Authenticator(this)
/*     */         {
/* 221 */           protected PasswordAuthentication getPasswordAuthentication() { return new PasswordAuthentication(this.this$0.smtpUsername, this.this$0.smtpPassword); }
/*     */           private final SMTPAppender this$0;
/*     */         };
/*     */     } 
/* 225 */     Session session = Session.getInstance(props, auth);
/* 226 */     if (this.smtpProtocol != null) {
/* 227 */       session.setProtocolForAddress("rfc822", this.smtpProtocol);
/*     */     }
/* 229 */     if (this.smtpDebug) {
/* 230 */       session.setDebug(this.smtpDebug);
/*     */     }
/* 232 */     return session;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void append(LoggingEvent event) {
/* 242 */     if (!checkEntryConditions()) {
/*     */       return;
/*     */     }
/*     */     
/* 246 */     event.getThreadName();
/* 247 */     event.getNDC();
/* 248 */     event.getMDCCopy();
/* 249 */     if (this.locationInfo) {
/* 250 */       event.getLocationInformation();
/*     */     }
/* 252 */     event.getRenderedMessage();
/* 253 */     event.getThrowableStrRep();
/* 254 */     this.cb.add(event);
/* 255 */     if (this.evaluator.isTriggeringEvent(event)) {
/* 256 */       sendBuffer();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkEntryConditions() {
/* 268 */     if (this.msg == null) {
/* 269 */       this.errorHandler.error("Message object not configured.");
/* 270 */       return false;
/*     */     } 
/*     */     
/* 273 */     if (this.evaluator == null) {
/* 274 */       this.errorHandler.error("No TriggeringEventEvaluator is set for appender [" + this.name + "].");
/*     */       
/* 276 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 280 */     if (this.layout == null) {
/* 281 */       this.errorHandler.error("No layout set for appender named [" + this.name + "].");
/* 282 */       return false;
/*     */     } 
/* 284 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 291 */     this.closed = true;
/* 292 */     if (this.sendOnClose && this.cb.length() > 0) {
/* 293 */       sendBuffer();
/*     */     }
/*     */   }
/*     */   
/*     */   InternetAddress getAddress(String addressStr) {
/*     */     try {
/* 299 */       return new InternetAddress(addressStr);
/* 300 */     } catch (AddressException e) {
/* 301 */       this.errorHandler.error("Could not parse address [" + addressStr + "].", e, 6);
/*     */       
/* 303 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   InternetAddress[] parseAddress(String addressStr) {
/*     */     try {
/* 309 */       return InternetAddress.parse(addressStr, true);
/* 310 */     } catch (AddressException e) {
/* 311 */       this.errorHandler.error("Could not parse address [" + addressStr + "].", e, 6);
/*     */       
/* 313 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 322 */   public String getTo() { return this.to; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 331 */   public boolean requiresLayout() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String formatBody() {
/* 343 */     StringBuffer sbuf = new StringBuffer();
/* 344 */     String t = this.layout.getHeader();
/* 345 */     if (t != null)
/* 346 */       sbuf.append(t); 
/* 347 */     int len = this.cb.length();
/* 348 */     for (int i = 0; i < len; i++) {
/*     */       
/* 350 */       LoggingEvent event = this.cb.get();
/* 351 */       sbuf.append(this.layout.format(event));
/* 352 */       if (this.layout.ignoresThrowable()) {
/* 353 */         String[] s = event.getThrowableStrRep();
/* 354 */         if (s != null) {
/* 355 */           for (int j = 0; j < s.length; j++) {
/* 356 */             sbuf.append(s[j]);
/* 357 */             sbuf.append(Layout.LINE_SEP);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     } 
/* 362 */     t = this.layout.getFooter();
/* 363 */     if (t != null) {
/* 364 */       sbuf.append(t);
/*     */     }
/*     */     
/* 367 */     return sbuf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendBuffer() {
/*     */     try {
/*     */       MimeBodyPart mimeBodyPart;
/* 377 */       String s = formatBody();
/* 378 */       boolean allAscii = true;
/* 379 */       for (int i = 0; i < s.length() && allAscii; i++) {
/* 380 */         allAscii = (s.charAt(i) <= '');
/*     */       }
/*     */       
/* 383 */       if (allAscii) {
/* 384 */         mimeBodyPart = new MimeBodyPart();
/* 385 */         mimeBodyPart.setContent(s, this.layout.getContentType());
/*     */       } else {
/*     */         try {
/* 388 */           ByteArrayOutputStream os = new ByteArrayOutputStream();
/* 389 */           Writer writer = new OutputStreamWriter(MimeUtility.encode(os, "quoted-printable"), "UTF-8");
/*     */           
/* 391 */           writer.write(s);
/* 392 */           writer.close();
/* 393 */           InternetHeaders headers = new InternetHeaders();
/* 394 */           headers.setHeader("Content-Type", this.layout.getContentType() + "; charset=UTF-8");
/* 395 */           headers.setHeader("Content-Transfer-Encoding", "quoted-printable");
/* 396 */           mimeBodyPart = new MimeBodyPart(headers, os.toByteArray());
/* 397 */         } catch (Exception ex) {
/* 398 */           StringBuffer sbuf = new StringBuffer(s);
/* 399 */           for (int i = 0; i < sbuf.length(); i++) {
/* 400 */             if (sbuf.charAt(i) >= '') {
/* 401 */               sbuf.setCharAt(i, '?');
/*     */             }
/*     */           } 
/* 404 */           mimeBodyPart = new MimeBodyPart();
/* 405 */           mimeBodyPart.setContent(sbuf.toString(), this.layout.getContentType());
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 411 */       MimeMultipart mimeMultipart = new MimeMultipart();
/* 412 */       mimeMultipart.addBodyPart(mimeBodyPart);
/* 413 */       this.msg.setContent(mimeMultipart);
/*     */       
/* 415 */       this.msg.setSentDate(new Date());
/* 416 */       Transport.send(this.msg);
/* 417 */     } catch (MessagingException e) {
/* 418 */       LogLog.error("Error occured while sending e-mail notification.", e);
/* 419 */     } catch (RuntimeException e) {
/* 420 */       LogLog.error("Error occured while sending e-mail notification.", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 431 */   public String getEvaluatorClass() { return (this.evaluator == null) ? null : this.evaluator.getClass().getName(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 439 */   public String getFrom() { return this.from; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 449 */   public String getReplyTo() { return this.replyTo; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 457 */   public String getSubject() { return this.subject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 466 */   public void setFrom(String from) { this.from = from; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 476 */   public void setReplyTo(String addresses) { this.replyTo = addresses; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 486 */   public void setSubject(String subject) { this.subject = subject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBufferSize(int bufferSize) {
/* 499 */     this.bufferSize = bufferSize;
/* 500 */     this.cb.resize(bufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 509 */   public void setSMTPHost(String smtpHost) { this.smtpHost = smtpHost; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 517 */   public String getSMTPHost() { return this.smtpHost; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 526 */   public void setTo(String to) { this.to = to; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 536 */   public int getBufferSize() { return this.bufferSize; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 548 */   public void setEvaluatorClass(String value) { this.evaluator = (TriggeringEventEvaluator)OptionConverter.instantiateByClassName(value, TriggeringEventEvaluator.class, this.evaluator); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 568 */   public void setLocationInfo(boolean locationInfo) { this.locationInfo = locationInfo; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 576 */   public boolean getLocationInfo() { return this.locationInfo; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 585 */   public void setCc(String addresses) { this.cc = addresses; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 594 */   public String getCc() { return this.cc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 603 */   public void setBcc(String addresses) { this.bcc = addresses; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 612 */   public String getBcc() { return this.bcc; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 622 */   public void setSMTPPassword(String password) { this.smtpPassword = password; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 632 */   public void setSMTPUsername(String username) { this.smtpUsername = username; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 643 */   public void setSMTPDebug(boolean debug) { this.smtpDebug = debug; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 652 */   public String getSMTPPassword() { return this.smtpPassword; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 661 */   public String getSMTPUsername() { return this.smtpUsername; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 670 */   public boolean getSMTPDebug() { return this.smtpDebug; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setEvaluator(TriggeringEventEvaluator trigger) {
/* 679 */     if (trigger == null) {
/* 680 */       throw new NullPointerException("trigger");
/*     */     }
/* 682 */     this.evaluator = trigger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 691 */   public final TriggeringEventEvaluator getEvaluator() { return this.evaluator; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean parseUnrecognizedElement(Element element, Properties props) throws Exception {
/* 699 */     if ("triggeringPolicy".equals(element.getNodeName())) {
/* 700 */       Object triggerPolicy = DOMConfigurator.parseElement(element, props, TriggeringEventEvaluator.class);
/*     */ 
/*     */       
/* 703 */       if (triggerPolicy instanceof TriggeringEventEvaluator) {
/* 704 */         setEvaluator((TriggeringEventEvaluator)triggerPolicy);
/*     */       }
/* 706 */       return true;
/*     */     } 
/*     */     
/* 709 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 720 */   public final String getSMTPProtocol() { return this.smtpProtocol; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 731 */   public final void setSMTPProtocol(String val) { this.smtpProtocol = val; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 741 */   public final int getSMTPPort() { return this.smtpPort; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 751 */   public final void setSMTPPort(int val) { this.smtpPort = val; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 761 */   public final boolean getSendOnClose() { return this.sendOnClose; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 771 */   public final void setSendOnClose(boolean val) { this.sendOnClose = val; }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\net\SMTPAppender.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */