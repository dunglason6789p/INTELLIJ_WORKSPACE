package org.apache.log4j.spi;

public interface ThrowableRenderer {
  String[] doRender(Throwable paramThrowable);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\spi\ThrowableRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */