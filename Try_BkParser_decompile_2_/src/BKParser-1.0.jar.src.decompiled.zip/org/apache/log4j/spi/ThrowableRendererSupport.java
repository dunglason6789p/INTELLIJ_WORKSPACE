package org.apache.log4j.spi;

public interface ThrowableRendererSupport {
  ThrowableRenderer getThrowableRenderer();
  
  void setThrowableRenderer(ThrowableRenderer paramThrowableRenderer);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\spi\ThrowableRendererSupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */