package org.apache.log4j.spi;

public interface RepositorySelector {
  LoggerRepository getLoggerRepository();
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\spi\RepositorySelector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */