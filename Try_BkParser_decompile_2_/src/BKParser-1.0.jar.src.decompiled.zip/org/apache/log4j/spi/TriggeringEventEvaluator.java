package org.apache.log4j.spi;

public interface TriggeringEventEvaluator {
  boolean isTriggeringEvent(LoggingEvent paramLoggingEvent);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\spi\TriggeringEventEvaluator.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */