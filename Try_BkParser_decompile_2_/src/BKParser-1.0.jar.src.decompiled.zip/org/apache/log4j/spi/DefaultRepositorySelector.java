/*    */ package org.apache.log4j.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultRepositorySelector
/*    */   implements RepositorySelector
/*    */ {
/*    */   final LoggerRepository repository;
/*    */   
/* 29 */   public DefaultRepositorySelector(LoggerRepository repository) { this.repository = repository; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public LoggerRepository getLoggerRepository() { return this.repository; }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\spi\DefaultRepositorySelector.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */