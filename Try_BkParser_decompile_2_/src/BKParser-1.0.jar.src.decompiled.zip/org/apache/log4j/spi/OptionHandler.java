package org.apache.log4j.spi;

public interface OptionHandler {
  void activateOptions();
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\spi\OptionHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */