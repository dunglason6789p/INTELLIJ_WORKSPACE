package org.apache.log4j.spi;

import org.apache.log4j.Logger;

public interface LoggerFactory {
  Logger makeNewLoggerInstance(String paramString);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\spi\LoggerFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */