/*     */ package org.apache.log4j.spi;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Category;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.MDC;
/*     */ import org.apache.log4j.NDC;
/*     */ import org.apache.log4j.Priority;
/*     */ import org.apache.log4j.helpers.Loader;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoggingEvent
/*     */   implements Serializable
/*     */ {
/*  57 */   private static long startTime = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String fqnOfCategoryClass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Category logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String categoryName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Priority level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String ndc;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Hashtable mdcCopy;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean ndcLookupRequired;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean mdcCopyLookupRequired;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object message;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String renderedMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String threadName;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ThrowableInformation throwableInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long timeStamp;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LocationInfo locationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final long serialVersionUID = -868428216207166145L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 142 */   static final Integer[] PARAM_ARRAY = new Integer[1];
/*     */   static final String TO_LEVEL = "toLevel";
/* 144 */   static final Class[] TO_LEVEL_PARAMS = { int.class };
/* 145 */   static final Hashtable methodCache = new Hashtable(3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggingEvent(String fqnOfCategoryClass, Category logger, Priority level, Object message, Throwable throwable) {
/*     */     this.ndcLookupRequired = true;
/*     */     this.mdcCopyLookupRequired = true;
/* 159 */     this.fqnOfCategoryClass = fqnOfCategoryClass;
/* 160 */     this.logger = logger;
/* 161 */     this.categoryName = logger.getName();
/* 162 */     this.level = level;
/* 163 */     this.message = message;
/* 164 */     if (throwable != null) {
/* 165 */       this.throwableInfo = new ThrowableInformation(throwable, logger);
/*     */     }
/* 167 */     this.timeStamp = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggingEvent(String fqnOfCategoryClass, Category logger, long timeStamp, Priority level, Object message, Throwable throwable) {
/*     */     this.ndcLookupRequired = true;
/*     */     this.mdcCopyLookupRequired = true;
/* 184 */     this.fqnOfCategoryClass = fqnOfCategoryClass;
/* 185 */     this.logger = logger;
/* 186 */     this.categoryName = logger.getName();
/* 187 */     this.level = level;
/* 188 */     this.message = message;
/* 189 */     if (throwable != null) {
/* 190 */       this.throwableInfo = new ThrowableInformation(throwable, logger);
/*     */     }
/*     */     
/* 193 */     this.timeStamp = timeStamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LoggingEvent(String fqnOfCategoryClass, Category logger, long timeStamp, Level level, Object message, String threadName, ThrowableInformation throwable, String ndc, LocationInfo info, Map properties) {
/*     */     this.ndcLookupRequired = true;
/*     */     this.mdcCopyLookupRequired = true;
/* 222 */     this.fqnOfCategoryClass = fqnOfCategoryClass;
/* 223 */     this.logger = logger;
/* 224 */     if (logger != null) {
/* 225 */       this.categoryName = logger.getName();
/*     */     } else {
/* 227 */       this.categoryName = null;
/*     */     } 
/* 229 */     this.level = level;
/* 230 */     this.message = message;
/* 231 */     if (throwable != null) {
/* 232 */       this.throwableInfo = throwable;
/*     */     }
/*     */     
/* 235 */     this.timeStamp = timeStamp;
/* 236 */     this.threadName = threadName;
/* 237 */     this.ndcLookupRequired = false;
/* 238 */     this.ndc = ndc;
/* 239 */     this.locationInfo = info;
/* 240 */     this.mdcCopyLookupRequired = false;
/* 241 */     if (properties != null) {
/* 242 */       this.mdcCopy = new Hashtable(properties);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocationInfo getLocationInformation() {
/* 252 */     if (this.locationInfo == null) {
/* 253 */       this.locationInfo = new LocationInfo(new Throwable(), this.fqnOfCategoryClass);
/*     */     }
/* 255 */     return this.locationInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   public Level getLevel() { return (Level)this.level; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 270 */   public String getLoggerName() { return this.categoryName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 279 */   public Category getLogger() { return this.logger; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getMessage() {
/* 293 */     if (this.message != null) {
/* 294 */       return this.message;
/*     */     }
/* 296 */     return getRenderedMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNDC() {
/* 307 */     if (this.ndcLookupRequired) {
/* 308 */       this.ndcLookupRequired = false;
/* 309 */       this.ndc = NDC.get();
/*     */     } 
/* 311 */     return this.ndc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getMDC(String key) {
/* 332 */     if (this.mdcCopy != null) {
/* 333 */       Object r = this.mdcCopy.get(key);
/* 334 */       if (r != null) {
/* 335 */         return r;
/*     */       }
/*     */     } 
/* 338 */     return MDC.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getMDCCopy() {
/* 347 */     if (this.mdcCopyLookupRequired) {
/* 348 */       this.mdcCopyLookupRequired = false;
/*     */ 
/*     */       
/* 351 */       Hashtable t = MDC.getContext();
/* 352 */       if (t != null) {
/* 353 */         this.mdcCopy = (Hashtable)t.clone();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getRenderedMessage() {
/* 360 */     if (this.renderedMessage == null && this.message != null) {
/* 361 */       if (this.message instanceof String) {
/* 362 */         this.renderedMessage = (String)this.message;
/*     */       } else {
/* 364 */         LoggerRepository repository = this.logger.getLoggerRepository();
/*     */         
/* 366 */         if (repository instanceof RendererSupport) {
/* 367 */           RendererSupport rs = (RendererSupport)repository;
/* 368 */           this.renderedMessage = rs.getRendererMap().findAndRender(this.message);
/*     */         } else {
/* 370 */           this.renderedMessage = this.message.toString();
/*     */         } 
/*     */       } 
/*     */     }
/* 374 */     return this.renderedMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 381 */   public static long getStartTime() { return startTime; }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getThreadName() {
/* 386 */     if (this.threadName == null)
/* 387 */       this.threadName = Thread.currentThread().getName(); 
/* 388 */     return this.threadName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 401 */   public ThrowableInformation getThrowableInformation() { return this.throwableInfo; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getThrowableStrRep() {
/* 410 */     if (this.throwableInfo == null) {
/* 411 */       return null;
/*     */     }
/* 413 */     return this.throwableInfo.getThrowableStrRep();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readLevel(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 421 */     int p = ois.readInt();
/*     */     try {
/* 423 */       String className = (String)ois.readObject();
/* 424 */       if (className == null) {
/* 425 */         this.level = Level.toLevel(p);
/*     */       } else {
/* 427 */         Method m = (Method)methodCache.get(className);
/* 428 */         if (m == null) {
/* 429 */           Class clazz = Loader.loadClass(className);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 436 */           m = clazz.getDeclaredMethod("toLevel", TO_LEVEL_PARAMS);
/* 437 */           methodCache.put(className, m);
/*     */         } 
/* 439 */         PARAM_ARRAY[0] = new Integer(p);
/* 440 */         this.level = (Level)m.invoke(null, PARAM_ARRAY);
/*     */       } 
/* 442 */     } catch (InvocationTargetException e) {
/* 443 */       if (e.getTargetException() instanceof InterruptedException || e.getTargetException() instanceof java.io.InterruptedIOException)
/*     */       {
/* 445 */         Thread.currentThread().interrupt();
/*     */       }
/* 447 */       LogLog.warn("Level deserialization failed, reverting to default.", e);
/* 448 */       this.level = Level.toLevel(p);
/* 449 */     } catch (NoSuchMethodException e) {
/* 450 */       LogLog.warn("Level deserialization failed, reverting to default.", e);
/* 451 */       this.level = Level.toLevel(p);
/* 452 */     } catch (IllegalAccessException e) {
/* 453 */       LogLog.warn("Level deserialization failed, reverting to default.", e);
/* 454 */       this.level = Level.toLevel(p);
/* 455 */     } catch (RuntimeException e) {
/* 456 */       LogLog.warn("Level deserialization failed, reverting to default.", e);
/* 457 */       this.level = Level.toLevel(p);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
/* 463 */     ois.defaultReadObject();
/* 464 */     readLevel(ois);
/*     */ 
/*     */     
/* 467 */     if (this.locationInfo == null) {
/* 468 */       this.locationInfo = new LocationInfo(null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream oos) throws IOException {
/* 475 */     getThreadName();
/*     */ 
/*     */     
/* 478 */     getRenderedMessage();
/*     */ 
/*     */ 
/*     */     
/* 482 */     getNDC();
/*     */ 
/*     */ 
/*     */     
/* 486 */     getMDCCopy();
/*     */ 
/*     */     
/* 489 */     getThrowableStrRep();
/*     */     
/* 491 */     oos.defaultWriteObject();
/*     */ 
/*     */     
/* 494 */     writeLevel(oos);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeLevel(ObjectOutputStream oos) throws IOException {
/* 500 */     oos.writeInt(this.level.toInt());
/*     */     
/* 502 */     Class clazz = this.level.getClass();
/* 503 */     if (clazz == Level.class) {
/* 504 */       oos.writeObject(null);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 509 */       oos.writeObject(clazz.getName());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setProperty(String propName, String propValue) {
/* 525 */     if (this.mdcCopy == null) {
/* 526 */       getMDCCopy();
/*     */     }
/* 528 */     if (this.mdcCopy == null) {
/* 529 */       this.mdcCopy = new Hashtable();
/*     */     }
/* 531 */     this.mdcCopy.put(propName, propValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getProperty(String key) {
/* 545 */     Object value = getMDC(key);
/* 546 */     String retval = null;
/* 547 */     if (value != null) {
/* 548 */       retval = value.toString();
/*     */     }
/* 550 */     return retval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 560 */   public final boolean locationInformationExists() { return (this.locationInfo != null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 571 */   public final long getTimeStamp() { return this.timeStamp; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 586 */   public Set getPropertyKeySet() { return getProperties().keySet(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map getProperties() {
/*     */     Map properties;
/* 601 */     getMDCCopy();
/*     */     
/* 603 */     if (this.mdcCopy == null) {
/* 604 */       properties = new HashMap();
/*     */     } else {
/* 606 */       properties = this.mdcCopy;
/*     */     } 
/* 608 */     return Collections.unmodifiableMap(properties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 618 */   public String getFQNOfLoggerClass() { return this.fqnOfCategoryClass; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object removeProperty(String propName) {
/* 631 */     if (this.mdcCopy == null) {
/* 632 */       getMDCCopy();
/*     */     }
/* 634 */     if (this.mdcCopy == null) {
/* 635 */       this.mdcCopy = new Hashtable();
/*     */     }
/* 637 */     return this.mdcCopy.remove(propName);
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\spi\LoggingEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */