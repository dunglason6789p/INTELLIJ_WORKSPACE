package org.apache.log4j.or;

public interface ObjectRenderer {
  String doRender(Object paramObject);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\or\ObjectRenderer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */