/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ThreadLocalMap
/*    */   extends InheritableThreadLocal
/*    */ {
/*    */   public final Object childValue(Object parentValue) {
/* 35 */     Hashtable ht = (Hashtable)parentValue;
/* 36 */     if (ht != null) {
/* 37 */       return ht.clone();
/*    */     }
/* 39 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\helpers\ThreadLocalMap.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */