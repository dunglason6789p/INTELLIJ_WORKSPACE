/*    */ package org.apache.log4j.helpers;
/*    */ 
/*    */ import java.util.Enumeration;
/*    */ import java.util.NoSuchElementException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NullEnumeration
/*    */   implements Enumeration
/*    */ {
/* 31 */   private static final NullEnumeration instance = new NullEnumeration();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   public static NullEnumeration getInstance() { return instance; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public boolean hasMoreElements() { return false; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public Object nextElement() { throw new NoSuchElementException(); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\helpers\NullEnumeration.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */