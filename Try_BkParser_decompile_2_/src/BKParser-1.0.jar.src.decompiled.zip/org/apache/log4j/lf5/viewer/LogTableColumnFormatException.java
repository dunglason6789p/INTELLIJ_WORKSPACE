/*    */ package org.apache.log4j.lf5.viewer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogTableColumnFormatException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 6529165785030431653L;
/*    */   
/* 49 */   public LogTableColumnFormatException(String message) { super(message); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\lf5\viewer\LogTableColumnFormatException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */