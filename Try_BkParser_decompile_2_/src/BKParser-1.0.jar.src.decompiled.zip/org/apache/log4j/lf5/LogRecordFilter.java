package org.apache.log4j.lf5;

public interface LogRecordFilter {
  boolean passes(LogRecord paramLogRecord);
}


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\lf5\LogRecordFilter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */