/*     */ package org.apache.log4j.lf5.util;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateFormatManager
/*     */ {
/*     */   private TimeZone _timeZone;
/*     */   private Locale _locale;
/*     */   private String _pattern;
/*     */   private DateFormat _dateFormat;
/*     */   
/*     */   public DateFormatManager() {
/*  50 */     this._timeZone = null;
/*  51 */     this._locale = null;
/*     */     
/*  53 */     this._pattern = null;
/*  54 */     this._dateFormat = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     configure();
/*     */   } public DateFormatManager(TimeZone timeZone) {
/*     */     this._timeZone = null;
/*     */     this._locale = null;
/*     */     this._pattern = null;
/*     */     this._dateFormat = null;
/*  67 */     this._timeZone = timeZone;
/*  68 */     configure();
/*     */   } public DateFormatManager(Locale locale) {
/*     */     this._timeZone = null;
/*     */     this._locale = null;
/*     */     this._pattern = null;
/*     */     this._dateFormat = null;
/*  74 */     this._locale = locale;
/*  75 */     configure();
/*     */   } public DateFormatManager(String pattern) {
/*     */     this._timeZone = null;
/*     */     this._locale = null;
/*     */     this._pattern = null;
/*     */     this._dateFormat = null;
/*  81 */     this._pattern = pattern;
/*  82 */     configure();
/*     */   } public DateFormatManager(TimeZone timeZone, Locale locale) {
/*     */     this._timeZone = null;
/*     */     this._locale = null;
/*     */     this._pattern = null;
/*     */     this._dateFormat = null;
/*  88 */     this._timeZone = timeZone;
/*  89 */     this._locale = locale;
/*  90 */     configure();
/*     */   } public DateFormatManager(TimeZone timeZone, String pattern) {
/*     */     this._timeZone = null;
/*     */     this._locale = null;
/*     */     this._pattern = null;
/*     */     this._dateFormat = null;
/*  96 */     this._timeZone = timeZone;
/*  97 */     this._pattern = pattern;
/*  98 */     configure();
/*     */   } public DateFormatManager(Locale locale, String pattern) {
/*     */     this._timeZone = null;
/*     */     this._locale = null;
/*     */     this._pattern = null;
/*     */     this._dateFormat = null;
/* 104 */     this._locale = locale;
/* 105 */     this._pattern = pattern;
/* 106 */     configure();
/*     */   } public DateFormatManager(TimeZone timeZone, Locale locale, String pattern) {
/*     */     this._timeZone = null;
/*     */     this._locale = null;
/*     */     this._pattern = null;
/*     */     this._dateFormat = null;
/* 112 */     this._timeZone = timeZone;
/* 113 */     this._locale = locale;
/* 114 */     this._pattern = pattern;
/* 115 */     configure();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TimeZone getTimeZone() {
/* 123 */     if (this._timeZone == null) {
/* 124 */       return TimeZone.getDefault();
/*     */     }
/* 126 */     return this._timeZone;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeZone(TimeZone timeZone) {
/* 131 */     this._timeZone = timeZone;
/* 132 */     configure();
/*     */   }
/*     */   
/*     */   public Locale getLocale() {
/* 136 */     if (this._locale == null) {
/* 137 */       return Locale.getDefault();
/*     */     }
/* 139 */     return this._locale;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 144 */     this._locale = locale;
/* 145 */     configure();
/*     */   }
/*     */ 
/*     */   
/* 149 */   public String getPattern() { return this._pattern; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPattern(String pattern) {
/* 156 */     this._pattern = pattern;
/* 157 */     configure();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   public String getOutputFormat() { return this._pattern; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputFormat(String pattern) {
/* 174 */     this._pattern = pattern;
/* 175 */     configure();
/*     */   }
/*     */ 
/*     */   
/* 179 */   public DateFormat getDateFormatInstance() { return this._dateFormat; }
/*     */ 
/*     */ 
/*     */   
/* 183 */   public void setDateFormatInstance(DateFormat dateFormat) { this._dateFormat = dateFormat; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 188 */   public String format(Date date) { return getDateFormatInstance().format(date); }
/*     */ 
/*     */   
/*     */   public String format(Date date, String pattern) {
/* 192 */     DateFormat formatter = null;
/* 193 */     formatter = getDateFormatInstance();
/* 194 */     if (formatter instanceof SimpleDateFormat) {
/* 195 */       formatter = (SimpleDateFormat)formatter.clone();
/* 196 */       ((SimpleDateFormat)formatter).applyPattern(pattern);
/*     */     } 
/* 198 */     return formatter.format(date);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public Date parse(String date) throws ParseException { return getDateFormatInstance().parse(date); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date parse(String date, String pattern) throws ParseException {
/* 212 */     DateFormat formatter = null;
/* 213 */     formatter = getDateFormatInstance();
/* 214 */     if (formatter instanceof SimpleDateFormat) {
/* 215 */       formatter = (SimpleDateFormat)formatter.clone();
/* 216 */       ((SimpleDateFormat)formatter).applyPattern(pattern);
/*     */     } 
/* 218 */     return formatter.parse(date);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configure() {
/* 229 */     this._dateFormat = DateFormat.getDateTimeInstance(0, 0, getLocale());
/*     */ 
/*     */     
/* 232 */     this._dateFormat.setTimeZone(getTimeZone());
/*     */     
/* 234 */     if (this._pattern != null)
/* 235 */       ((SimpleDateFormat)this._dateFormat).applyPattern(this._pattern); 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\org\apache\log4j\lf\\util\DateFormatManager.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */