/*    */ package com.github.jcrfsuite.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OSInfo
/*    */ {
/*    */   public static void main(String[] args) {
/* 37 */     if (args.length >= 1) {
/* 38 */       if ("--os".equals(args[0])) {
/* 39 */         System.out.print(getOSName());
/*    */         return;
/*    */       } 
/* 42 */       if ("--arch".equals(args[0])) {
/* 43 */         System.out.print(getArchName());
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 48 */     System.out.print(getNativeLibFolderPathForCurrentOS());
/*    */   }
/*    */ 
/*    */   
/* 52 */   public static String getNativeLibFolderPathForCurrentOS() { return getOSName() + "/" + getArchName(); }
/*    */ 
/*    */ 
/*    */   
/* 56 */   public static String getOSName() { return translateOSNameToFolderName(System.getProperty("os.name")); }
/*    */ 
/*    */ 
/*    */   
/* 60 */   public static String getArchName() { return translateArchNameToFolderName(System.getProperty("os.arch")); }
/*    */ 
/*    */   
/*    */   public static String translateOSNameToFolderName(String osName) {
/* 64 */     if (osName.contains("Windows")) {
/* 65 */       return "Windows";
/*    */     }
/* 67 */     if (osName.contains("Mac")) {
/* 68 */       return "Mac";
/*    */     }
/* 70 */     if (osName.contains("Linux")) {
/* 71 */       return "Linux";
/*    */     }
/*    */     
/* 74 */     return osName.replaceAll("\\W", "");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 79 */   public static String translateArchNameToFolderName(String archName) { return archName.replaceAll("\\W", ""); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\github\jcrfsuit\\util\OSInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */