/*     */ package com.github.jcrfsuite.util;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.security.DigestInputStream;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.ProtectionDomain;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrfSuiteLoader
/*     */ {
/*     */   public static final String CRFSUITE_SYSTEM_PROPERTIES_FILE = "org-chokkan-crfsuite.properties";
/*     */   public static final String KEY_CRFSUITE_LIB_PATH = "org.chokkan.crfsuite.lib.path";
/*     */   public static final String KEY_CRFSUITE_LIB_NAME = "org.chokkan.crfsuite.lib.name";
/*     */   public static final String KEY_CRFSUITE_TEMPDIR = "org.chokkan.crfsuite.tempdir";
/*     */   public static final String KEY_CRFSUITE_USE_SYSTEMLIB = "org.chokkan.crfsuite.use.systemlib";
/*     */   public static final String KEY_CRFSUITE_DISABLE_BUNDLED_LIBS = "org.chokkan.crfsuite.disable.bundled.libs";
/*     */   
/*     */   private static void loadCrfSuiteSystemProperties() {
/*     */     try {
/*  84 */       is = Thread.currentThread().getContextClassLoader().getResourceAsStream("org-chokkan-crfsuite.properties");
/*     */       
/*  86 */       if (is == null) {
/*     */         return;
/*     */       }
/*     */       
/*  90 */       Properties props = new Properties();
/*  91 */       props.load(is);
/*  92 */       is.close();
/*  93 */       Enumeration<?> names = props.propertyNames();
/*  94 */       while (names.hasMoreElements()) {
/*  95 */         String name = (String)names.nextElement();
/*  96 */         if (name.startsWith("org.chokkan.crfsuite.") && 
/*  97 */           System.getProperty(name) == null) {
/*  98 */           System.setProperty(name, props.getProperty(name));
/*     */         }
/*     */       }
/*     */     
/* 102 */     } catch (Throwable ex) {
/* 103 */       System.err.println("Could not load 'org-chokkan-crfsuite.properties' from classpath: " + ex
/* 104 */           .toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   static  {
/* 109 */     loadCrfSuiteSystemProperties();
/*     */   }
/*     */   
/*     */   private static ClassLoader getRootClassLoader() {
/* 113 */     cl = Thread.currentThread().getContextClassLoader();
/* 114 */     while (cl.getParent() != null) {
/* 115 */       cl = cl.getParent();
/*     */     }
/* 117 */     return cl;
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] getByteCode(String resourcePath) throws IOException {
/* 122 */     InputStream in = CrfSuiteLoader.class.getResourceAsStream(resourcePath);
/* 123 */     if (in == null)
/* 124 */       throw new IOException(resourcePath + " is not found"); 
/* 125 */     byte[] buf = new byte[1024];
/* 126 */     ByteArrayOutputStream byteCodeBuf = new ByteArrayOutputStream(); int readLength;
/* 127 */     while ((readLength = in.read(buf)) != -1) {
/* 128 */       byteCodeBuf.write(buf, 0, readLength);
/*     */     }
/* 130 */     in.close();
/*     */     
/* 132 */     return byteCodeBuf.toByteArray();
/*     */   }
/*     */ 
/*     */   
/* 136 */   public static boolean isNativeLibraryLoaded() { return isLoaded; }
/*     */ 
/*     */   
/*     */   private static boolean hasInjectedNativeLoader() {
/*     */     try {
/* 141 */       nativeLoaderClassName = "native_loader.CrfSuiteNativeLoader";
/* 142 */       Class.forName("native_loader.CrfSuiteNativeLoader");
/*     */       
/* 144 */       return true;
/*     */     }
/* 146 */     catch (ClassNotFoundException e) {
/*     */       
/* 148 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void load() {
/* 188 */     if (!isLoaded) {
/*     */       try {
/* 190 */         if (!hasInjectedNativeLoader()) {
/*     */           
/* 192 */           nativeLoader = injectCrfSuiteNativeLoader();
/*     */           
/* 194 */           loadNativeLibrary(nativeLoader);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 199 */         Class.forName("com.github.jcrfsuite.util.CrfSuiteLoader");
/*     */         
/* 201 */         isLoaded = true;
/*     */       }
/* 203 */       catch (Exception e) {
/* 204 */         e.printStackTrace();
/* 205 */         throw e;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> injectCrfSuiteNativeLoader() throws Exception {
/*     */     try {
/* 221 */       nativeLoaderClassName = "native_loader.CrfSuiteNativeLoader";
/* 222 */       ClassLoader rootClassLoader = getRootClassLoader();
/*     */       
/* 224 */       byte[] byteCode = getByteCode("/crfsuite-0.12/native_loader/CrfSuiteNativeLoader.bytecode");
/*     */       
/* 226 */       String[] classesToPreload = { "third_party.org.chokkan.crfsuite.Attribute", "third_party.org.chokkan.crfsuite.crfsuite", "third_party.org.chokkan.crfsuite.crfsuiteJNI", "third_party.org.chokkan.crfsuite.Item", "third_party.org.chokkan.crfsuite.ItemSequence", "third_party.org.chokkan.crfsuite.StringList", "third_party.org.chokkan.crfsuite.Tagger", "third_party.org.chokkan.crfsuite.Trainer" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 236 */       List<byte[]> preloadClassByteCode = new ArrayList<byte[]>(classesToPreload.length);
/* 237 */       for (String each : classesToPreload) {
/* 238 */         preloadClassByteCode.add(getByteCode(String.format("/%s.class", new Object[] { each.replaceAll("\\.", "/") })));
/*     */       } 
/*     */ 
/*     */       
/* 242 */       Class<?> classLoader = Class.forName("java.lang.ClassLoader");
/* 243 */       defineClass = classLoader.getDeclaredMethod("defineClass", new Class[] { String.class, byte[].class, int.class, int.class, ProtectionDomain.class });
/*     */ 
/*     */       
/* 246 */       ProtectionDomain pd = System.class.getProtectionDomain();
/*     */ 
/*     */       
/* 249 */       defineClass.setAccessible(true);
/*     */       
/*     */       try {
/* 252 */         defineClass.invoke(rootClassLoader, new Object[] { "native_loader.CrfSuiteNativeLoader", byteCode, Integer.valueOf(0), Integer.valueOf(byteCode.length), pd });
/*     */ 
/*     */         
/* 255 */         for (int i = 0; i < classesToPreload.length; i++) {
/* 256 */           byte[] b = (byte[])preloadClassByteCode.get(i);
/* 257 */           defineClass.invoke(rootClassLoader, new Object[] { classesToPreload[i], b, Integer.valueOf(0), Integer.valueOf(b.length), pd });
/*     */         }
/*     */       
/*     */       } finally {
/*     */         
/* 262 */         defineClass.setAccessible(false);
/*     */       } 
/*     */ 
/*     */       
/* 266 */       return rootClassLoader.loadClass("native_loader.CrfSuiteNativeLoader");
/*     */     }
/* 268 */     catch (Exception e) {
/* 269 */       e.printStackTrace();
/* 270 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void loadNativeLibrary(Class<?> loaderClass) throws Exception {
/* 283 */     if (loaderClass == null) {
/* 284 */       throw new Exception("missing crfsuite native loader class");
/*     */     }
/* 286 */     File nativeLib = findNativeLibrary();
/* 287 */     if (nativeLib != null) {
/*     */       
/* 289 */       Method loadMethod = loaderClass.getDeclaredMethod("loadLibByFile", new Class[] { String.class });
/* 290 */       loadMethod.invoke(null, new Object[] { nativeLib.getAbsolutePath() });
/*     */     } else {
/*     */       
/* 293 */       Method loadMethod = loaderClass.getDeclaredMethod("loadLibrary", new Class[] { String.class });
/* 294 */       loadMethod.invoke(null, new Object[] { "crfsuite" });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String md5sum(InputStream input) throws IOException {
/* 307 */     in = new BufferedInputStream(input);
/*     */     try {
/* 309 */       MessageDigest digest = MessageDigest.getInstance("MD5");
/* 310 */       DigestInputStream digestInputStream = new DigestInputStream(in, digest);
/* 311 */       while (digestInputStream.read() >= 0);
/*     */ 
/*     */       
/* 314 */       ByteArrayOutputStream md5out = new ByteArrayOutputStream();
/* 315 */       md5out.write(digest.digest());
/* 316 */       return md5out.toString();
/*     */     }
/* 318 */     catch (NoSuchAlgorithmException e) {
/* 319 */       throw new IllegalStateException("MD5 algorithm is not available: " + e);
/*     */     } finally {
/*     */       
/* 322 */       in.close();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static File extractLibraryFile(String libFolderForCurrentOS, String libraryFileName, String targetFolder) throws Exception {
/* 336 */     String nativeLibraryFilePath = libFolderForCurrentOS + "/" + libraryFileName;
/* 337 */     String prefix = "crfsuite-" + getVersion() + "-";
/* 338 */     String extractedLibFileName = prefix + libraryFileName;
/* 339 */     File extractedLibFile = new File(targetFolder, extractedLibFileName);
/*     */     
/*     */     try {
/* 342 */       if (extractedLibFile.exists()) {
/*     */         
/* 344 */         String md5sum1 = md5sum(CrfSuiteLoader.class.getResourceAsStream(nativeLibraryFilePath));
/* 345 */         String md5sum2 = md5sum(new FileInputStream(extractedLibFile));
/*     */         
/* 347 */         if (md5sum1.equals(md5sum2)) {
/* 348 */           return new File(targetFolder, extractedLibFileName);
/*     */         }
/*     */ 
/*     */         
/* 352 */         boolean deletionSucceeded = extractedLibFile.delete();
/* 353 */         if (!deletionSucceeded) {
/* 354 */           throw new IOException("failed to remove existing native library file: " + extractedLibFile
/* 355 */               .getAbsolutePath());
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 361 */       InputStream reader = CrfSuiteLoader.class.getResourceAsStream(nativeLibraryFilePath);
/* 362 */       FileOutputStream writer = new FileOutputStream(extractedLibFile);
/* 363 */       byte[] buffer = new byte[8192];
/* 364 */       int bytesRead = 0;
/* 365 */       while ((bytesRead = reader.read(buffer)) != -1) {
/* 366 */         writer.write(buffer, 0, bytesRead);
/*     */       }
/*     */       
/* 369 */       writer.close();
/* 370 */       reader.close();
/*     */ 
/*     */       
/* 373 */       if (!System.getProperty("os.name").contains("Windows")) {
/*     */         try {
/* 375 */           Runtime.getRuntime().exec(new String[] { "chmod", "755", extractedLibFile.getAbsolutePath()
/* 376 */               }).waitFor();
/* 377 */         } catch (Throwable throwable) {}
/*     */       }
/*     */       
/* 380 */       return new File(targetFolder, extractedLibFileName);
/*     */     }
/* 382 */     catch (IOException e) {
/* 383 */       e.printStackTrace();
/* 384 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static File findNativeLibrary() throws Exception {
/* 391 */     useSystemLib = Boolean.parseBoolean(System.getProperty("org.chokkan.crfsuite.use.systemlib", "false"));
/* 392 */     if (useSystemLib) {
/* 393 */       return null;
/*     */     }
/*     */     
/* 396 */     boolean disabledBundledLibs = Boolean.parseBoolean(System.getProperty("org.chokkan.crfsuite.disable.bundled.libs", "false"));
/* 397 */     if (disabledBundledLibs) {
/* 398 */       return null;
/*     */     }
/*     */     
/* 401 */     String crfsuiteNativeLibraryPath = System.getProperty("org.chokkan.crfsuite.lib.path");
/* 402 */     String crfsuiteNativeLibraryName = System.getProperty("org.chokkan.crfsuite.lib.name");
/*     */ 
/*     */     
/* 405 */     if (crfsuiteNativeLibraryName == null) {
/* 406 */       crfsuiteNativeLibraryName = System.mapLibraryName("crfsuite");
/*     */     }
/* 408 */     if (crfsuiteNativeLibraryPath != null) {
/* 409 */       File nativeLib = new File(crfsuiteNativeLibraryPath, crfsuiteNativeLibraryName);
/* 410 */       if (nativeLib.exists()) {
/* 411 */         return nativeLib;
/*     */       }
/*     */     } 
/*     */     
/* 415 */     crfsuiteNativeLibraryPath = "/crfsuite-0.12/" + OSInfo.getNativeLibFolderPathForCurrentOS();
/*     */     
/* 417 */     if (CrfSuiteLoader.class.getResource(crfsuiteNativeLibraryPath + "/" + crfsuiteNativeLibraryName) != null) {
/*     */ 
/*     */       
/* 420 */       String tempFolder = (new File(System.getProperty("org.chokkan.crfsuite.tempdir", System.getProperty("java.io.tmpdir")))).getAbsolutePath();
/*     */ 
/*     */       
/* 423 */       return extractLibraryFile(crfsuiteNativeLibraryPath, crfsuiteNativeLibraryName, tempFolder);
/*     */     } 
/*     */     
/* 426 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getVersion() {
/* 439 */     versionFile = CrfSuiteLoader.class.getResource("/META-INF/maven/org.chokkan.crfsuite/pom.properties");
/* 440 */     if (versionFile == null) {
/* 441 */       versionFile = CrfSuiteLoader.class.getResource("/third_party/org/chokkan/crfsuite/VERSION");
/*     */     }
/* 443 */     String version = "unknown";
/*     */     try {
/* 445 */       if (versionFile != null) {
/* 446 */         Properties versionData = new Properties();
/* 447 */         versionData.load(versionFile.openStream());
/* 448 */         version = versionData.getProperty("version", version);
/* 449 */         if (version.equals("unknown"))
/* 450 */           version = versionData.getProperty("VERSION", version); 
/* 451 */         version = version.trim().replaceAll("[^0-9M\\.]", "");
/*     */       } 
/* 453 */     } catch (IOException e) {
/* 454 */       e.printStackTrace();
/*     */     } 
/* 456 */     return version;
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\github\jcrfsuit\\util\CrfSuiteLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */