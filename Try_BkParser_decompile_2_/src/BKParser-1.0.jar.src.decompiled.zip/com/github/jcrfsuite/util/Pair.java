/*    */ package com.github.jcrfsuite.util;
/*    */ 
/*    */ public class Pair<T1, T2> extends Object {
/*    */   public T1 first;
/*    */   
/*  6 */   public Pair(T1 x, T2 y) { this.first = x; this.second = y; }
/*    */   public T2 second;
/*    */   
/*  9 */   public T1 getFirst() { return (T1)this.first; }
/*    */ 
/*    */ 
/*    */   
/* 13 */   public T2 getSecond() { return (T2)this.second; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 18 */   public String toString() { return String.format("{%s, %s}", new Object[] { this.first, this.second }); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\github\jcrfsuit\\util\Pair.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */