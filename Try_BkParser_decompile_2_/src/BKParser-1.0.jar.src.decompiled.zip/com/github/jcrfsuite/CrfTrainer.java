/*     */ package com.github.jcrfsuite;
/*     */ 
/*     */ import com.github.jcrfsuite.util.CrfSuiteLoader;
/*     */ import com.github.jcrfsuite.util.Pair;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import third_party.org.chokkan.crfsuite.Attribute;
/*     */ import third_party.org.chokkan.crfsuite.Item;
/*     */ import third_party.org.chokkan.crfsuite.ItemSequence;
/*     */ import third_party.org.chokkan.crfsuite.StringList;
/*     */ import third_party.org.chokkan.crfsuite.Trainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrfTrainer
/*     */ {
/*     */   private static final String DEFAULT_ALGORITHM = "lbfgs";
/*     */   private static final String DEFAULT_GRAPHICAL_MODEL_TYPE = "crf1d";
/*     */   public static final String DEFAULT_ENCODING = "UTF-8";
/*     */   
/*     */   static  {
/*     */     try {
/*  27 */       CrfSuiteLoader.load();
/*  28 */     } catch (Exception e) {
/*  29 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pair<List<ItemSequence>, List<StringList>> loadTrainingInstances(String fileName, String encoding) throws IOException {
/*  46 */     List<ItemSequence> xseqs = new ArrayList<ItemSequence>();
/*  47 */     List<StringList> yseqs = new ArrayList<StringList>();
/*     */     
/*  49 */     ItemSequence xseq = new ItemSequence();
/*  50 */     StringList yseq = new StringList();
/*     */     
/*  52 */     try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), encoding))) {
/*     */       
/*  54 */       while ((line = br.readLine()) != null) {
/*  55 */         if (line.length() > 0) {
/*  56 */           String[] fields = line.split("\t");
/*     */           
/*  58 */           yseq.add(fields[0]);
/*     */           
/*  60 */           Item item = new Item();
/*  61 */           for (int i = 1; i < fields.length; i++) {
/*  62 */             String field = fields[i];
/*  63 */             String[] colonSplit = field.split(":", 2);
/*  64 */             if (colonSplit.length == 2) {
/*     */               
/*     */               try {
/*  67 */                 double val = Double.valueOf(colonSplit[1]).doubleValue();
/*  68 */                 item.add(new Attribute(colonSplit[0], val));
/*  69 */               } catch (NumberFormatException e) {
/*     */                 
/*  71 */                 item.add(new Attribute(field));
/*     */               } 
/*     */             } else {
/*  74 */               item.add(new Attribute(field));
/*     */             } 
/*     */           } 
/*  77 */           xseq.add(item);
/*     */           continue;
/*     */         } 
/*  80 */         xseqs.add(xseq);
/*  81 */         yseqs.add(yseq);
/*  82 */         xseq = new ItemSequence();
/*  83 */         yseq = new StringList();
/*     */       } 
/*     */       
/*  86 */       if (!xseq.isEmpty()) {
/*     */         
/*  88 */         xseqs.add(xseq);
/*  89 */         yseqs.add(yseq);
/*     */       } 
/*     */     } 
/*     */     
/*  93 */     return new Pair(xseqs, yseqs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public static void train(String fileName, String modelFile) throws IOException { train(fileName, modelFile, "lbfgs", "crf1d", "UTF-8", new Pair[0]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static void train(String fileName, String modelFile, String encoding) throws IOException { train(fileName, modelFile, "lbfgs", "crf1d", encoding, new Pair[0]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void train(String fileName, String modelFile, String algorithm, String graphicalModelType, String encoding, Pair... parameters) throws IOException {
/* 117 */     Pair<List<ItemSequence>, List<StringList>> trainingData = loadTrainingInstances(fileName, encoding);
/*     */     
/* 119 */     List<ItemSequence> xseqs = (List)trainingData.first;
/* 120 */     List<StringList> yseqs = (List)trainingData.second;
/* 121 */     train(xseqs, yseqs, modelFile, algorithm, graphicalModelType, parameters);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   public static void train(List<ItemSequence> xseqs, List<StringList> yseqs, String modelFile) { train(xseqs, yseqs, modelFile, "lbfgs", "crf1d", new Pair[0]); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void train(List<ItemSequence> xseqs, List<StringList> yseqs, String modelFile, String algorithm, String graphicalModelType, Pair... parameters) {
/* 140 */     Trainer trainer = new Trainer();
/*     */     
/* 142 */     int n = xseqs.size();
/* 143 */     for (int i = 0; i < n; i++)
/*     */     {
/* 145 */       trainer.append((ItemSequence)xseqs.get(i), (StringList)yseqs.get(i), 0);
/*     */     }
/*     */ 
/*     */     
/* 149 */     trainer.select(algorithm, graphicalModelType);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     if (parameters != null) {
/* 160 */       for (Pair<String, String> attribute : parameters) {
/* 161 */         trainer.set((String)attribute.first, (String)attribute.second);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 166 */     StringList params = trainer.params();
/* 167 */     for (int i = 0; i < params.size(); i++) {
/* 168 */       String param = params.get(i);
/* 169 */       System.out.printf("%s, %s, %s\n", new Object[] { param, trainer
/* 170 */             .get(param), trainer.help(param) });
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 175 */     trainer.train(modelFile, -1);
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\github\jcrfsuite\CrfTrainer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */