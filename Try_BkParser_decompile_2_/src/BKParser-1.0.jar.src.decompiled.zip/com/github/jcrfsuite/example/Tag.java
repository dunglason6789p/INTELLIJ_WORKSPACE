/*    */ package com.github.jcrfsuite.example;
/*    */ 
/*    */ import com.github.jcrfsuite.CrfTagger;
/*    */ import com.github.jcrfsuite.util.Pair;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Tag
/*    */ {
/*    */   public static void main(String[] args) throws IOException {
/* 27 */     if (args.length != 2) {
/* 28 */       System.out.println("Usage: " + Tag.class.getCanonicalName() + " <model file> <test file>");
/* 29 */       System.exit(1);
/*    */     } 
/* 31 */     String modelFile = args[0];
/* 32 */     String testFile = args[1];
/*    */ 
/*    */     
/* 35 */     CrfTagger crfTagger = new CrfTagger(modelFile);
/* 36 */     List<List<Pair<String, Double>>> tagProbLists = crfTagger.tag(testFile);
/*    */ 
/*    */     
/* 39 */     int total = 0;
/* 40 */     int correct = 0;
/* 41 */     System.out.println("Gold\tPredict\tProbability");
/*    */     
/* 43 */     BufferedReader br = new BufferedReader(new FileReader(testFile));
/*    */     
/* 45 */     for (List<Pair<String, Double>> tagProbs : tagProbLists) {
/* 46 */       for (Pair<String, Double> tagProb : tagProbs) {
/* 47 */         String prediction = (String)tagProb.first;
/* 48 */         Double prob = (Double)tagProb.second;
/*    */         
/* 50 */         String line = br.readLine();
/* 51 */         if (line.length() == 0)
/*    */         {
/* 53 */           line = br.readLine();
/*    */         }
/* 55 */         String gold = line.split("\t")[0];
/*    */         
/* 57 */         System.out.format("%s\t%s\t%.2f\n", new Object[] { gold, prediction, prob });
/* 58 */         total++;
/* 59 */         if (gold.equals(prediction)) {
/* 60 */           correct++;
/*    */         }
/*    */       } 
/* 63 */       System.out.println();
/*    */     } 
/* 65 */     br.close();
/*    */     
/* 67 */     System.out.format("Accuracy = %.2f%%\n", new Object[] { Double.valueOf(100.0D * correct / total) });
/*    */   }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\github\jcrfsuite\example\Tag.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */