/*    */ package com.github.jcrfsuite.example;
/*    */ 
/*    */ import com.github.jcrfsuite.CrfTrainer;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Train
/*    */ {
/*    */   public static void main(String[] args) throws IOException {
/* 20 */     if (args.length != 2) {
/* 21 */       System.out.println("Usage: " + Train.class.getCanonicalName() + " <train file> <model file>");
/* 22 */       System.exit(1);
/*    */     } 
/*    */     
/* 25 */     String trainFile = args[0];
/* 26 */     String modelFile = args[1];
/* 27 */     CrfTrainer.train(trainFile, modelFile);
/*    */   }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\github\jcrfsuite\example\Train.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */