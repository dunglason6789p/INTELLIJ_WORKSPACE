/*     */ package com.github.jcrfsuite;
/*     */ 
/*     */ import com.github.jcrfsuite.util.CrfSuiteLoader;
/*     */ import com.github.jcrfsuite.util.Pair;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import third_party.org.chokkan.crfsuite.ItemSequence;
/*     */ import third_party.org.chokkan.crfsuite.StringList;
/*     */ import third_party.org.chokkan.crfsuite.Tagger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CrfTagger
/*     */ {
/*     */   private final Tagger tagger;
/*     */   
/*     */   static  {
/*     */     try {
/*  21 */       CrfSuiteLoader.load();
/*  22 */     } catch (Exception e) {
/*  23 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   public CrfTagger(String modelFile) {
/*  27 */     this.tagger = new Tagger();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  35 */     this.tagger.open(modelFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Pair<String, Double>> tag(ItemSequence xseq) {
/*  47 */     List<Pair<String, Double>> predicted = new ArrayList<Pair<String, Double>>();
/*     */ 
/*     */     
/*  50 */     this.tagger.set(xseq);
/*  51 */     StringList labels = this.tagger.viterbi();
/*  52 */     for (int i = 0; i < labels.size(); i++) {
/*  53 */       String label = labels.get(i);
/*  54 */       predicted.add(new Pair(label, 
/*  55 */             Double.valueOf(this.tagger.marginal(label, i))));
/*     */     } 
/*     */     
/*  58 */     return predicted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<List<Pair<String, Double>>> tag(String fileName) throws IOException {
/*  74 */     List<List<Pair<String, Double>>> taggedSentences = new ArrayList<List<Pair<String, Double>>>();
/*     */ 
/*     */     
/*  77 */     Pair<List<ItemSequence>, List<StringList>> taggingSequences = CrfTrainer.loadTrainingInstances(fileName, "UTF-8");
/*  78 */     for (ItemSequence xseq : (List)taggingSequences.getFirst()) {
/*  79 */       taggedSentences.add(tag(xseq));
/*     */     }
/*     */     
/*  82 */     return taggedSentences;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<List<Pair<String, Double>>> tag(String fileName, String encoding) throws IOException {
/* 100 */     List<List<Pair<String, Double>>> taggedSentences = new ArrayList<List<Pair<String, Double>>>();
/*     */ 
/*     */     
/* 103 */     Pair<List<ItemSequence>, List<StringList>> taggingSequences = CrfTrainer.loadTrainingInstances(fileName, encoding);
/* 104 */     for (ItemSequence xseq : (List)taggingSequences.getFirst()) {
/* 105 */       taggedSentences.add(tag(xseq));
/*     */     }
/*     */     
/* 108 */     return taggedSentences;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getlabels() {
/* 115 */     StringList labels = this.tagger.labels();
/* 116 */     int numLabels = (int)labels.size();
/* 117 */     List<String> result = new ArrayList<String>(numLabels);
/* 118 */     for (int labelIndex = 0; labelIndex < numLabels; labelIndex++) {
/* 119 */       result.add(labels.get(labelIndex));
/*     */     }
/* 121 */     return result;
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\github\jcrfsuite\CrfTagger.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.0.7
 */