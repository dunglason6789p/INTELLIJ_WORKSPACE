/*     */ package com.google.gson.internal;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.GenericArrayType;
/*     */ import java.lang.reflect.GenericDeclaration;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.lang.reflect.ParameterizedType;
/*     */ import java.lang.reflect.Type;
/*     */ import java.lang.reflect.TypeVariable;
/*     */ import java.lang.reflect.WildcardType;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class $Gson$Types
/*     */ {
/*  40 */   static final Type[] EMPTY_TYPE_ARRAY = new Type[0];
/*     */ 
/*     */   
/*  43 */   private $Gson$Types() { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static ParameterizedType newParameterizedTypeWithOwner(Type ownerType, Type rawType, Type... typeArguments) { return new ParameterizedTypeImpl(ownerType, rawType, typeArguments); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static GenericArrayType arrayOf(Type componentType) { return new GenericArrayTypeImpl(componentType); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WildcardType subtypeOf(Type bound) {
/*     */     Type[] upperBounds;
/*  75 */     if (bound instanceof WildcardType) {
/*  76 */       upperBounds = ((WildcardType)bound).getUpperBounds();
/*     */     } else {
/*  78 */       upperBounds = new Type[] { bound };
/*     */     } 
/*  80 */     return new WildcardTypeImpl(upperBounds, EMPTY_TYPE_ARRAY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WildcardType supertypeOf(Type bound) {
/*     */     Type[] lowerBounds;
/*  90 */     if (bound instanceof WildcardType) {
/*  91 */       lowerBounds = ((WildcardType)bound).getLowerBounds();
/*     */     } else {
/*  93 */       lowerBounds = new Type[] { bound };
/*     */     } 
/*  95 */     return new WildcardTypeImpl(new Type[] { Object.class }, lowerBounds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type canonicalize(Type type) {
/* 104 */     if (type instanceof Class) {
/* 105 */       Class<?> c = (Class)type;
/* 106 */       return (Type)(c.isArray() ? new GenericArrayTypeImpl(canonicalize(c.getComponentType())) : c);
/*     */     } 
/* 108 */     if (type instanceof ParameterizedType) {
/* 109 */       ParameterizedType p = (ParameterizedType)type;
/* 110 */       return new ParameterizedTypeImpl(p.getOwnerType(), p
/* 111 */           .getRawType(), p.getActualTypeArguments());
/*     */     } 
/* 113 */     if (type instanceof GenericArrayType) {
/* 114 */       GenericArrayType g = (GenericArrayType)type;
/* 115 */       return new GenericArrayTypeImpl(g.getGenericComponentType());
/*     */     } 
/* 117 */     if (type instanceof WildcardType) {
/* 118 */       WildcardType w = (WildcardType)type;
/* 119 */       return new WildcardTypeImpl(w.getUpperBounds(), w.getLowerBounds());
/*     */     } 
/*     */ 
/*     */     
/* 123 */     return type;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Class<?> getRawType(Type type) {
/* 128 */     if (type instanceof Class)
/*     */     {
/* 130 */       return (Class)type;
/*     */     }
/* 132 */     if (type instanceof ParameterizedType) {
/* 133 */       ParameterizedType parameterizedType = (ParameterizedType)type;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 138 */       Type rawType = parameterizedType.getRawType();
/* 139 */       $Gson$Preconditions.checkArgument(rawType instanceof Class);
/* 140 */       return (Class)rawType;
/*     */     } 
/* 142 */     if (type instanceof GenericArrayType) {
/* 143 */       Type componentType = ((GenericArrayType)type).getGenericComponentType();
/* 144 */       return Array.newInstance(getRawType(componentType), 0).getClass();
/*     */     } 
/* 146 */     if (type instanceof TypeVariable)
/*     */     {
/*     */       
/* 149 */       return Object.class;
/*     */     }
/* 151 */     if (type instanceof WildcardType) {
/* 152 */       return getRawType(((WildcardType)type).getUpperBounds()[0]);
/*     */     }
/*     */     
/* 155 */     String className = (type == null) ? "null" : type.getClass().getName();
/* 156 */     throw new IllegalArgumentException("Expected a Class, ParameterizedType, or GenericArrayType, but <" + type + "> is of type " + className);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   static boolean equal(Object a, Object b) { return (a == b || (a != null && a.equals(b))); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean equals(Type a, Type b) {
/* 169 */     if (a == b)
/*     */     {
/* 171 */       return true;
/*     */     }
/* 173 */     if (a instanceof Class)
/*     */     {
/* 175 */       return a.equals(b);
/*     */     }
/* 177 */     if (a instanceof ParameterizedType) {
/* 178 */       if (!(b instanceof ParameterizedType)) {
/* 179 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 183 */       ParameterizedType pa = (ParameterizedType)a;
/* 184 */       ParameterizedType pb = (ParameterizedType)b;
/* 185 */       return (equal(pa.getOwnerType(), pb.getOwnerType()) && pa
/* 186 */         .getRawType().equals(pb.getRawType()) && 
/* 187 */         Arrays.equals(pa.getActualTypeArguments(), pb.getActualTypeArguments()));
/*     */     } 
/* 189 */     if (a instanceof GenericArrayType) {
/* 190 */       if (!(b instanceof GenericArrayType)) {
/* 191 */         return false;
/*     */       }
/*     */       
/* 194 */       GenericArrayType ga = (GenericArrayType)a;
/* 195 */       GenericArrayType gb = (GenericArrayType)b;
/* 196 */       return equals(ga.getGenericComponentType(), gb.getGenericComponentType());
/*     */     } 
/* 198 */     if (a instanceof WildcardType) {
/* 199 */       if (!(b instanceof WildcardType)) {
/* 200 */         return false;
/*     */       }
/*     */       
/* 203 */       WildcardType wa = (WildcardType)a;
/* 204 */       WildcardType wb = (WildcardType)b;
/* 205 */       return (Arrays.equals(wa.getUpperBounds(), wb.getUpperBounds()) && 
/* 206 */         Arrays.equals(wa.getLowerBounds(), wb.getLowerBounds()));
/*     */     } 
/* 208 */     if (a instanceof TypeVariable) {
/* 209 */       if (!(b instanceof TypeVariable)) {
/* 210 */         return false;
/*     */       }
/* 212 */       TypeVariable<?> va = (TypeVariable)a;
/* 213 */       TypeVariable<?> vb = (TypeVariable)b;
/* 214 */       return (va.getGenericDeclaration() == vb.getGenericDeclaration() && va
/* 215 */         .getName().equals(vb.getName()));
/*     */     } 
/*     */ 
/*     */     
/* 219 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 224 */   static int hashCodeOrZero(Object o) { return (o != null) ? o.hashCode() : 0; }
/*     */ 
/*     */ 
/*     */   
/* 228 */   public static String typeToString(Type type) { return (type instanceof Class) ? ((Class)type).getName() : type.toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Type getGenericSupertype(Type context, Class<?> rawType, Class<?> toResolve) {
/* 237 */     if (toResolve == rawType) {
/* 238 */       return context;
/*     */     }
/*     */ 
/*     */     
/* 242 */     if (toResolve.isInterface()) {
/* 243 */       Class[] interfaces = rawType.getInterfaces();
/* 244 */       for (int i = 0, length = interfaces.length; i < length; i++) {
/* 245 */         if (interfaces[i] == toResolve)
/* 246 */           return rawType.getGenericInterfaces()[i]; 
/* 247 */         if (toResolve.isAssignableFrom(interfaces[i])) {
/* 248 */           return getGenericSupertype(rawType.getGenericInterfaces()[i], interfaces[i], toResolve);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 254 */     if (!rawType.isInterface()) {
/* 255 */       while (rawType != Object.class) {
/* 256 */         Class<?> rawSupertype = rawType.getSuperclass();
/* 257 */         if (rawSupertype == toResolve)
/* 258 */           return rawType.getGenericSuperclass(); 
/* 259 */         if (toResolve.isAssignableFrom(rawSupertype)) {
/* 260 */           return getGenericSupertype(rawType.getGenericSuperclass(), rawSupertype, toResolve);
/*     */         }
/* 262 */         rawType = rawSupertype;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 267 */     return toResolve;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Type getSupertype(Type context, Class<?> contextRawType, Class<?> supertype) {
/* 278 */     $Gson$Preconditions.checkArgument(supertype.isAssignableFrom(contextRawType));
/* 279 */     return resolve(context, contextRawType, 
/* 280 */         getGenericSupertype(context, contextRawType, supertype));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getArrayComponentType(Type array) {
/* 288 */     return (array instanceof GenericArrayType) ? ((GenericArrayType)array)
/* 289 */       .getGenericComponentType() : ((Class)array)
/* 290 */       .getComponentType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getCollectionElementType(Type context, Class<?> contextRawType) {
/* 298 */     Type collectionType = getSupertype(context, contextRawType, Collection.class);
/*     */     
/* 300 */     if (collectionType instanceof WildcardType) {
/* 301 */       collectionType = ((WildcardType)collectionType).getUpperBounds()[0];
/*     */     }
/* 303 */     if (collectionType instanceof ParameterizedType) {
/* 304 */       return ((ParameterizedType)collectionType).getActualTypeArguments()[0];
/*     */     }
/* 306 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type[] getMapKeyAndValueTypes(Type context, Class<?> contextRawType) {
/* 319 */     if (context == java.util.Properties.class) {
/* 320 */       return new Type[] { String.class, String.class };
/*     */     }
/*     */     
/* 323 */     Type mapType = getSupertype(context, contextRawType, java.util.Map.class);
/*     */     
/* 325 */     if (mapType instanceof ParameterizedType) {
/* 326 */       ParameterizedType mapParameterizedType = (ParameterizedType)mapType;
/* 327 */       return mapParameterizedType.getActualTypeArguments();
/*     */     } 
/* 329 */     return new Type[] { Object.class, Object.class };
/*     */   }
/*     */ 
/*     */   
/* 333 */   public static Type resolve(Type context, Class<?> contextRawType, Type toResolve) { return resolve(context, contextRawType, toResolve, new HashSet()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Type resolve(Type context, Class<?> contextRawType, Type toResolve, Collection<TypeVariable> visitedTypeVariables) {
/* 340 */     while (toResolve instanceof TypeVariable) {
/* 341 */       TypeVariable<?> typeVariable = (TypeVariable)toResolve;
/* 342 */       if (visitedTypeVariables.contains(typeVariable))
/*     */       {
/* 344 */         return toResolve;
/*     */       }
/* 346 */       visitedTypeVariables.add(typeVariable);
/*     */       
/* 348 */       toResolve = resolveTypeVariable(context, contextRawType, typeVariable);
/* 349 */       if (toResolve == typeVariable) {
/* 350 */         return toResolve;
/*     */       }
/*     */     } 
/* 353 */     if (toResolve instanceof Class && ((Class)toResolve).isArray()) {
/* 354 */       Class<?> original = (Class)toResolve;
/* 355 */       Type componentType = original.getComponentType();
/* 356 */       Type newComponentType = resolve(context, contextRawType, componentType, visitedTypeVariables);
/* 357 */       return (componentType == newComponentType) ? original : 
/*     */         
/* 359 */         arrayOf(newComponentType);
/*     */     } 
/* 361 */     if (toResolve instanceof GenericArrayType) {
/* 362 */       GenericArrayType original = (GenericArrayType)toResolve;
/* 363 */       Type componentType = original.getGenericComponentType();
/* 364 */       Type newComponentType = resolve(context, contextRawType, componentType, visitedTypeVariables);
/* 365 */       return (componentType == newComponentType) ? original : 
/*     */         
/* 367 */         arrayOf(newComponentType);
/*     */     } 
/* 369 */     if (toResolve instanceof ParameterizedType) {
/* 370 */       ParameterizedType original = (ParameterizedType)toResolve;
/* 371 */       Type ownerType = original.getOwnerType();
/* 372 */       Type newOwnerType = resolve(context, contextRawType, ownerType, visitedTypeVariables);
/* 373 */       boolean changed = (newOwnerType != ownerType);
/*     */       
/* 375 */       Type[] args = original.getActualTypeArguments();
/* 376 */       for (int t = 0, length = args.length; t < length; t++) {
/* 377 */         Type resolvedTypeArgument = resolve(context, contextRawType, args[t], visitedTypeVariables);
/* 378 */         if (resolvedTypeArgument != args[t]) {
/* 379 */           if (!changed) {
/* 380 */             args = (Type[])args.clone();
/* 381 */             changed = true;
/*     */           } 
/* 383 */           args[t] = resolvedTypeArgument;
/*     */         } 
/*     */       } 
/*     */       
/* 387 */       return changed ? 
/* 388 */         newParameterizedTypeWithOwner(newOwnerType, original.getRawType(), args) : original;
/*     */     } 
/*     */     
/* 391 */     if (toResolve instanceof WildcardType) {
/* 392 */       WildcardType original = (WildcardType)toResolve;
/* 393 */       Type[] originalLowerBound = original.getLowerBounds();
/* 394 */       Type[] originalUpperBound = original.getUpperBounds();
/*     */       
/* 396 */       if (originalLowerBound.length == 1) {
/* 397 */         Type lowerBound = resolve(context, contextRawType, originalLowerBound[0], visitedTypeVariables);
/* 398 */         if (lowerBound != originalLowerBound[false]) {
/* 399 */           return supertypeOf(lowerBound);
/*     */         }
/* 401 */       } else if (originalUpperBound.length == 1) {
/* 402 */         Type upperBound = resolve(context, contextRawType, originalUpperBound[0], visitedTypeVariables);
/* 403 */         if (upperBound != originalUpperBound[false]) {
/* 404 */           return subtypeOf(upperBound);
/*     */         }
/*     */       } 
/* 407 */       return original;
/*     */     } 
/*     */     
/* 410 */     return toResolve;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Type resolveTypeVariable(Type context, Class<?> contextRawType, TypeVariable<?> unknown) {
/* 416 */     Class<?> declaredByRaw = declaringClassOf(unknown);
/*     */ 
/*     */     
/* 419 */     if (declaredByRaw == null) {
/* 420 */       return unknown;
/*     */     }
/*     */     
/* 423 */     Type declaredBy = getGenericSupertype(context, contextRawType, declaredByRaw);
/* 424 */     if (declaredBy instanceof ParameterizedType) {
/* 425 */       int index = indexOf(declaredByRaw.getTypeParameters(), unknown);
/* 426 */       return ((ParameterizedType)declaredBy).getActualTypeArguments()[index];
/*     */     } 
/*     */     
/* 429 */     return unknown;
/*     */   }
/*     */   
/*     */   private static int indexOf(Object[] array, Object toFind) {
/* 433 */     for (int i = 0, length = array.length; i < length; i++) {
/* 434 */       if (toFind.equals(array[i])) {
/* 435 */         return i;
/*     */       }
/*     */     } 
/* 438 */     throw new NoSuchElementException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> declaringClassOf(TypeVariable<?> typeVariable) {
/* 446 */     GenericDeclaration genericDeclaration = typeVariable.getGenericDeclaration();
/* 447 */     return (genericDeclaration instanceof Class) ? (Class)genericDeclaration : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 453 */   static void checkNotPrimitive(Type type) { $Gson$Preconditions.checkArgument((!(type instanceof Class) || !((Class)type).isPrimitive())); }
/*     */   
/*     */   private static final class ParameterizedTypeImpl
/*     */     implements ParameterizedType, Serializable {
/*     */     private final Type ownerType;
/*     */     private final Type rawType;
/*     */     private final Type[] typeArguments;
/*     */     private static final long serialVersionUID = 0L;
/*     */     
/*     */     public ParameterizedTypeImpl(Type ownerType, Type rawType, Type... typeArguments) {
/* 463 */       if (rawType instanceof Class) {
/* 464 */         Class<?> rawTypeAsClass = (Class)rawType;
/*     */         
/* 466 */         boolean isStaticOrTopLevelClass = (Modifier.isStatic(rawTypeAsClass.getModifiers()) || rawTypeAsClass.getEnclosingClass() == null);
/* 467 */         $Gson$Preconditions.checkArgument((ownerType != null || isStaticOrTopLevelClass));
/*     */       } 
/*     */       
/* 470 */       this.ownerType = (ownerType == null) ? null : $Gson$Types.canonicalize(ownerType);
/* 471 */       this.rawType = $Gson$Types.canonicalize(rawType);
/* 472 */       this.typeArguments = (Type[])typeArguments.clone();
/* 473 */       for (int t = 0, length = this.typeArguments.length; t < length; t++) {
/* 474 */         $Gson$Preconditions.checkNotNull(this.typeArguments[t]);
/* 475 */         $Gson$Types.checkNotPrimitive(this.typeArguments[t]);
/* 476 */         this.typeArguments[t] = $Gson$Types.canonicalize(this.typeArguments[t]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 481 */     public Type[] getActualTypeArguments() { return (Type[])this.typeArguments.clone(); }
/*     */ 
/*     */ 
/*     */     
/* 485 */     public Type getRawType() { return this.rawType; }
/*     */ 
/*     */ 
/*     */     
/* 489 */     public Type getOwnerType() { return this.ownerType; }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 493 */       return (other instanceof ParameterizedType && 
/* 494 */         $Gson$Types.equals(this, (ParameterizedType)other));
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 498 */       return Arrays.hashCode(this.typeArguments) ^ this.rawType
/* 499 */         .hashCode() ^ 
/* 500 */         $Gson$Types.hashCodeOrZero(this.ownerType);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 504 */       int length = this.typeArguments.length;
/* 505 */       if (length == 0) {
/* 506 */         return $Gson$Types.typeToString(this.rawType);
/*     */       }
/*     */       
/* 509 */       StringBuilder stringBuilder = new StringBuilder(30 * (length + 1));
/* 510 */       stringBuilder.append($Gson$Types.typeToString(this.rawType)).append("<").append($Gson$Types.typeToString(this.typeArguments[0]));
/* 511 */       for (int i = 1; i < length; i++) {
/* 512 */         stringBuilder.append(", ").append($Gson$Types.typeToString(this.typeArguments[i]));
/*     */       }
/* 514 */       return stringBuilder.append(">").toString();
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class GenericArrayTypeImpl
/*     */     implements GenericArrayType, Serializable
/*     */   {
/*     */     private final Type componentType;
/*     */     private static final long serialVersionUID = 0L;
/*     */     
/* 524 */     public GenericArrayTypeImpl(Type componentType) { this.componentType = $Gson$Types.canonicalize(componentType); }
/*     */ 
/*     */ 
/*     */     
/* 528 */     public Type getGenericComponentType() { return this.componentType; }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 532 */       return (o instanceof GenericArrayType && 
/* 533 */         $Gson$Types.equals(this, (GenericArrayType)o));
/*     */     }
/*     */ 
/*     */     
/* 537 */     public int hashCode() { return this.componentType.hashCode(); }
/*     */ 
/*     */ 
/*     */     
/* 541 */     public String toString() { return $Gson$Types.typeToString(this.componentType) + "[]"; }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class WildcardTypeImpl
/*     */     implements WildcardType, Serializable
/*     */   {
/*     */     private final Type upperBound;
/*     */     
/*     */     private final Type lowerBound;
/*     */     
/*     */     private static final long serialVersionUID = 0L;
/*     */ 
/*     */     
/*     */     public WildcardTypeImpl(Type[] upperBounds, Type[] lowerBounds) {
/* 557 */       $Gson$Preconditions.checkArgument((lowerBounds.length <= 1));
/* 558 */       $Gson$Preconditions.checkArgument((upperBounds.length == 1));
/*     */       
/* 560 */       if (lowerBounds.length == 1) {
/* 561 */         $Gson$Preconditions.checkNotNull(lowerBounds[0]);
/* 562 */         $Gson$Types.checkNotPrimitive(lowerBounds[0]);
/* 563 */         $Gson$Preconditions.checkArgument((upperBounds[false] == Object.class));
/* 564 */         this.lowerBound = $Gson$Types.canonicalize(lowerBounds[0]);
/* 565 */         this.upperBound = Object.class;
/*     */       } else {
/*     */         
/* 568 */         $Gson$Preconditions.checkNotNull(upperBounds[0]);
/* 569 */         $Gson$Types.checkNotPrimitive(upperBounds[0]);
/* 570 */         this.lowerBound = null;
/* 571 */         this.upperBound = $Gson$Types.canonicalize(upperBounds[0]);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 576 */     public Type[] getUpperBounds() { return new Type[] { this.upperBound }; }
/*     */ 
/*     */ 
/*     */     
/* 580 */     public Type[] getLowerBounds() { new Type[1][0] = this.lowerBound; return (this.lowerBound != null) ? new Type[1] : $Gson$Types.EMPTY_TYPE_ARRAY; }
/*     */ 
/*     */     
/*     */     public boolean equals(Object other) {
/* 584 */       return (other instanceof WildcardType && 
/* 585 */         $Gson$Types.equals(this, (WildcardType)other));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 590 */     public int hashCode() { return ((this.lowerBound != null) ? (31 + this.lowerBound.hashCode()) : 1) ^ 31 + this.upperBound
/* 591 */         .hashCode(); }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 595 */       if (this.lowerBound != null)
/* 596 */         return "? super " + $Gson$Types.typeToString(this.lowerBound); 
/* 597 */       if (this.upperBound == Object.class) {
/* 598 */         return "?";
/*     */       }
/* 600 */       return "? extends " + $Gson$Types.typeToString(this.upperBound);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\internal\$Gson$Types.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */