/*     */ package com.google.gson.internal.bind;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonIOException;
/*     */ import com.google.gson.JsonNull;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import com.google.gson.TypeAdapter;
/*     */ import com.google.gson.TypeAdapterFactory;
/*     */ import com.google.gson.annotations.SerializedName;
/*     */ import com.google.gson.internal.LazilyParsedNumber;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import com.google.gson.stream.JsonToken;
/*     */ import com.google.gson.stream.JsonWriter;
/*     */ import java.io.IOException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.Calendar;
/*     */ import java.util.Currency;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.UUID;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import java.util.concurrent.atomic.AtomicIntegerArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypeAdapters
/*     */ {
/*  65 */   private TypeAdapters() { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static final TypeAdapter<Class> CLASS = (new TypeAdapter<Class>()
/*     */     {
/*     */       public void write(JsonWriter out, Class value) throws IOException {
/*  72 */         throw new UnsupportedOperationException("Attempted to serialize java.lang.Class: " + value
/*  73 */             .getName() + ". Forgot to register a type adapter?");
/*     */       }
/*     */       
/*     */       public Class read(JsonReader in) throws IOException {
/*  77 */         throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
/*     */       }
/*  80 */     }).nullSafe();
/*     */   
/*  82 */   public static final TypeAdapterFactory CLASS_FACTORY = newFactory(Class.class, CLASS);
/*     */   
/*  84 */   public static final TypeAdapter<BitSet> BIT_SET = (new TypeAdapter<BitSet>() {
/*     */       public BitSet read(JsonReader in) throws IOException {
/*  86 */         BitSet bitset = new BitSet();
/*  87 */         in.beginArray();
/*  88 */         int i = 0;
/*  89 */         JsonToken tokenType = in.peek();
/*  90 */         while (tokenType != JsonToken.END_ARRAY) {
/*     */           String stringValue; boolean set, set;
/*  92 */           switch (TypeAdapters.null.$SwitchMap$com$google$gson$stream$JsonToken[tokenType.ordinal()]) {
/*     */             case 1:
/*  94 */               set = (in.nextInt() != 0);
/*     */               break;
/*     */             case 2:
/*  97 */               set = in.nextBoolean();
/*     */               break;
/*     */             case 3:
/* 100 */               stringValue = in.nextString();
/*     */               try {
/* 102 */                 set = (Integer.parseInt(stringValue) != 0);
/* 103 */               } catch (NumberFormatException e) {
/* 104 */                 throw new JsonSyntaxException("Error: Expecting: bitset number value (1, 0), Found: " + stringValue);
/*     */               } 
/*     */               break;
/*     */             
/*     */             default:
/* 109 */               throw new JsonSyntaxException("Invalid bitset value type: " + tokenType);
/*     */           } 
/* 111 */           if (set) {
/* 112 */             bitset.set(i);
/*     */           }
/* 114 */           i++;
/* 115 */           tokenType = in.peek();
/*     */         } 
/* 117 */         in.endArray();
/* 118 */         return bitset;
/*     */       }
/*     */       
/*     */       public void write(JsonWriter out, BitSet src) throws IOException {
/* 122 */         out.beginArray();
/* 123 */         for (int i = 0, length = src.length(); i < length; i++) {
/* 124 */           int value = src.get(i) ? 1 : 0;
/* 125 */           out.value(value);
/*     */         } 
/* 127 */         out.endArray();
/*     */       }
/* 129 */     }).nullSafe();
/*     */   
/* 131 */   public static final TypeAdapterFactory BIT_SET_FACTORY = newFactory(BitSet.class, BIT_SET);
/*     */   
/* 133 */   public static final TypeAdapter<Boolean> BOOLEAN = new TypeAdapter<Boolean>()
/*     */     {
/*     */       public Boolean read(JsonReader in) throws IOException {
/* 136 */         if (in.peek() == JsonToken.NULL) {
/* 137 */           in.nextNull();
/* 138 */           return null;
/* 139 */         }  if (in.peek() == JsonToken.STRING)
/*     */         {
/* 141 */           return Boolean.valueOf(Boolean.parseBoolean(in.nextString()));
/*     */         }
/* 143 */         return Boolean.valueOf(in.nextBoolean());
/*     */       }
/*     */ 
/*     */       
/* 147 */       public void write(JsonWriter out, Boolean value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public static final TypeAdapter<Boolean> BOOLEAN_AS_STRING = new TypeAdapter<Boolean>() {
/*     */       public Boolean read(JsonReader in) throws IOException {
/* 157 */         if (in.peek() == JsonToken.NULL) {
/* 158 */           in.nextNull();
/* 159 */           return null;
/*     */         } 
/* 161 */         return Boolean.valueOf(in.nextString());
/*     */       }
/*     */ 
/*     */       
/* 165 */       public void write(JsonWriter out, Boolean value) throws IOException { out.value((value == null) ? "null" : value.toString()); }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 170 */   public static final TypeAdapterFactory BOOLEAN_FACTORY = newFactory(boolean.class, Boolean.class, BOOLEAN);
/*     */   
/* 172 */   public static final TypeAdapter<Number> BYTE = new TypeAdapter<Number>()
/*     */     {
/*     */       public Number read(JsonReader in) throws IOException {
/* 175 */         if (in.peek() == JsonToken.NULL) {
/* 176 */           in.nextNull();
/* 177 */           return null;
/*     */         } 
/*     */         try {
/* 180 */           int intValue = in.nextInt();
/* 181 */           return Byte.valueOf((byte)intValue);
/* 182 */         } catch (NumberFormatException e) {
/* 183 */           throw new JsonSyntaxException(e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 188 */       public void write(JsonWriter out, Number value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 193 */   public static final TypeAdapterFactory BYTE_FACTORY = newFactory(byte.class, Byte.class, BYTE);
/*     */   
/* 195 */   public static final TypeAdapter<Number> SHORT = new TypeAdapter<Number>()
/*     */     {
/*     */       public Number read(JsonReader in) throws IOException {
/* 198 */         if (in.peek() == JsonToken.NULL) {
/* 199 */           in.nextNull();
/* 200 */           return null;
/*     */         } 
/*     */         try {
/* 203 */           return Short.valueOf((short)in.nextInt());
/* 204 */         } catch (NumberFormatException e) {
/* 205 */           throw new JsonSyntaxException(e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 210 */       public void write(JsonWriter out, Number value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 215 */   public static final TypeAdapterFactory SHORT_FACTORY = newFactory(short.class, Short.class, SHORT);
/*     */   
/* 217 */   public static final TypeAdapter<Number> INTEGER = new TypeAdapter<Number>()
/*     */     {
/*     */       public Number read(JsonReader in) throws IOException {
/* 220 */         if (in.peek() == JsonToken.NULL) {
/* 221 */           in.nextNull();
/* 222 */           return null;
/*     */         } 
/*     */         try {
/* 225 */           return Integer.valueOf(in.nextInt());
/* 226 */         } catch (NumberFormatException e) {
/* 227 */           throw new JsonSyntaxException(e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 232 */       public void write(JsonWriter out, Number value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */   
/* 236 */   public static final TypeAdapterFactory INTEGER_FACTORY = newFactory(int.class, Integer.class, INTEGER);
/*     */   
/* 238 */   public static final TypeAdapter<AtomicInteger> ATOMIC_INTEGER = (new TypeAdapter<AtomicInteger>() {
/*     */       public AtomicInteger read(JsonReader in) throws IOException {
/*     */         try {
/* 241 */           return new AtomicInteger(in.nextInt());
/* 242 */         } catch (NumberFormatException e) {
/* 243 */           throw new JsonSyntaxException(e);
/*     */         } 
/*     */       }
/*     */       
/* 247 */       public void write(JsonWriter out, AtomicInteger value) throws IOException { out.value(value.get()); }
/*     */     
/* 249 */     }).nullSafe();
/*     */   
/* 251 */   public static final TypeAdapterFactory ATOMIC_INTEGER_FACTORY = newFactory(AtomicInteger.class, ATOMIC_INTEGER);
/*     */   
/* 253 */   public static final TypeAdapter<AtomicBoolean> ATOMIC_BOOLEAN = (new TypeAdapter<AtomicBoolean>()
/*     */     {
/* 255 */       public AtomicBoolean read(JsonReader in) throws IOException { return new AtomicBoolean(in.nextBoolean()); }
/*     */       
/*     */       public void write(JsonWriter out, AtomicBoolean value) throws IOException {
/* 258 */         out.value(value.get());
/*     */       }
/* 260 */     }).nullSafe();
/*     */   
/* 262 */   public static final TypeAdapterFactory ATOMIC_BOOLEAN_FACTORY = newFactory(AtomicBoolean.class, ATOMIC_BOOLEAN);
/*     */   
/* 264 */   public static final TypeAdapter<AtomicIntegerArray> ATOMIC_INTEGER_ARRAY = (new TypeAdapter<AtomicIntegerArray>() {
/*     */       public AtomicIntegerArray read(JsonReader in) throws IOException {
/* 266 */         List<Integer> list = new ArrayList<Integer>();
/* 267 */         in.beginArray();
/* 268 */         while (in.hasNext()) {
/*     */           try {
/* 270 */             int integer = in.nextInt();
/* 271 */             list.add(Integer.valueOf(integer));
/* 272 */           } catch (NumberFormatException e) {
/* 273 */             throw new JsonSyntaxException(e);
/*     */           } 
/*     */         } 
/* 276 */         in.endArray();
/* 277 */         int length = list.size();
/* 278 */         AtomicIntegerArray array = new AtomicIntegerArray(length);
/* 279 */         for (int i = 0; i < length; i++) {
/* 280 */           array.set(i, ((Integer)list.get(i)).intValue());
/*     */         }
/* 282 */         return array;
/*     */       }
/*     */       public void write(JsonWriter out, AtomicIntegerArray value) throws IOException {
/* 285 */         out.beginArray();
/* 286 */         for (int i = 0, length = value.length(); i < length; i++) {
/* 287 */           out.value(value.get(i));
/*     */         }
/* 289 */         out.endArray();
/*     */       }
/* 291 */     }).nullSafe();
/*     */   
/* 293 */   public static final TypeAdapterFactory ATOMIC_INTEGER_ARRAY_FACTORY = newFactory(AtomicIntegerArray.class, ATOMIC_INTEGER_ARRAY);
/*     */   
/* 295 */   public static final TypeAdapter<Number> LONG = new TypeAdapter<Number>()
/*     */     {
/*     */       public Number read(JsonReader in) throws IOException {
/* 298 */         if (in.peek() == JsonToken.NULL) {
/* 299 */           in.nextNull();
/* 300 */           return null;
/*     */         } 
/*     */         try {
/* 303 */           return Long.valueOf(in.nextLong());
/* 304 */         } catch (NumberFormatException e) {
/* 305 */           throw new JsonSyntaxException(e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 310 */       public void write(JsonWriter out, Number value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */   
/* 314 */   public static final TypeAdapter<Number> FLOAT = new TypeAdapter<Number>()
/*     */     {
/*     */       public Number read(JsonReader in) throws IOException {
/* 317 */         if (in.peek() == JsonToken.NULL) {
/* 318 */           in.nextNull();
/* 319 */           return null;
/*     */         } 
/* 321 */         return Float.valueOf((float)in.nextDouble());
/*     */       }
/*     */ 
/*     */       
/* 325 */       public void write(JsonWriter out, Number value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */   
/* 329 */   public static final TypeAdapter<Number> DOUBLE = new TypeAdapter<Number>()
/*     */     {
/*     */       public Number read(JsonReader in) throws IOException {
/* 332 */         if (in.peek() == JsonToken.NULL) {
/* 333 */           in.nextNull();
/* 334 */           return null;
/*     */         } 
/* 336 */         return Double.valueOf(in.nextDouble());
/*     */       }
/*     */ 
/*     */       
/* 340 */       public void write(JsonWriter out, Number value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */   
/* 344 */   public static final TypeAdapter<Number> NUMBER = new TypeAdapter<Number>()
/*     */     {
/*     */       public Number read(JsonReader in) throws IOException {
/* 347 */         JsonToken jsonToken = in.peek();
/* 348 */         switch (TypeAdapters.null.$SwitchMap$com$google$gson$stream$JsonToken[jsonToken.ordinal()]) {
/*     */           case 4:
/* 350 */             in.nextNull();
/* 351 */             return null;
/*     */           case 1:
/*     */           case 3:
/* 354 */             return new LazilyParsedNumber(in.nextString());
/*     */         } 
/* 356 */         throw new JsonSyntaxException("Expecting number, got: " + jsonToken);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 361 */       public void write(JsonWriter out, Number value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */   
/* 365 */   public static final TypeAdapterFactory NUMBER_FACTORY = newFactory(Number.class, NUMBER);
/*     */   
/* 367 */   public static final TypeAdapter<Character> CHARACTER = new TypeAdapter<Character>()
/*     */     {
/*     */       public Character read(JsonReader in) throws IOException {
/* 370 */         if (in.peek() == JsonToken.NULL) {
/* 371 */           in.nextNull();
/* 372 */           return null;
/*     */         } 
/* 374 */         String str = in.nextString();
/* 375 */         if (str.length() != 1) {
/* 376 */           throw new JsonSyntaxException("Expecting character, got: " + str);
/*     */         }
/* 378 */         return Character.valueOf(str.charAt(0));
/*     */       }
/*     */ 
/*     */       
/* 382 */       public void write(JsonWriter out, Character value) throws IOException { out.value((value == null) ? null : String.valueOf(value)); }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 387 */   public static final TypeAdapterFactory CHARACTER_FACTORY = newFactory(char.class, Character.class, CHARACTER);
/*     */   
/* 389 */   public static final TypeAdapter<String> STRING = new TypeAdapter<String>()
/*     */     {
/*     */       public String read(JsonReader in) throws IOException {
/* 392 */         JsonToken peek = in.peek();
/* 393 */         if (peek == JsonToken.NULL) {
/* 394 */           in.nextNull();
/* 395 */           return null;
/*     */         } 
/*     */         
/* 398 */         if (peek == JsonToken.BOOLEAN) {
/* 399 */           return Boolean.toString(in.nextBoolean());
/*     */         }
/* 401 */         return in.nextString();
/*     */       }
/*     */ 
/*     */       
/* 405 */       public void write(JsonWriter out, String value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */   
/* 409 */   public static final TypeAdapter<BigDecimal> BIG_DECIMAL = new TypeAdapter<BigDecimal>() {
/*     */       public BigDecimal read(JsonReader in) throws IOException {
/* 411 */         if (in.peek() == JsonToken.NULL) {
/* 412 */           in.nextNull();
/* 413 */           return null;
/*     */         } 
/*     */         try {
/* 416 */           return new BigDecimal(in.nextString());
/* 417 */         } catch (NumberFormatException e) {
/* 418 */           throw new JsonSyntaxException(e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 423 */       public void write(JsonWriter out, BigDecimal value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */   
/* 427 */   public static final TypeAdapter<BigInteger> BIG_INTEGER = new TypeAdapter<BigInteger>() {
/*     */       public BigInteger read(JsonReader in) throws IOException {
/* 429 */         if (in.peek() == JsonToken.NULL) {
/* 430 */           in.nextNull();
/* 431 */           return null;
/*     */         } 
/*     */         try {
/* 434 */           return new BigInteger(in.nextString());
/* 435 */         } catch (NumberFormatException e) {
/* 436 */           throw new JsonSyntaxException(e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 441 */       public void write(JsonWriter out, BigInteger value) throws IOException { out.value(value); }
/*     */     };
/*     */ 
/*     */   
/* 445 */   public static final TypeAdapterFactory STRING_FACTORY = newFactory(String.class, STRING);
/*     */   
/* 447 */   public static final TypeAdapter<StringBuilder> STRING_BUILDER = new TypeAdapter<StringBuilder>()
/*     */     {
/*     */       public StringBuilder read(JsonReader in) throws IOException {
/* 450 */         if (in.peek() == JsonToken.NULL) {
/* 451 */           in.nextNull();
/* 452 */           return null;
/*     */         } 
/* 454 */         return new StringBuilder(in.nextString());
/*     */       }
/*     */ 
/*     */       
/* 458 */       public void write(JsonWriter out, StringBuilder value) throws IOException { out.value((value == null) ? null : value.toString()); }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 463 */   public static final TypeAdapterFactory STRING_BUILDER_FACTORY = newFactory(StringBuilder.class, STRING_BUILDER);
/*     */   
/* 465 */   public static final TypeAdapter<StringBuffer> STRING_BUFFER = new TypeAdapter<StringBuffer>()
/*     */     {
/*     */       public StringBuffer read(JsonReader in) throws IOException {
/* 468 */         if (in.peek() == JsonToken.NULL) {
/* 469 */           in.nextNull();
/* 470 */           return null;
/*     */         } 
/* 472 */         return new StringBuffer(in.nextString());
/*     */       }
/*     */ 
/*     */       
/* 476 */       public void write(JsonWriter out, StringBuffer value) throws IOException { out.value((value == null) ? null : value.toString()); }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 481 */   public static final TypeAdapterFactory STRING_BUFFER_FACTORY = newFactory(StringBuffer.class, STRING_BUFFER);
/*     */   
/* 483 */   public static final TypeAdapter<URL> URL = new TypeAdapter<URL>()
/*     */     {
/*     */       public URL read(JsonReader in) throws IOException {
/* 486 */         if (in.peek() == JsonToken.NULL) {
/* 487 */           in.nextNull();
/* 488 */           return null;
/*     */         } 
/* 490 */         String nextString = in.nextString();
/* 491 */         return "null".equals(nextString) ? null : new URL(nextString);
/*     */       }
/*     */ 
/*     */       
/* 495 */       public void write(JsonWriter out, URL value) throws IOException { out.value((value == null) ? null : value.toExternalForm()); }
/*     */     };
/*     */ 
/*     */   
/* 499 */   public static final TypeAdapterFactory URL_FACTORY = newFactory(URL.class, URL);
/*     */   
/* 501 */   public static final TypeAdapter<URI> URI = new TypeAdapter<URI>()
/*     */     {
/*     */       public URI read(JsonReader in) throws IOException {
/* 504 */         if (in.peek() == JsonToken.NULL) {
/* 505 */           in.nextNull();
/* 506 */           return null;
/*     */         } 
/*     */         try {
/* 509 */           String nextString = in.nextString();
/* 510 */           return "null".equals(nextString) ? null : new URI(nextString);
/* 511 */         } catch (URISyntaxException e) {
/* 512 */           throw new JsonIOException(e);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 517 */       public void write(JsonWriter out, URI value) throws IOException { out.value((value == null) ? null : value.toASCIIString()); }
/*     */     };
/*     */ 
/*     */   
/* 521 */   public static final TypeAdapterFactory URI_FACTORY = newFactory(URI.class, URI);
/*     */   
/* 523 */   public static final TypeAdapter<InetAddress> INET_ADDRESS = new TypeAdapter<InetAddress>()
/*     */     {
/*     */       public InetAddress read(JsonReader in) throws IOException {
/* 526 */         if (in.peek() == JsonToken.NULL) {
/* 527 */           in.nextNull();
/* 528 */           return null;
/*     */         } 
/*     */         
/* 531 */         return InetAddress.getByName(in.nextString());
/*     */       }
/*     */ 
/*     */       
/* 535 */       public void write(JsonWriter out, InetAddress value) throws IOException { out.value((value == null) ? null : value.getHostAddress()); }
/*     */     };
/*     */ 
/*     */ 
/*     */   
/* 540 */   public static final TypeAdapterFactory INET_ADDRESS_FACTORY = newTypeHierarchyFactory(InetAddress.class, INET_ADDRESS);
/*     */   
/* 542 */   public static final TypeAdapter<UUID> UUID = new TypeAdapter<UUID>()
/*     */     {
/*     */       public UUID read(JsonReader in) throws IOException {
/* 545 */         if (in.peek() == JsonToken.NULL) {
/* 546 */           in.nextNull();
/* 547 */           return null;
/*     */         } 
/* 549 */         return UUID.fromString(in.nextString());
/*     */       }
/*     */ 
/*     */       
/* 553 */       public void write(JsonWriter out, UUID value) throws IOException { out.value((value == null) ? null : value.toString()); }
/*     */     };
/*     */ 
/*     */   
/* 557 */   public static final TypeAdapterFactory UUID_FACTORY = newFactory(UUID.class, UUID);
/*     */   
/* 559 */   public static final TypeAdapter<Currency> CURRENCY = (new TypeAdapter<Currency>()
/*     */     {
/*     */       public Currency read(JsonReader in) throws IOException {
/* 562 */         return Currency.getInstance(in.nextString());
/*     */       }
/*     */       
/*     */       public void write(JsonWriter out, Currency value) throws IOException {
/* 566 */         out.value(value.getCurrencyCode());
/*     */       }
/* 568 */     }).nullSafe();
/* 569 */   public static final TypeAdapterFactory CURRENCY_FACTORY = newFactory(Currency.class, CURRENCY);
/*     */   
/* 571 */   public static final TypeAdapterFactory TIMESTAMP_FACTORY = new TypeAdapterFactory()
/*     */     {
/*     */       public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 574 */         if (typeToken.getRawType() != Timestamp.class) {
/* 575 */           return null;
/*     */         }
/*     */         
/* 578 */         final TypeAdapter<Date> dateTypeAdapter = gson.getAdapter(Date.class);
/* 579 */         return new TypeAdapter<Timestamp>() {
/*     */             public Timestamp read(JsonReader in) throws IOException {
/* 581 */               Date date = (Date)dateTypeAdapter.read(in);
/* 582 */               return (date != null) ? new Timestamp(date.getTime()) : null;
/*     */             }
/*     */ 
/*     */             
/* 586 */             public void write(JsonWriter out, Timestamp value) throws IOException { dateTypeAdapter.write(out, value); }
/*     */           };
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 592 */   public static final TypeAdapter<Calendar> CALENDAR = new TypeAdapter<Calendar>()
/*     */     {
/*     */       private static final String YEAR = "year";
/*     */       private static final String MONTH = "month";
/*     */       private static final String DAY_OF_MONTH = "dayOfMonth";
/*     */       private static final String HOUR_OF_DAY = "hourOfDay";
/*     */       private static final String MINUTE = "minute";
/*     */       private static final String SECOND = "second";
/*     */       
/*     */       public Calendar read(JsonReader in) throws IOException {
/* 602 */         if (in.peek() == JsonToken.NULL) {
/* 603 */           in.nextNull();
/* 604 */           return null;
/*     */         } 
/* 606 */         in.beginObject();
/* 607 */         int year = 0;
/* 608 */         int month = 0;
/* 609 */         int dayOfMonth = 0;
/* 610 */         int hourOfDay = 0;
/* 611 */         int minute = 0;
/* 612 */         int second = 0;
/* 613 */         while (in.peek() != JsonToken.END_OBJECT) {
/* 614 */           String name = in.nextName();
/* 615 */           int value = in.nextInt();
/* 616 */           if ("year".equals(name)) {
/* 617 */             year = value; continue;
/* 618 */           }  if ("month".equals(name)) {
/* 619 */             month = value; continue;
/* 620 */           }  if ("dayOfMonth".equals(name)) {
/* 621 */             dayOfMonth = value; continue;
/* 622 */           }  if ("hourOfDay".equals(name)) {
/* 623 */             hourOfDay = value; continue;
/* 624 */           }  if ("minute".equals(name)) {
/* 625 */             minute = value; continue;
/* 626 */           }  if ("second".equals(name)) {
/* 627 */             second = value;
/*     */           }
/*     */         } 
/* 630 */         in.endObject();
/* 631 */         return new GregorianCalendar(year, month, dayOfMonth, hourOfDay, minute, second);
/*     */       }
/*     */ 
/*     */       
/*     */       public void write(JsonWriter out, Calendar value) throws IOException {
/* 636 */         if (value == null) {
/* 637 */           out.nullValue();
/*     */           return;
/*     */         } 
/* 640 */         out.beginObject();
/* 641 */         out.name("year");
/* 642 */         out.value(value.get(1));
/* 643 */         out.name("month");
/* 644 */         out.value(value.get(2));
/* 645 */         out.name("dayOfMonth");
/* 646 */         out.value(value.get(5));
/* 647 */         out.name("hourOfDay");
/* 648 */         out.value(value.get(11));
/* 649 */         out.name("minute");
/* 650 */         out.value(value.get(12));
/* 651 */         out.name("second");
/* 652 */         out.value(value.get(13));
/* 653 */         out.endObject();
/*     */       }
/*     */     };
/*     */ 
/*     */   
/* 658 */   public static final TypeAdapterFactory CALENDAR_FACTORY = newFactoryForMultipleTypes(Calendar.class, GregorianCalendar.class, CALENDAR);
/*     */   
/* 660 */   public static final TypeAdapter<Locale> LOCALE = new TypeAdapter<Locale>()
/*     */     {
/*     */       public Locale read(JsonReader in) throws IOException {
/* 663 */         if (in.peek() == JsonToken.NULL) {
/* 664 */           in.nextNull();
/* 665 */           return null;
/*     */         } 
/* 667 */         String locale = in.nextString();
/* 668 */         StringTokenizer tokenizer = new StringTokenizer(locale, "_");
/* 669 */         String language = null;
/* 670 */         String country = null;
/* 671 */         String variant = null;
/* 672 */         if (tokenizer.hasMoreElements()) {
/* 673 */           language = tokenizer.nextToken();
/*     */         }
/* 675 */         if (tokenizer.hasMoreElements()) {
/* 676 */           country = tokenizer.nextToken();
/*     */         }
/* 678 */         if (tokenizer.hasMoreElements()) {
/* 679 */           variant = tokenizer.nextToken();
/*     */         }
/* 681 */         if (country == null && variant == null)
/* 682 */           return new Locale(language); 
/* 683 */         if (variant == null) {
/* 684 */           return new Locale(language, country);
/*     */         }
/* 686 */         return new Locale(language, country, variant);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 691 */       public void write(JsonWriter out, Locale value) throws IOException { out.value((value == null) ? null : value.toString()); }
/*     */     };
/*     */ 
/*     */   
/* 695 */   public static final TypeAdapterFactory LOCALE_FACTORY = newFactory(Locale.class, LOCALE);
/*     */   
/* 697 */   public static final TypeAdapter<JsonElement> JSON_ELEMENT = new TypeAdapter<JsonElement>() { public JsonElement read(JsonReader in) throws IOException { JsonObject object; JsonArray array;
/*     */         String number;
/* 699 */         switch (TypeAdapters.null.$SwitchMap$com$google$gson$stream$JsonToken[in.peek().ordinal()]) {
/*     */           case 3:
/* 701 */             return new JsonPrimitive(in.nextString());
/*     */           case 1:
/* 703 */             number = in.nextString();
/* 704 */             return new JsonPrimitive(new LazilyParsedNumber(number));
/*     */           case 2:
/* 706 */             return new JsonPrimitive(Boolean.valueOf(in.nextBoolean()));
/*     */           case 4:
/* 708 */             in.nextNull();
/* 709 */             return JsonNull.INSTANCE;
/*     */           case 5:
/* 711 */             array = new JsonArray();
/* 712 */             in.beginArray();
/* 713 */             while (in.hasNext()) {
/* 714 */               array.add(read(in));
/*     */             }
/* 716 */             in.endArray();
/* 717 */             return array;
/*     */           case 6:
/* 719 */             object = new JsonObject();
/* 720 */             in.beginObject();
/* 721 */             while (in.hasNext()) {
/* 722 */               object.add(in.nextName(), read(in));
/*     */             }
/* 724 */             in.endObject();
/* 725 */             return object;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 731 */         throw new IllegalArgumentException(); }
/*     */ 
/*     */ 
/*     */       
/*     */       public void write(JsonWriter out, JsonElement value) throws IOException {
/* 736 */         if (value == null || value.isJsonNull()) {
/* 737 */           out.nullValue();
/* 738 */         } else if (value.isJsonPrimitive()) {
/* 739 */           JsonPrimitive primitive = value.getAsJsonPrimitive();
/* 740 */           if (primitive.isNumber()) {
/* 741 */             out.value(primitive.getAsNumber());
/* 742 */           } else if (primitive.isBoolean()) {
/* 743 */             out.value(primitive.getAsBoolean());
/*     */           } else {
/* 745 */             out.value(primitive.getAsString());
/*     */           }
/*     */         
/* 748 */         } else if (value.isJsonArray()) {
/* 749 */           out.beginArray();
/* 750 */           for (JsonElement e : value.getAsJsonArray()) {
/* 751 */             write(out, e);
/*     */           }
/* 753 */           out.endArray();
/*     */         }
/* 755 */         else if (value.isJsonObject()) {
/* 756 */           out.beginObject();
/* 757 */           for (Map.Entry<String, JsonElement> e : value.getAsJsonObject().entrySet()) {
/* 758 */             out.name((String)e.getKey());
/* 759 */             write(out, (JsonElement)e.getValue());
/*     */           } 
/* 761 */           out.endObject();
/*     */         } else {
/*     */           
/* 764 */           throw new IllegalArgumentException("Couldn't write " + value.getClass());
/*     */         } 
/*     */       } }
/*     */   ;
/*     */ 
/*     */   
/* 770 */   public static final TypeAdapterFactory JSON_ELEMENT_FACTORY = newTypeHierarchyFactory(JsonElement.class, JSON_ELEMENT);
/*     */   
/*     */   private static final class EnumTypeAdapter<T extends Enum<T>> extends TypeAdapter<T> {
/* 773 */     private final Map<String, T> nameToConstant = new HashMap();
/* 774 */     private final Map<T, String> constantToName = new HashMap(); public EnumTypeAdapter(Class<T> classOfT) { try {
/*     */         Enum[] arrayOfEnum;
/*     */         int i;
/*     */         byte b;
/* 778 */         for (arrayOfEnum = (Enum[])classOfT.getEnumConstants(), i = arrayOfEnum.length, b = 0; b < i; ) { T constant = (T)arrayOfEnum[b];
/* 779 */           String name = constant.name();
/* 780 */           SerializedName annotation = (SerializedName)classOfT.getField(name).getAnnotation(SerializedName.class);
/* 781 */           if (annotation != null) {
/* 782 */             name = annotation.value();
/* 783 */             for (String alternate : annotation.alternate()) {
/* 784 */               this.nameToConstant.put(alternate, constant);
/*     */             }
/*     */           } 
/* 787 */           this.nameToConstant.put(name, constant);
/* 788 */           this.constantToName.put(constant, name); b++; }
/*     */       
/* 790 */       } catch (NoSuchFieldException e) {
/* 791 */         throw new AssertionError(e);
/*     */       }  }
/*     */     
/*     */     public T read(JsonReader in) throws IOException {
/* 795 */       if (in.peek() == JsonToken.NULL) {
/* 796 */         in.nextNull();
/* 797 */         return null;
/*     */       } 
/* 799 */       return (T)(Enum)this.nameToConstant.get(in.nextString());
/*     */     }
/*     */ 
/*     */     
/* 803 */     public void write(JsonWriter out, T value) throws IOException { out.value((value == null) ? null : (String)this.constantToName.get(value)); }
/*     */   }
/*     */ 
/*     */   
/* 807 */   public static final TypeAdapterFactory ENUM_FACTORY = new TypeAdapterFactory()
/*     */     {
/*     */       public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 810 */         Class<? super T> rawType = typeToken.getRawType();
/* 811 */         if (!Enum.class.isAssignableFrom(rawType) || rawType == Enum.class) {
/* 812 */           return null;
/*     */         }
/* 814 */         if (!rawType.isEnum()) {
/* 815 */           rawType = rawType.getSuperclass();
/*     */         }
/* 817 */         return new TypeAdapters.EnumTypeAdapter(rawType);
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   public static <TT> TypeAdapterFactory newFactory(final TypeToken<TT> type, final TypeAdapter<TT> typeAdapter) {
/* 823 */     return new TypeAdapterFactory()
/*     */       {
/*     */         public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 826 */           return typeToken.equals(type) ? typeAdapter : null;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static <TT> TypeAdapterFactory newFactory(final Class<TT> type, final TypeAdapter<TT> typeAdapter) {
/* 833 */     return new TypeAdapterFactory()
/*     */       {
/*     */         public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 836 */           return (typeToken.getRawType() == type) ? typeAdapter : null;
/*     */         }
/*     */         
/* 839 */         public String toString() { return "Factory[type=" + type.getName() + ",adapter=" + typeAdapter + "]"; }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static <TT> TypeAdapterFactory newFactory(final Class<TT> unboxed, final Class<TT> boxed, final TypeAdapter<? super TT> typeAdapter) {
/* 846 */     return new TypeAdapterFactory()
/*     */       {
/*     */         public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 849 */           Class<? super T> rawType = typeToken.getRawType();
/* 850 */           return (rawType == unboxed || rawType == boxed) ? typeAdapter : null;
/*     */         }
/*     */         public String toString() {
/* 853 */           return "Factory[type=" + boxed.getName() + "+" + unboxed
/* 854 */             .getName() + ",adapter=" + typeAdapter + "]";
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   public static <TT> TypeAdapterFactory newFactoryForMultipleTypes(final Class<TT> base, final Class<? extends TT> sub, final TypeAdapter<? super TT> typeAdapter) {
/* 861 */     return new TypeAdapterFactory()
/*     */       {
/*     */         public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 864 */           Class<? super T> rawType = typeToken.getRawType();
/* 865 */           return (rawType == base || rawType == sub) ? typeAdapter : null;
/*     */         }
/*     */         public String toString() {
/* 868 */           return "Factory[type=" + base.getName() + "+" + sub
/* 869 */             .getName() + ",adapter=" + typeAdapter + "]";
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T1> TypeAdapterFactory newTypeHierarchyFactory(final Class<T1> clazz, final TypeAdapter<T1> typeAdapter) {
/* 880 */     return new TypeAdapterFactory()
/*     */       {
/*     */         public <T2> TypeAdapter<T2> create(Gson gson, TypeToken<T2> typeToken) {
/* 883 */           final Class<? super T2> requestedType = typeToken.getRawType();
/* 884 */           if (!clazz.isAssignableFrom(requestedType)) {
/* 885 */             return null;
/*     */           }
/* 887 */           return new TypeAdapter<T1>()
/*     */             {
/* 889 */               public void write(JsonWriter out, T1 value) throws IOException { typeAdapter.write(out, value); }
/*     */ 
/*     */               
/*     */               public T1 read(JsonReader in) throws IOException {
/* 893 */                 T1 result = (T1)typeAdapter.read(in);
/* 894 */                 if (result != null && !requestedType.isInstance(result)) {
/* 895 */                   throw new JsonSyntaxException("Expected a " + requestedType.getName() + " but was " + result
/* 896 */                       .getClass().getName());
/*     */                 }
/* 898 */                 return result;
/*     */               }
/*     */             };
/*     */         }
/*     */         
/* 903 */         public String toString() { return "Factory[typeHierarchy=" + clazz.getName() + ",adapter=" + typeAdapter + "]"; }
/*     */       };
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\internal\bind\TypeAdapters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */