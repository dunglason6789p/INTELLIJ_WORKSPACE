/*     */ package com.google.gson;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonArray
/*     */   extends JsonElement
/*     */   implements Iterable<JsonElement>
/*     */ {
/*     */   private final List<JsonElement> elements;
/*     */   
/*  40 */   public JsonArray() { this.elements = new ArrayList(); }
/*     */ 
/*     */ 
/*     */   
/*  44 */   public JsonArray(int capacity) { this.elements = new ArrayList(capacity); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonArray deepCopy() {
/*  53 */     if (!this.elements.isEmpty()) {
/*  54 */       JsonArray result = new JsonArray(this.elements.size());
/*  55 */       for (JsonElement element : this.elements) {
/*  56 */         result.add(element.deepCopy());
/*     */       }
/*  58 */       return result;
/*     */     } 
/*  60 */     return new JsonArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void add(Boolean bool) { this.elements.add((bool == null) ? JsonNull.INSTANCE : new JsonPrimitive(bool)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public void add(Character character) { this.elements.add((character == null) ? JsonNull.INSTANCE : new JsonPrimitive(character)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public void add(Number number) { this.elements.add((number == null) ? JsonNull.INSTANCE : new JsonPrimitive(number)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public void add(String string) { this.elements.add((string == null) ? JsonNull.INSTANCE : new JsonPrimitive(string)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(JsonElement element) {
/* 105 */     if (element == null) {
/* 106 */       element = JsonNull.INSTANCE;
/*     */     }
/* 108 */     this.elements.add(element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void addAll(JsonArray array) { this.elements.addAll(array.elements); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public JsonElement set(int index, JsonElement element) { return (JsonElement)this.elements.set(index, element); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public boolean remove(JsonElement element) { return this.elements.remove(element); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public JsonElement remove(int index) { return (JsonElement)this.elements.remove(index); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public boolean contains(JsonElement element) { return this.elements.contains(element); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public int size() { return this.elements.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public Iterator<JsonElement> iterator() { return this.elements.iterator(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public JsonElement get(int i) { return (JsonElement)this.elements.get(i); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Number getAsNumber() {
/* 207 */     if (this.elements.size() == 1) {
/* 208 */       return ((JsonElement)this.elements.get(0)).getAsNumber();
/*     */     }
/* 210 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAsString() {
/* 223 */     if (this.elements.size() == 1) {
/* 224 */       return ((JsonElement)this.elements.get(0)).getAsString();
/*     */     }
/* 226 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getAsDouble() {
/* 239 */     if (this.elements.size() == 1) {
/* 240 */       return ((JsonElement)this.elements.get(0)).getAsDouble();
/*     */     }
/* 242 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BigDecimal getAsBigDecimal() {
/* 256 */     if (this.elements.size() == 1) {
/* 257 */       return ((JsonElement)this.elements.get(0)).getAsBigDecimal();
/*     */     }
/* 259 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BigInteger getAsBigInteger() {
/* 273 */     if (this.elements.size() == 1) {
/* 274 */       return ((JsonElement)this.elements.get(0)).getAsBigInteger();
/*     */     }
/* 276 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float getAsFloat() {
/* 289 */     if (this.elements.size() == 1) {
/* 290 */       return ((JsonElement)this.elements.get(0)).getAsFloat();
/*     */     }
/* 292 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAsLong() {
/* 305 */     if (this.elements.size() == 1) {
/* 306 */       return ((JsonElement)this.elements.get(0)).getAsLong();
/*     */     }
/* 308 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAsInt() {
/* 321 */     if (this.elements.size() == 1) {
/* 322 */       return ((JsonElement)this.elements.get(0)).getAsInt();
/*     */     }
/* 324 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public byte getAsByte() {
/* 329 */     if (this.elements.size() == 1) {
/* 330 */       return ((JsonElement)this.elements.get(0)).getAsByte();
/*     */     }
/* 332 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */   
/*     */   public char getAsCharacter() {
/* 337 */     if (this.elements.size() == 1) {
/* 338 */       return ((JsonElement)this.elements.get(0)).getAsCharacter();
/*     */     }
/* 340 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public short getAsShort() {
/* 353 */     if (this.elements.size() == 1) {
/* 354 */       return ((JsonElement)this.elements.get(0)).getAsShort();
/*     */     }
/* 356 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAsBoolean() {
/* 369 */     if (this.elements.size() == 1) {
/* 370 */       return ((JsonElement)this.elements.get(0)).getAsBoolean();
/*     */     }
/* 372 */     throw new IllegalStateException();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 377 */   public boolean equals(Object o) { return (o == this || (o instanceof JsonArray && ((JsonArray)o).elements.equals(this.elements))); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 382 */   public int hashCode() { return this.elements.hashCode(); }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\JsonArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */