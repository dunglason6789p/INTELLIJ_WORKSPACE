/*     */ package com.google.gson;
/*     */ 
/*     */ import com.google.gson.internal.LinkedTreeMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JsonObject
/*     */   extends JsonElement
/*     */ {
/*  33 */   private final LinkedTreeMap<String, JsonElement> members = new LinkedTreeMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonObject deepCopy() {
/*  42 */     JsonObject result = new JsonObject();
/*  43 */     for (Map.Entry<String, JsonElement> entry : this.members.entrySet()) {
/*  44 */       result.add((String)entry.getKey(), ((JsonElement)entry.getValue()).deepCopy());
/*     */     }
/*  46 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String property, JsonElement value) {
/*  58 */     if (value == null) {
/*  59 */       value = JsonNull.INSTANCE;
/*     */     }
/*  61 */     this.members.put(property, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public JsonElement remove(String property) { return (JsonElement)this.members.remove(property); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   public void addProperty(String property, String value) { add(property, createJsonElement(value)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public void addProperty(String property, Number value) { add(property, createJsonElement(value)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void addProperty(String property, Boolean value) { add(property, createJsonElement(value)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void addProperty(String property, Character value) { add(property, createJsonElement(value)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   private JsonElement createJsonElement(Object value) { return (value == null) ? JsonNull.INSTANCE : new JsonPrimitive(value); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public Set<Map.Entry<String, JsonElement>> entrySet() { return this.members.entrySet(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public Set<String> keySet() { return this.members.keySet(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public int size() { return this.members.size(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public boolean has(String memberName) { return this.members.containsKey(memberName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   public JsonElement get(String memberName) { return (JsonElement)this.members.get(memberName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 185 */   public JsonPrimitive getAsJsonPrimitive(String memberName) { return (JsonPrimitive)this.members.get(memberName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public JsonArray getAsJsonArray(String memberName) { return (JsonArray)this.members.get(memberName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public JsonObject getAsJsonObject(String memberName) { return (JsonObject)this.members.get(memberName); }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 210 */     return (o == this || (o instanceof JsonObject && ((JsonObject)o).members
/* 211 */       .equals(this.members)));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 216 */   public int hashCode() { return this.members.hashCode(); }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\JsonObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */