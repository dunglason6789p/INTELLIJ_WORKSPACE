/*    */ package com.google.gson;
/*    */ 
/*    */ public static final abstract enum LongSerializationPolicy {
/*    */   DEFAULT, STRING;
/*    */   
/*    */   public abstract JsonElement serialize(Long paramLong);
/*    */   
/*    */   static  {
/*    */     // Byte code:
/*    */     //   0: new com/google/gson/LongSerializationPolicy$1
/*    */     //   3: dup
/*    */     //   4: ldc 'DEFAULT'
/*    */     //   6: iconst_0
/*    */     //   7: invokespecial <init> : (Ljava/lang/String;I)V
/*    */     //   10: putstatic com/google/gson/LongSerializationPolicy.DEFAULT : Lcom/google/gson/LongSerializationPolicy;
/*    */     //   13: new com/google/gson/LongSerializationPolicy$2
/*    */     //   16: dup
/*    */     //   17: ldc 'STRING'
/*    */     //   19: iconst_1
/*    */     //   20: invokespecial <init> : (Ljava/lang/String;I)V
/*    */     //   23: putstatic com/google/gson/LongSerializationPolicy.STRING : Lcom/google/gson/LongSerializationPolicy;
/*    */     //   26: iconst_2
/*    */     //   27: anewarray com/google/gson/LongSerializationPolicy
/*    */     //   30: dup
/*    */     //   31: iconst_0
/*    */     //   32: getstatic com/google/gson/LongSerializationPolicy.DEFAULT : Lcom/google/gson/LongSerializationPolicy;
/*    */     //   35: aastore
/*    */     //   36: dup
/*    */     //   37: iconst_1
/*    */     //   38: getstatic com/google/gson/LongSerializationPolicy.STRING : Lcom/google/gson/LongSerializationPolicy;
/*    */     //   41: aastore
/*    */     //   42: putstatic com/google/gson/LongSerializationPolicy.$VALUES : [Lcom/google/gson/LongSerializationPolicy;
/*    */     //   45: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #34	-> 0
/*    */     //   #45	-> 13
/*    */     //   #27	-> 26
/*    */   }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\LongSerializationPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */