/*     */ package com.google.gson;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public static final abstract enum FieldNamingPolicy
/*     */   implements FieldNamingStrategy
/*     */ {
/*     */   IDENTITY, UPPER_CAMEL_CASE, UPPER_CAMEL_CASE_WITH_SPACES, LOWER_CASE_WITH_UNDERSCORES, LOWER_CASE_WITH_DASHES;
/*     */   
/*     */   static  {
/*     */     // Byte code:
/*     */     //   0: new com/google/gson/FieldNamingPolicy$1
/*     */     //   3: dup
/*     */     //   4: ldc 'IDENTITY'
/*     */     //   6: iconst_0
/*     */     //   7: invokespecial <init> : (Ljava/lang/String;I)V
/*     */     //   10: putstatic com/google/gson/FieldNamingPolicy.IDENTITY : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   13: new com/google/gson/FieldNamingPolicy$2
/*     */     //   16: dup
/*     */     //   17: ldc 'UPPER_CAMEL_CASE'
/*     */     //   19: iconst_1
/*     */     //   20: invokespecial <init> : (Ljava/lang/String;I)V
/*     */     //   23: putstatic com/google/gson/FieldNamingPolicy.UPPER_CAMEL_CASE : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   26: new com/google/gson/FieldNamingPolicy$3
/*     */     //   29: dup
/*     */     //   30: ldc 'UPPER_CAMEL_CASE_WITH_SPACES'
/*     */     //   32: iconst_2
/*     */     //   33: invokespecial <init> : (Ljava/lang/String;I)V
/*     */     //   36: putstatic com/google/gson/FieldNamingPolicy.UPPER_CAMEL_CASE_WITH_SPACES : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   39: new com/google/gson/FieldNamingPolicy$4
/*     */     //   42: dup
/*     */     //   43: ldc 'LOWER_CASE_WITH_UNDERSCORES'
/*     */     //   45: iconst_3
/*     */     //   46: invokespecial <init> : (Ljava/lang/String;I)V
/*     */     //   49: putstatic com/google/gson/FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   52: new com/google/gson/FieldNamingPolicy$5
/*     */     //   55: dup
/*     */     //   56: ldc 'LOWER_CASE_WITH_DASHES'
/*     */     //   58: iconst_4
/*     */     //   59: invokespecial <init> : (Ljava/lang/String;I)V
/*     */     //   62: putstatic com/google/gson/FieldNamingPolicy.LOWER_CASE_WITH_DASHES : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   65: iconst_5
/*     */     //   66: anewarray com/google/gson/FieldNamingPolicy
/*     */     //   69: dup
/*     */     //   70: iconst_0
/*     */     //   71: getstatic com/google/gson/FieldNamingPolicy.IDENTITY : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   74: aastore
/*     */     //   75: dup
/*     */     //   76: iconst_1
/*     */     //   77: getstatic com/google/gson/FieldNamingPolicy.UPPER_CAMEL_CASE : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   80: aastore
/*     */     //   81: dup
/*     */     //   82: iconst_2
/*     */     //   83: getstatic com/google/gson/FieldNamingPolicy.UPPER_CAMEL_CASE_WITH_SPACES : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   86: aastore
/*     */     //   87: dup
/*     */     //   88: iconst_3
/*     */     //   89: getstatic com/google/gson/FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   92: aastore
/*     */     //   93: dup
/*     */     //   94: iconst_4
/*     */     //   95: getstatic com/google/gson/FieldNamingPolicy.LOWER_CASE_WITH_DASHES : Lcom/google/gson/FieldNamingPolicy;
/*     */     //   98: aastore
/*     */     //   99: putstatic com/google/gson/FieldNamingPolicy.$VALUES : [Lcom/google/gson/FieldNamingPolicy;
/*     */     //   102: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #37	-> 0
/*     */     //   #53	-> 13
/*     */     //   #72	-> 26
/*     */     //   #90	-> 39
/*     */     //   #113	-> 52
/*     */     //   #31	-> 65
/*     */   }
/*     */   
/*     */   static String separateCamelCase(String name, String separator) {
/* 124 */     StringBuilder translation = new StringBuilder();
/* 125 */     for (int i = 0, length = name.length(); i < length; i++) {
/* 126 */       char character = name.charAt(i);
/* 127 */       if (Character.isUpperCase(character) && translation.length() != 0) {
/* 128 */         translation.append(separator);
/*     */       }
/* 130 */       translation.append(character);
/*     */     } 
/* 132 */     return translation.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String upperCaseFirstLetter(String name) {
/* 139 */     StringBuilder fieldNameBuilder = new StringBuilder();
/* 140 */     int index = 0;
/* 141 */     char firstCharacter = name.charAt(index);
/* 142 */     int length = name.length();
/*     */     
/* 144 */     while (index < length - 1 && 
/* 145 */       !Character.isLetter(firstCharacter)) {
/*     */ 
/*     */ 
/*     */       
/* 149 */       fieldNameBuilder.append(firstCharacter);
/* 150 */       firstCharacter = name.charAt(++index);
/*     */     } 
/*     */     
/* 153 */     if (!Character.isUpperCase(firstCharacter)) {
/* 154 */       String modifiedTarget = modifyString(Character.toUpperCase(firstCharacter), name, ++index);
/* 155 */       return fieldNameBuilder.append(modifiedTarget).toString();
/*     */     } 
/* 157 */     return name;
/*     */   }
/*     */ 
/*     */   
/*     */   private static String modifyString(char firstCharacter, String srcString, int indexOfSubstring) {
/* 162 */     return (indexOfSubstring < srcString.length()) ? (firstCharacter + srcString
/* 163 */       .substring(indexOfSubstring)) : 
/* 164 */       String.valueOf(firstCharacter);
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\FieldNamingPolicy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */