/*    */ package com.google.gson;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JsonSyntaxException
/*    */   extends JsonParseException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/* 30 */   public JsonSyntaxException(String msg) { super(msg); }
/*    */ 
/*    */ 
/*    */   
/* 34 */   public JsonSyntaxException(String msg, Throwable cause) { super(msg, cause); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public JsonSyntaxException(Throwable cause) { super(cause); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\JsonSyntaxException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */