/*     */ package com.google.gson;
/*     */ 
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import com.google.gson.stream.JsonToken;
/*     */ import com.google.gson.stream.JsonWriter;
/*     */ import java.io.IOException;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class DefaultDateTypeAdapter
/*     */   extends TypeAdapter<Date>
/*     */ {
/*     */   private static final String SIMPLE_NAME = "DefaultDateTypeAdapter";
/*     */   private final Class<? extends Date> dateType;
/*     */   private final DateFormat enUsFormat;
/*     */   private final DateFormat localFormat;
/*     */   
/*     */   DefaultDateTypeAdapter(Class<? extends Date> dateType) {
/*  49 */     this(dateType, 
/*  50 */         DateFormat.getDateTimeInstance(2, 2, Locale.US), 
/*  51 */         DateFormat.getDateTimeInstance(2, 2));
/*     */   }
/*     */ 
/*     */   
/*  55 */   DefaultDateTypeAdapter(Class<? extends Date> dateType, String datePattern) { this(dateType, new SimpleDateFormat(datePattern, Locale.US), new SimpleDateFormat(datePattern)); }
/*     */ 
/*     */ 
/*     */   
/*  59 */   DefaultDateTypeAdapter(Class<? extends Date> dateType, int style) { this(dateType, DateFormat.getDateInstance(style, Locale.US), DateFormat.getDateInstance(style)); }
/*     */ 
/*     */   
/*     */   public DefaultDateTypeAdapter(int dateStyle, int timeStyle) {
/*  63 */     this(Date.class, 
/*  64 */         DateFormat.getDateTimeInstance(dateStyle, timeStyle, Locale.US), 
/*  65 */         DateFormat.getDateTimeInstance(dateStyle, timeStyle));
/*     */   }
/*     */   
/*     */   public DefaultDateTypeAdapter(Class<? extends Date> dateType, int dateStyle, int timeStyle) {
/*  69 */     this(dateType, 
/*  70 */         DateFormat.getDateTimeInstance(dateStyle, timeStyle, Locale.US), 
/*  71 */         DateFormat.getDateTimeInstance(dateStyle, timeStyle));
/*     */   }
/*     */   
/*     */   DefaultDateTypeAdapter(Class<? extends Date> dateType, DateFormat enUsFormat, DateFormat localFormat) {
/*  75 */     if (dateType != Date.class && dateType != Date.class && dateType != Timestamp.class) {
/*  76 */       throw new IllegalArgumentException("Date type must be one of " + Date.class + ", " + Timestamp.class + ", or " + Date.class + " but was " + dateType);
/*     */     }
/*  78 */     this.dateType = dateType;
/*  79 */     this.enUsFormat = enUsFormat;
/*  80 */     this.localFormat = localFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(JsonWriter out, Date value) throws IOException {
/*  87 */     if (value == null) {
/*  88 */       out.nullValue();
/*     */       return;
/*     */     } 
/*  91 */     synchronized (this.localFormat) {
/*  92 */       String dateFormatAsString = this.enUsFormat.format(value);
/*  93 */       out.value(dateFormatAsString);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Date read(JsonReader in) throws IOException {
/*  99 */     if (in.peek() == JsonToken.NULL) {
/* 100 */       in.nextNull();
/* 101 */       return null;
/*     */     } 
/* 103 */     Date date = deserializeToDate(in.nextString());
/* 104 */     if (this.dateType == Date.class)
/* 105 */       return date; 
/* 106 */     if (this.dateType == Timestamp.class)
/* 107 */       return new Timestamp(date.getTime()); 
/* 108 */     if (this.dateType == Date.class) {
/* 109 */       return new Date(date.getTime());
/*     */     }
/*     */     
/* 112 */     throw new AssertionError();
/*     */   }
/*     */ 
/*     */   
/*     */   private Date deserializeToDate(String s) {
/* 117 */     synchronized (this.localFormat) {
/*     */       
/* 119 */       return this.localFormat.parse(s);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 134 */     StringBuilder sb = new StringBuilder();
/* 135 */     sb.append("DefaultDateTypeAdapter");
/* 136 */     sb.append('(').append(this.localFormat.getClass().getSimpleName()).append(')');
/* 137 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\DefaultDateTypeAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */