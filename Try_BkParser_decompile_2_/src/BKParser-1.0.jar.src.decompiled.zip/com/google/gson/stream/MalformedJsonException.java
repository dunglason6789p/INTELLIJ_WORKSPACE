/*    */ package com.google.gson.stream;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MalformedJsonException
/*    */   extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/* 29 */   public MalformedJsonException(String msg) { super(msg); }
/*    */ 
/*    */   
/*    */   public MalformedJsonException(String msg, Throwable throwable) {
/* 33 */     super(msg);
/*    */ 
/*    */     
/* 36 */     initCause(throwable);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   public MalformedJsonException(Throwable throwable) { initCause(throwable); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\stream\MalformedJsonException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */