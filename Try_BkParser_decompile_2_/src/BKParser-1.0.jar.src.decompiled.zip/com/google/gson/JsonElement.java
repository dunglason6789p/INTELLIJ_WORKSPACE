/*     */ package com.google.gson;
/*     */ 
/*     */ import com.google.gson.internal.Streams;
/*     */ import com.google.gson.stream.JsonWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonElement
/*     */ {
/*     */   public abstract JsonElement deepCopy();
/*     */   
/*  47 */   public boolean isJsonArray() { return this instanceof JsonArray; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   public boolean isJsonObject() { return this instanceof JsonObject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public boolean isJsonPrimitive() { return this instanceof JsonPrimitive; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public boolean isJsonNull() { return this instanceof JsonNull; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonObject getAsJsonObject() {
/*  88 */     if (isJsonObject()) {
/*  89 */       return (JsonObject)this;
/*     */     }
/*  91 */     throw new IllegalStateException("Not a JSON Object: " + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonArray getAsJsonArray() {
/* 104 */     if (isJsonArray()) {
/* 105 */       return (JsonArray)this;
/*     */     }
/* 107 */     throw new IllegalStateException("Not a JSON Array: " + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonPrimitive getAsJsonPrimitive() {
/* 120 */     if (isJsonPrimitive()) {
/* 121 */       return (JsonPrimitive)this;
/*     */     }
/* 123 */     throw new IllegalStateException("Not a JSON Primitive: " + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JsonNull getAsJsonNull() {
/* 137 */     if (isJsonNull()) {
/* 138 */       return (JsonNull)this;
/*     */     }
/* 140 */     throw new IllegalStateException("Not a JSON Null: " + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public boolean getAsBoolean() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   Boolean getAsBooleanWrapper() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public Number getAsNumber() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public String getAsString() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public double getAsDouble() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   public float getAsFloat() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 231 */   public long getAsLong() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 244 */   public int getAsInt() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 258 */   public byte getAsByte() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 272 */   public char getAsCharacter() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   public BigDecimal getAsBigDecimal() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public BigInteger getAsBigInteger() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 313 */   public short getAsShort() { throw new UnsupportedOperationException(getClass().getSimpleName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*     */     try {
/* 322 */       StringWriter stringWriter = new StringWriter();
/* 323 */       JsonWriter jsonWriter = new JsonWriter(stringWriter);
/* 324 */       jsonWriter.setLenient(true);
/* 325 */       Streams.write(this, jsonWriter);
/* 326 */       return stringWriter.toString();
/* 327 */     } catch (IOException e) {
/* 328 */       throw new AssertionError(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\JsonElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */