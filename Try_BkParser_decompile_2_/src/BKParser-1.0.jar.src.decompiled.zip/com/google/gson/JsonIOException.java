/*    */ package com.google.gson;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JsonIOException
/*    */   extends JsonParseException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/* 29 */   public JsonIOException(String msg) { super(msg); }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public JsonIOException(String msg, Throwable cause) { super(msg, cause); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   public JsonIOException(Throwable cause) { super(cause); }
/*    */ }


/* Location:              E:\temp_extract\BkParser\BKParser-1.0.jar!\com\google\gson\JsonIOException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.0.7
 */