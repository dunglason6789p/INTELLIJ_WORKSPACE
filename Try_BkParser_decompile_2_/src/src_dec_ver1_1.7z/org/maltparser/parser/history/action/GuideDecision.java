package org.maltparser.parser.history.action;

public interface GuideDecision extends ActionDecision {
   int numberOfDecisions();
}
