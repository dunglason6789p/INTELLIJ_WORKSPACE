/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.parser.history;

public interface GuideHistory {
}

