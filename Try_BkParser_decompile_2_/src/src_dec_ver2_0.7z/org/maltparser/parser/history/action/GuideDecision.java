/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.parser.history.action;

import org.maltparser.parser.history.action.ActionDecision;

public interface GuideDecision
extends ActionDecision {
    public int numberOfDecisions();
}

