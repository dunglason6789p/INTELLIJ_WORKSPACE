/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.core.feature.function;

import org.maltparser.core.feature.function.FeatureFunction;

public interface FeatureCastFunction
extends FeatureFunction {
}

