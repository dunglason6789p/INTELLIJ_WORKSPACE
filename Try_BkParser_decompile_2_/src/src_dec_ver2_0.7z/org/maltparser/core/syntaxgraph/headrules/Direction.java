/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.core.syntaxgraph.headrules;

public enum Direction {
    LEFT,
    RIGHT;
    
}

