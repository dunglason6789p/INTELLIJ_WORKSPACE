/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.core.syntaxgraph;

public interface Weightable {
    public void setWeight(double var1);

    public double getWeight();
}

