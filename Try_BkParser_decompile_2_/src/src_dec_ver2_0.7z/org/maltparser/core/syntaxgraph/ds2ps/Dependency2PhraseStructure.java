/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.core.syntaxgraph.ds2ps;

public interface Dependency2PhraseStructure {
}

