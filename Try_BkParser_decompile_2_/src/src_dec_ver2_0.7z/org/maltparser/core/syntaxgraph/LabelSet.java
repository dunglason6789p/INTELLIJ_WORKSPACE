/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.core.syntaxgraph;

import java.util.LinkedHashMap;
import java.util.Map;
import org.maltparser.core.symbol.SymbolTable;

public class LabelSet
extends LinkedHashMap<SymbolTable, Integer> {
    public static final long serialVersionUID = 8045567022124816378L;

    public LabelSet() {
    }

    public LabelSet(int initialCapacity) {
        super(initialCapacity);
    }

    public LabelSet(int initialCapacity, float loadFactor) {
        super(initialCapacity, loadFactor);
    }

    public LabelSet(LabelSet labelSet) {
        super(labelSet);
    }
}

