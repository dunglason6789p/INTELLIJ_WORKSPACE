/*
 * Decompiled with CFR 0.146.
 */
package org.apache.commons.lang3.builder;

public interface Builder<T> {
    public T build();
}

