/*
 * Decompiled with CFR 0.146.
 */
package libsvm;

public interface svm_print_interface {
    public void print(String var1);
}

