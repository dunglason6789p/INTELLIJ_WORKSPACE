/*
 * Decompiled with CFR 0.146.
 */
package org.apache.log4j.spi;

import org.apache.log4j.spi.LoggingEvent;

public interface TriggeringEventEvaluator {
    public boolean isTriggeringEvent(LoggingEvent var1);
}

