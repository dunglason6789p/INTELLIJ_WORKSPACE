/*
 * Decompiled with CFR 0.146.
 */
package org.apache.log4j.spi;

public interface ThrowableRenderer {
    public String[] doRender(Throwable var1);
}

