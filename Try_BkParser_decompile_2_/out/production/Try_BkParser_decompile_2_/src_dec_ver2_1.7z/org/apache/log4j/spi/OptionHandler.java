/*
 * Decompiled with CFR 0.146.
 */
package org.apache.log4j.spi;

public interface OptionHandler {
    public void activateOptions();
}

