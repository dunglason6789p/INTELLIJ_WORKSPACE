/*
 * Decompiled with CFR 0.146.
 */
package org.apache.log4j.or;

public interface ObjectRenderer {
    public String doRender(Object var1);
}

