/*
 * Decompiled with CFR 0.146.
 */
package org.apache.log4j.lf5;

import org.apache.log4j.lf5.LogRecord;

public interface LogRecordFilter {
    public boolean passes(LogRecord var1);
}

