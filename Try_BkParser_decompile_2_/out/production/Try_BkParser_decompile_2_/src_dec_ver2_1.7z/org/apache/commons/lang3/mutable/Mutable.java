/*
 * Decompiled with CFR 0.146.
 */
package org.apache.commons.lang3.mutable;

public interface Mutable<T> {
    public T getValue();

    public void setValue(T var1);
}

