/*
 * Decompiled with CFR 0.146.
 */
package org.apache.commons.lang3.text;

import java.text.Format;
import java.util.Locale;

public interface FormatFactory {
    public Format getFormat(String var1, String var2, Locale var3);
}

