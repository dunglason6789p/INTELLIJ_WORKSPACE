/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser;

import org.maltparser.MaltConsoleEngine;

public class Malt {
    public static void main(String[] args) {
        MaltConsoleEngine engine = new MaltConsoleEngine();
        engine.startEngine(args);
    }
}

