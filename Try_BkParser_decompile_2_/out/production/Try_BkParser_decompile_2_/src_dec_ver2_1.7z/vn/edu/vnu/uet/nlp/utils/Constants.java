/*
 * Decompiled with CFR 0.146.
 */
package vn.edu.vnu.uet.nlp.utils;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public interface Constants {
    public static final Charset cs = StandardCharsets.UTF_8;
}

