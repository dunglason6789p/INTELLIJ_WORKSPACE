package vn.edu.vnu.uet.nlp.utils;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public interface Constants {
   Charset cs = StandardCharsets.UTF_8;
}
