package vn.edu.vnu.uet.nlp.segmenter;

public enum SyllableType {
   BOS,
   EOS,
   ALLUPPER,
   UPPER,
   LOWER,
   NUMBER,
   OTHER;

   private SyllableType() {
   }
}
