package vn.edu.vnu.uet.nlp.segmenter;

public interface Configure {
   int SPACE = 0;
   int UNDERSCORE = 1;
   int WINDOW_LENGTH = 2;
   int TRAIN = 0;
   int PREDICT = 1;
   int TEST = 2;
}
