package vn.edu.vnu.uet.nlp.tokenizer;

public interface StringConst {
   String BOS = "<s>";
   String EOS = "</s>";
   String SPACE = " ";
   String COMMA = ",";
   String STOP = ".";
   String COLON = ":";
   String UNDERSCORE = "_";
}
