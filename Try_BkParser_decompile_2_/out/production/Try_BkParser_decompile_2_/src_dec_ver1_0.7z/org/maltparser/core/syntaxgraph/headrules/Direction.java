package org.maltparser.core.syntaxgraph.headrules;

public enum Direction {
   LEFT,
   RIGHT;

   private Direction() {
   }
}
