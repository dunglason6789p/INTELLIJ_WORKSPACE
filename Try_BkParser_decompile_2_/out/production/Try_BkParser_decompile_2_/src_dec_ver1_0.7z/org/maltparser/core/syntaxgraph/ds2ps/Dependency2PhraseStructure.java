package org.maltparser.core.syntaxgraph.ds2ps;

public interface Dependency2PhraseStructure {
}
