package org.maltparser.core.feature.function;

public interface FeatureMapFunction extends FeatureFunction {
}
