package org.maltparser.core.syntaxgraph;

public interface Weightable {
   void setWeight(double var1);

   double getWeight();
}
