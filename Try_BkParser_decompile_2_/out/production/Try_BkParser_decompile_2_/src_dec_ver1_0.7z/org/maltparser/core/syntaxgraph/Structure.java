package org.maltparser.core.syntaxgraph;

import org.maltparser.core.exception.MaltChainedException;

public interface Structure {
   void clear() throws MaltChainedException;
}
