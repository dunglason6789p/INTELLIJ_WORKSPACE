package org.maltparser.parser.history;

public interface GuideHistory {
}
