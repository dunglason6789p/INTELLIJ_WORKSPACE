package org.maltparser.parser.history.action;

public interface ActionDecision {
   void clear();
}
