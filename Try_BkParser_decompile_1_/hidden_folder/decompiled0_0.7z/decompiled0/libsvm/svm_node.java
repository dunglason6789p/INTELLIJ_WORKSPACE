/*
 * Decompiled with CFR 0.146.
 */
package libsvm;

import java.io.Serializable;

public class svm_node
implements Serializable {
    public int index;
    public double value;
}

