/*
 * Decompiled with CFR 0.146.
 */
package vn.edu.vnu.uet.liblinear;

public interface Feature {
    public int getIndex();

    public double getValue();

    public void setValue(double var1);
}

