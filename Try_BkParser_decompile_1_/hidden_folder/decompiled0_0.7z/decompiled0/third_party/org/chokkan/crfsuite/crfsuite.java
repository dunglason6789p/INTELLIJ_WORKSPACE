/*
 * Decompiled with CFR 0.146.
 */
package third_party.org.chokkan.crfsuite;

import third_party.org.chokkan.crfsuite.crfsuiteJNI;

public class crfsuite {
    public static String version() {
        return crfsuiteJNI.version();
    }
}

