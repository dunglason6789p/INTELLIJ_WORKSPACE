/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.parser.history.action;

public interface ActionDecision {
    public void clear();
}

