/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.core.syntaxgraph;

import org.maltparser.core.exception.MaltChainedException;

public interface Structure {
    public void clear() throws MaltChainedException;
}

