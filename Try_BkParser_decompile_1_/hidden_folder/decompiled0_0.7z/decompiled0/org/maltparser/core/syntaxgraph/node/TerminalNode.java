/*
 * Decompiled with CFR 0.146.
 */
package org.maltparser.core.syntaxgraph.node;

import org.maltparser.core.syntaxgraph.node.PhraseStructureNode;

public interface TerminalNode
extends PhraseStructureNode {
}

