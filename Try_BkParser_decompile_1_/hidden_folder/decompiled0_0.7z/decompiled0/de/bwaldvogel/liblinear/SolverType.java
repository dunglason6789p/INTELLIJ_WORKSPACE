/*
 * Decompiled with CFR 0.146.
 */
package de.bwaldvogel.liblinear;

public enum SolverType {
    L2R_LR,
    L2R_L2LOSS_SVC_DUAL,
    L2R_L2LOSS_SVC,
    L2R_L1LOSS_SVC_DUAL,
    MCSVM_CS,
    L1R_L2LOSS_SVC,
    L1R_LR,
    L2R_LR_DUAL;
    
}

